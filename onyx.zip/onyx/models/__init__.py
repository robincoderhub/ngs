"""Global model related classes"""
