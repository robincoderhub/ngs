"""Custom model fields"""

from django.db.models import CharField, TextField
from django.utils.translation import gettext_lazy as _

from onyx.forms import validators
from onyx.forms import fields


class InternalNameField(CharField):
    """CharField that accepts a valid internal name

    Uses onyx.forms.fields.IternalNameField as it's form equivelant.

    Args:
        *args: Inherited arguments
        **kwargs: Inherited keyword arguments"""

    description = _("Internal Name")
    """A short description of the field"""

    def __init__(self, *args, **kwargs):
        kwargs.setdefault('max_length', 255)
        super().__init__(*args, **kwargs)
        self.validators.append(validators.InternalNameValidator())

    def formfield(self, **kwargs):
        """Returns a non-model field for use in forms

        Args:
            **kwargs: Keyword arguments to be passed to the field

        Returns:
            A InternalNameField form field"""
        return super().formfield(
            **{
                'form_class': fields.InternalNameField
            },
            **kwargs
        )


class DottedPathField(CharField):
    """CharField that accepts a valid python import path

    Uses onyx.forms.fields.DottedPathField as it's form equivelant.

    Args:
        *args: Inherited arguments
        **kwargs: Inherited keyword arguments"""

    description = _("Dotted Path")
    """A short description of the field"""

    def __init__(self, *args, **kwargs):
        kwargs.setdefault('max_length', 255)
        super().__init__(*args, **kwargs)
        self.validators.append(validators.DottedPathValidator())

    def formfield(self, **kwargs):
        """Returns a non-model field for use in forms

        Args:
            **kwargs: Keyword arguments to be passed to the field

        Returns:
            A DottedPathField form field"""
        return super().formfield(
            **{
                'form_class': fields.DottedPathField
            },
            **kwargs
        )


class ExistingDottedPathField(DottedPathField):
    """CharField that accepts a valid python import path that exists on the
    python path

    Uses onyx.forms.fields.ExistingDottedPathField as it's form equivelant.

    Args:
        *args: Inherited arguments
        **kwargs: Inherited keyword arguments"""

    description = _("Existing Dotted Path")
    """A short description of the field"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.validators.append(validators.DottedPathExistsValidator())

    def formfield(self, **kwargs):
        """Returns a non-model field for use in forms

        Args:
            **kwargs: Keyword arguments to be passed to the field

        Returns:
            An ExistingDottedPathField form field"""
        return super().formfield(
            **{
                'form_class': fields.ExistingDottedPathField
            },
            **kwargs
        )


class JSONField(TextField):
    """Note this is different from Django's JSONField which relates to
    an actual JSON column type that's unique to postgres.

    This field is a TextField with additional JSON validators added.

    https://docs.djangoproject.com/en/2.2/ref/contrib/postgres/fields/#jsonfield

    Uses onyx.forms.fields.JSONField as it's form equivelant.

    Args:
        *args: Inherited arguments
        **kwargs: Inherited keyword arguments"""

    description = _("JSON Data")
    """A short description of the field"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.validators.append(validators.JSONValidator())

    def formfield(self, **kwargs):
        """Returns a non-model field for use in forms

        Args:
            **kwargs: Keyword arguments to be passed to the field

        Returns:
            A JSONField form field"""
        return super().formfield(
            **{
                'form_class': fields.JSONField
            },
            **kwargs
        )


class JSONObjectField(JSONField):
    """Note this is different from Django's JSONField which relates to
    an actual JSON column type that's unique to postgres.

    This field is a TextField with additional JSON validators added, with the
    addition that it must also validate to an JSON object.

    https://docs.djangoproject.com/en/2.2/ref/contrib/postgres/fields/#jsonfield

    Uses onyx.forms.fields.JSONObjectField as it's form equivelant.

    Args:
        *args: Inherited arguments
        **kwargs: Inherited keyword arguments"""

    description = _("JSON Object")
    """A short description of the field"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.validators.append(validators.JSONObjectValidator())

    def formfield(self, **kwargs):
        """Returns a non-model field for use in forms

        Args:
            **kwargs: Keyword arguments to be passed to the field

        Returns:
            A JSONObjectField form field"""
        return super().formfield(
            **{
                'form_class': fields.JSONObjectField
            },
            **kwargs
        )


class URLPathField(CharField):
    """CharField that accepts a valid URL path string
    i.e. /my/path/test.js?something=else

    Uses onyx.forms.fields.URLPathField as it's form equivelant

    Args:
        *args: Inherited arguments
        **kwargs: Inherited keyword arguments"""

    description = _("URL Path")
    """A short description of the field"""

    def __init__(self, *args, **kwargs):
        kwargs.setdefault('max_length', 255)
        super().__init__(*args, **kwargs)
        self.validators.append(validators.URLPathValidator())

    def formfield(self, **kwargs):
        """Returns a non-model field for use in forms

        Args:
            **kwargs: Keyword arguments to be passed to the field

        Returns:
            A URLPathField form field"""
        return super().formfield(
            **{
                'form_class': fields.URLPathField
            },
            **kwargs
        )


class FlexibleURLField(CharField):
    """CharField that accepts a valid URL path string
    i.e. /my/path/test.js?something=else or a fully qualified url.

    Uses onyx.forms.fields.FlexibleURLField as it's form equivelant

    Args:
        *args: Inherited arguments
        **kwargs: Inherited keyword arguments"""

    description = _("URL")
    """A short description of the field"""

    def __init__(self, *args, **kwargs):
        kwargs.setdefault('max_length', 255)
        super().__init__(*args, **kwargs)
        self.validators.append(validators.FlexibleURLValidator())

    def formfield(self, **kwargs):
        """Returns a non-model field for use in forms

        Args:
            **kwargs: Keyword arguments to be passed to the field

        Returns:
            A FlexibleURLField form field"""
        return super().formfield(
            **{
                'form_class': fields.FlexibleURLField
            },
            **kwargs
        )


class TinyMCEField(TextField):
    """A TextField using the TinyMCE widget

    Args:
        *args: Inherited arguments
        **kwargs: Inherited keyword arguments"""

    description = _("TinyMCE")
    """A short description of the field"""

    def formfield(self, **kwargs):
        """Returns a non-model field for use in forms

        Args:
            **kwargs: Keyword arguments to be passed to the field

        Returns:
            A TinyMCEField form field"""
        kwargs.setdefault('form_class', fields.TinyMCEField)
        return super().formfield(**kwargs)
