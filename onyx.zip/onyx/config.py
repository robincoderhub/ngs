"""
# Onyx app config classes

These are the app configs for the main onyx app and the sub apps.
"""

from django.apps import AppConfig


class AbstractOnyxConfig(AppConfig):
    """Currently empty but if you need all sub
    apps to have shared traits this is where they
    would go"""
    pass


class OnyxConfig(AbstractOnyxConfig):
    """Main Onyx app config"""

    name = "onyx"
    """The name of the app"""

    verbose_name = "Onyx"
    """The verbose name of the app"""

    label = "onyx"
    """The app label of this app"""
