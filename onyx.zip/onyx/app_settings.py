"""
# Onyx settings variables

Global application settings and their defaults. Any variables that are global
or could be used by multiple different apps should go here. Consider this
Onyx's settings.
"""

import datetime
import os

from django.conf import settings

PUBLIC_MEDIA_ROOT = getattr(settings, 'PUBLIC_MEDIA_ROOT', os.path.join(
    settings.MEDIA_ROOT,
    'public'
))
"""Public media root, this where all onyx apps should
place their publicly accessible files."""


PRIVATE_MEDIA_ROOT = getattr(settings, 'PRIVATE_MEDIA_ROOT', os.path.join(
    settings.MEDIA_ROOT,
    'private'
))
"""Private media root, this is where all onyx app should
place non publicly accessible uploads."""


GIT_REPO_NAME = getattr(settings, 'GIT_REPO_NAME', 'unknown')
"""The repository name of the current project (NOT onyx)."""


GIT_REPO_HASH = getattr(settings, 'GIT_REPO_HASH', 'unknown')
"""The commit hash of the current project (NOT onyx)."""


APP_ENV = getattr(settings, 'APP_ENV', 'live')
"""Application environment, this is typically one dev, staging or live."""


APP_RELEASE = getattr(
    settings,
    'APP_RELEASE',
    f"{GIT_REPO_NAME}-{APP_ENV}@{GIT_REPO_HASH}"
)
"""Application 'release', this is a string that identifies
the deployment, environment and code hash of the project. This is
mostly to namespace and identify the source of errors sent to Sentry."""


APP_NAME = getattr(settings, 'APP_NAME', 'Untitled Project')
"""Application name, this is typically the website's name
i.e. "Bob's Potatoes"."""


APP_HOSTNAME = getattr(settings, 'APP_HOSTNAME', 'localhost')
"""The hostname of the main application, the site's url."""


APP_EMAIL = getattr(
    settings,
    'APP_EMAIL',
    'onyx-default@test.mercurytide.co.uk'
)
"""This is a convenience variable, the main email address to
be used for contact about errors and so on. Saves having to set this
in multiple places."""


APP_COPYRIGHT_YEAR = getattr(
    settings,
    'APP_COPYRIGHT_YEAR',
    datetime.datetime.now().year
)
"""Copyright year, this can be used to display copyright
information in templates. For example if the site launched in 2017 it
would display 2017-2020."""


SENTRY_DSN = getattr(settings, 'SENTRY_DSN', None)
"""The Sentry DSN key used to identify the account errors should
be sent to."""


RECAPTCHA_VERSION = getattr(settings, 'RECAPTCHA_VERSION', 'v2_invisible')
"""The version of recaptcha to use, values can be 'v2',
'v2_invisible' and 'v3'."""


RECAPTCHA_PUBLIC_KEY = getattr(settings, 'RECAPTCHA_PUBLIC_KEY', None)
"""The recaptcha public key to use, by default this is
the test v2 recaptcha public key which WILL NOT work with v3."""


RECAPTCHA_PRIVATE_KEY = getattr(settings, 'RECAPTCHA_PRIVATE_KEY', None)
"""The recaptch private key to use, by defaul this is
the test v2 recaptcha private key which WILL NOT work with v3."""


GOOGLE_MAPS_KEY = getattr(settings, 'GOOGLE_MAPS_KEY', None)
"""Google maps JS API key"""


GOOGLE_ANALYTICS_ACCOUNT = getattr(settings, 'GOOGLE_ANALYTICS_ACCOUNT', None)
"""Google analytics account identifier"""
