"""General use decorators."""


def verbose_name(name):
    """Adds a 'verbose_name' attribute to a class or function,
    this typically can be used to identify classes or functions
    with a human name

    Args:
        name: The name to set on the object
    
    Returns:
        A decorator wrapper function"""
    def wrapped(obj):
        obj.verbose_name = name
        return obj
    return wrapped


def get_verbose_name(obj):
    """
    Fetches the verbose name assign from an object
    that has it set

    Args:
        obj: The object to test

    Returns:
        The verbose name or None if not set"""
    return getattr(obj, 'verbose_name', None)
