"""General use templating related utilities"""

import os

from django.conf import settings
from django.template.loaders.app_directories import get_app_template_dirs


def get_template_list(file_paths=False):
    """Get a list of templates throughout the project.

    Args:
        file_paths: Defaults to False, if set to True will return
            all the full template file paths detected in this project
            including templates that are overidden. If False, will
            return template file paths relative to the project removing
            any duplicates where apps have overidden others.

    Returns:
        A list of template paths"""
    template_dir_list = list(get_app_template_dirs('templates'))
    for template_settings in settings.TEMPLATES:
        if 'DIRS' in template_settings:
            template_dir_list = template_dir_list + list(template_settings['DIRS'])
    template_list = []
    for template_dir in template_dir_list:
        for base_dir, __, filenames in os.walk(template_dir):
            for filename in filenames:
                file_path = os.path.join(base_dir, filename)
                if not file_paths:
                    file_path = file_path.replace(f"{template_dir}/", '')
                template_list.append(file_path)
    return list(set(template_list))
