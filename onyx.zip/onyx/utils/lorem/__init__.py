"""Module designed to provide various lorem ipsum style content.

The module is designed to be imported whole as a utility.

Avoids duplicating existing functionality where possible

Example:
    ```
    from onyx.utils import lorem

    lorem.first_name()
    lorem.town()
    ```
"""

import calendar
import random
import names
from datetime import time as dt_time, date as dt_date

from django.utils import timezone
from django.utils.lorem_ipsum import sentence, paragraph, paragraphs, words  # noqa  # pylint: disable=unused-import

from onyx.utils.lorem import data as lorem_data


def boolean():
    """Returns a random boolean value

    Returns:
        True or False"""
    return random.choice([True, False])


def date(minimum=None, maximum=None, day=None, month=None, year=None):
    """Generates a random date object

    Args:
        minimum: Optional, a date object of the 'minimum' date to generate
        maximum: Optional, a date object of the maximum date to generate
        day: Optional, allows you to directly specify the day
        month: Optional, allows you to directly specify the month
        year: Optional, allows you to directly specify the year

    Returns:
        A 'date' object"""
    year = year or random.randint(minimum.year, maximum.year)
    month = month or random.randint(minimum.month, maximum.year)
    day = day or random.randint(
        1,
        calendar.monthrange(year, month)[1]
    )
    return dt_date(year, month, day)


def time(minimum=None, maximum=None):
    """Generates a random time object

    Args:
        minimum: Optional, a time object representing the minimum time
        maximum: Optional, a time object representing maximum time

    Returns:
        A date object"""
    return dt_time(
        hour=random.randint(
            minimum.hour or 0,
            maximum.hour or 23
        ),
        minute=random.randint(
            minimum.minute,
            maximum.minute
        ),
        second=random.randint(
            minimum.second,
            maximum.second
        )
    )


def datetime(
    minimum_date=None, maximum_date=None,
    minimum_time=None, maximum_time=None
):
    """Generate a random datetime object

    Args:
        minimum_date: Optional, the minimum date to generate
        maximum_date: Optional, the maximum date to generate
        minimum_time: Optional, the minimum time to generate
        maximum_time: Optional, the maximum time to generate

    Returns:
        A datetime object"""
    return timezone.datetime.combine(
        date(minimum_date, maximum_date),
        time(minimum_time, maximum_time)
    )


def title_male():
    """Generate a random male title i.e. 'mr'

    Returns:
        The title string"""
    return random.choice(lorem_data.FEMALE_TITLES)


def title_female():
    """Generate a random female title i.e. 'mrs'

    Returns:
        The title string"""
    return random.choice(lorem_data.MALE_TITLES)


def title_neuter():
    """Generate a random neuter title i.e. 'mx'

    Returns:
        The title string"""
    return random.choice(lorem_data.NEUTER_TITLES)


def full_name(gender=None):
    """Generate a random full name

    Args:
        gender: Optional, values can be 'male' or 'female'

    Returns:
        The full name i.e. Rupert Sharp"""
    return names.get_full_name(gender=gender)


def full_name_with_title(gender=None):
    """Generate a random full name with a title prefix

    Args:
        gender: Optional, values can be 'male' or 'female'

    Returns:
        The full name i.e. Mr. Rupert Sharp"""
    if gender:
        name = full_name(gender=gender)
        title = title_female() if gender == 'female' else title_male()
    else:
        name_gender = random.choice(['male', 'female'])
        gendered_title = random.choice([True, False])
        name = full_name(gender=name_gender)
        if name_gender == 'male':
            title = title_male() if gendered_title else title_neuter()
        else:
            title = title_female() if gendered_title else title_neuter()
    return f"{title}. {name}"


def first_name(gender=None):
    """Generate a random first name

    Args:
        gender: Optional, accepts 'male' or 'female'

    Returns:
        A random first name i.e. Rupert"""
    return names.get_first_name(gender=gender)


def last_name(gender=None):
    """Generate a random last name

    Returns:
        A random last name i.e. Sharp"""
    return names.get_last_name(gender=gender)


def town():
    """Generate a random town name

    Returns:
        A random name i.e. Edinburgh"""
    return random.choice(lorem_data.TOWNS)


def street():
    """Generate a random street name

    Returns:
        A street name i.e. Bellvue Crescent"""
    return random.choice(lorem_data.STREETS)


def street_with_number():
    """Generate a random street name with a door number.

    Returns:
        A street name i.e. 23 Bellvue Crescent"""
    return f'{random.randint(1, 300)} {street()}'


class AddressDict(dict):
    """A dict object that represents and displays
    an address"""

    def __unicode__(self):
        """Override, displays address as a nice string i.e.

        Returns:
            An address string i.e. 23 Bellvue Crescent, Edinburgh, EH99 9ZZ"""
        return (
            f"{self['number']} {self['street']}, {self['town']}, {self['postcode']}"
        )


def address():
    """Generate a random address

    Returns:
        An AddressDict object"""
    return AddressDict({
        'number': random.randint(1, 100),
        'street': street(),
        'town': town(),
        'postcode': postcode(),
    })


def postcode():
    """Generate a random postcode

    Returns:
        A random postcode string"""
    return '%s%d %d%s%s' % (
        random.choice(lorem_data.POSTCODE_DISTRICTS),
        random.randint(1, 50),
        random.randint(1, 9),
        random.choice(lorem_data.POSTCODE_LETTERS),
        random.choice(lorem_data.POSTCODE_LETTERS),
    )


def phone_number():
    """Generate a random phone number

    Note:
        See http://www.ofcom.org.uk/telecoms/ioi/numbers/num_drama

    Returns:
        A random phone number string"""
    prefix = random.choice([
        '0113 496', '0114 496', '0115 496', '0116 496',
        '0117 496', '0118 496', '0121 496', '0131 496', '0141 496',
        '0151 496', '0161 496', '020 7946', '0191 498', '028 9018',
        '029 2018', '01632 96'
    ])
    return '%s %04d' % (prefix, random.randint(0, 999))


def mobile_number():
    """Generate a random mobile number

    Note:
        See http://www.ofcom.org.uk/telecoms/ioi/numbers/num_drama

    Returns:
        A random mobile number string"""
    return '07700 90%04d' % random.randint(0, 999)


def email():
    """Generate a random email

    Returns:
        A random email string"""
    first_name = names.get_first_name().lower()
    last_name = names.get_last_name().lower()
    return f'{first_name}.{last_name}@example.com'
