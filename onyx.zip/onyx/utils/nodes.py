"""Module for complex manipulation of nested trees using nodes"""

from django.template.loader import render_to_string


class NodeSelectorError(ValueError):
    """Exception thrown when an invalid or non existent selector is used."""


class NodeDuplicateNameError(ValueError):
    """Exception thrown when trying to add a node to another nodes
    children when a matching named node already exists."""


class NodeTreeMixin(object):
    """A mixin to augment a list-like object to manage node objects."""

    def set_node_selected(
        self,
        selector,
        selected=True,
        update_selected_parents=True
    ):
        """Set a node as selected and set it's parent heirarchy as
            'selected parents' if specified.

        Args:
            selector (str): A selector, node names joined by periods.
            selected (bool): Whether to set the node as selected or
                unselected (default is False)
            update_selected_parents (bool): Whether to set the parents
                of the node as 'selected parents' or deselect them if
                selected is False. (default is True)

        Returns:
            bool: True if the node was found and updated, False if not found."""
        persist = {
            'node_found': False
        }

        def callback(
            callback_node, callback_selector,
            parent_nodes, *args, persist
        ):
            if selector == callback_selector:
                persist['node_found'] = True
                callback_node.set_node_selected(selected)
                if update_selected_parents:
                    parent_nodes.reverse()
                    for parent_node in parent_nodes:
                        if not selected:
                            update_parent = True
                            for child_node in parent_node.get_node_children():
                                if child_node.is_node_selected()\
                                 or child_node.is_node_selected_parent():
                                    update_parent = False
                                    break
                            if update_parent:
                                parent_node.set_node_selected_parent(selected)
                        else:
                            parent_node.set_node_selected_parent(selected)
                return True
            return callback_node
        self.walk_node_tree(callback, persist=persist)
        return persist['node_found']

    def get_node(self, selector):
        """Get node from tree using selector

        Args:
            selector (str): A selector, node names joined by periods.

        Returns:
            The node-like object that matched the selector or None
            if not found."""
        persist = {
            'found_node': None
        }

        def callback(callback_node, callback_selector, *args, persist):
            if callback_selector == selector:
                persist['found_node'] = callback_node
                return True
            return callback_node
        self.walk_node_tree(callback, persist=persist)
        return persist['found_node']

    def add_node(self, node, parent_selector=None):
        """Appends a node to the tree root or a child node via a selector.

        Args:
            node: A node-like object
            parent_selector (str): Optional, the selector of the parent node
                the node new should be added to (default is None)

        Returns:
            bool: True if node was added, False if the parent node
                specified could not be found.

        Raises:
            ValueError: Raised if a non-node object was passed
            NodeDuplicateNameError: Raised if a node with the same
                name already exists"""
        persist = {
            'node_added': False
        }
        if not parent_selector:
            self.append(node)
            return True

        def callback(callback_node, callback_selector, *args, persist):
            if callback_selector == parent_selector:
                callback_node.get_node_children().add_node(node)
                persist['node_added'] = True
                return True
            return callback_node
        self.walk_node_tree(callback, persist=persist)
        return persist['node_added']

    def replace_node(
        self, selector, node, replace_nodes=True,
        merge_children=True, ignore_selector_errors=True
    ):
        """Alias for merge_tree accepting a single member"""
        self.merge_tree(
            [
                {
                    selector: node
                },
            ],
            replace_nodes=replace_nodes,
            merge_children=merge_children,
            ignore_selector_errors=ignore_selector_errors
        )

    def remove_node(self, selector):
        """Remove a node from the tree via a selector

        Args:
            selector (str): A selector, names joined by periods

        Returns:
            The node-like object found or None if the selector couldn't find
            the node."""
        node_chain = self.get_node_chain(selector)
        node_chain_length = len(node_chain)
        if node_chain:
            if node_chain_length == 1:
                self.remove(node_chain[0])
            else:
                node_chain[node_chain_length -
                           2].remove(node_chain[node_chain_length - 1])
        return node_chain[len(node_chain) - 1]

    def get_node_selector(self, node):
        """Get a selector for the given node relative to this tree root.

        Args:
            node: A node-like object

        Returns:
            str: The selector for the given node or None if not found."""
        persist = {
            'node_selector': None
        }

        def callback(callback_node, callback_selector, *args, persist):
            if node == callback_node:
                persist['node_selector'] = callback_selector
                return True
            return callback_node
        self.walk_node_tree(callback, persist=persist)
        return persist['node_selector']

    def get_node_chain(self, selector):
        """Fetch a node and it's parents in a depth descending list using a selector

        Args:
            selector (str): A selector, names joined by periods

        Returns:
            list: A list of node-like objects from lowest depth -> deepest,
                or None if node not found"""
        persist = {
            'node_chain': None
        }

        def callback(
            callback_node,
            callback_selector,
            parent_nodes,
            *args,
            persist
        ):
            if callback_selector == selector:
                persist['node_chain'] = parent_nodes.copy() + [callback_node, ]
                return True
            return callback_node
        self.walk_node_tree(callback, persist=persist)
        return persist['node_chain']

    def contains_selector(self, selector):
        """Searches node tree to see if selector is valid

        Args:
            selector (str): A selector, names joined by periods.

        Returns:
            bool: True if node was found, False if not"""
        return self.get_node(selector) is not None

    def contains_node(self, node):
        """Searches node tree to see if node is contained within it

        Args:
            node: A node-like object

        Returns:
            bool: True if node was found, false if not."""
        return self.get_node_selector(node) is not None

    def sort_by_node_weight(self, descending=True):
        """Sorts current tree and all its children by node weight

        Args:
            descending (bool): Optional, if True orders highest to lowest,
                False lowest to highest (default is False)"""
        sorted_self = sorted(
            self, key=lambda x: x.get_node_weight(),
            reverse=not descending
        )
        self.clear()
        for node in sorted_self:
            self.append(node)

        def sort_children(node, node_selector, *args, **kwargs):
            node.set_node_children(
                sorted(
                    node.get_node_children(),
                    key=lambda x: x.get_node_weight(),
                    reverse=not descending
                )
            )
            return node
        self.walk_node_tree(sort_children)

    def walk_node_tree(self, callback, *args, **kwargs):
        """Walks through entire node tree and modifies tree nodes based
        on a given callback's return value

        Cycle through every node in the entire tree, passing the node and
        relevant data to the callbackprovided.

        Callback return values are:

        True - The tree walk will stop and assumes the desired outcome has
            been reached, this is mostly used for efficiency.
        False or falsey value - The node will be removed from the tree,
            it's children won't be processed.
        Node-like object or other value - The node will be replaced with the
            one given, note this does not 'merge' the nodes so any children
            of the original will be removed.

        Args:
            callback: A callable function, will be passed node, node_selector,
                parent_nodes and parent_selector args, in addition to any
                additions args specified.
            *args: Additional args to be passed to the given callback for each
                node
            **kwargs: Additional keywords args to passed to the given callback"""
        persist = {
            'remove_nodes': [],
            'stop_walking': False
        }

        def recursive_func(
            node_tree,
            persist,
            callback,
            callback_args,
            callback_kwargs,
            parent_selector=None,
            parent_nodes=None
        ):
            if persist['stop_walking']:
                return
            parent_nodes = parent_nodes or []
            for index, node in enumerate(node_tree):
                node_selector_parent = (
                    f"{parent_selector}."
                    if parent_selector
                    else ''
                )
                node_selector = f"{node_selector_parent}{node.get_node_name()}"
                new_node = callback(
                    node,
                    node_selector,
                    parent_nodes,
                    parent_selector,
                    *callback_args,
                    **callback_kwargs
                )
                if new_node is True:
                    persist['stop_walking'] = True
                    break
                if not new_node:
                    persist['remove_nodes'].append(node)
                    continue
                node_tree[index] = new_node
                if (
                    node not in persist['remove_nodes']
                    and new_node.has_node_children()
                ):
                    recursive_func(
                        new_node.get_node_children(),
                        persist,
                        callback,
                        callback_args,
                        callback_kwargs,
                        node_selector,
                        parent_nodes.copy() + [new_node]
                    )
        recursive_func(self, persist, callback, args, kwargs)
        if len(persist['remove_nodes']) > 0:
            for node in persist['remove_nodes']:
                self.remove_node(node)

    def append(self, value):
        """Override of the 'append' function with a check for duplicate names in nodes.

        Args:
            value: A node-like object

        Returns:
            bool: True if node was found, false if not.

        Raises:
            ValueError: Raised if the given object is not a node
            NodeDuplicateNameError: Raised if a node of the same name
                already exists."""
        if not hasattr(value, 'get_node_name'):
            raise ValueError(
                'Appended values must have "get_node_name" member')
        for node in self:
            if node.get_node_name() == value.get_node_name():
                raise NodeDuplicateNameError(
                    'Cannot append node, a node with duplicate'
                    + f' name "{node.get_node_name()}" exists.'
                )
        return super().append(value)

    def get_selector_list(self):
        """Get a list of all selectors in this tree

        Returns:
            list: A list of selector strings"""
        persist = {
            'list': []
        }

        def callback(
            callback_node, callback_selector,
            *arg, persist, **kwargs
        ):
            persist['list'].append(callback_selector)
            return callback_node
        self.walk_node_tree(callback, persist=persist)
        return sorted(persist['list'])

    def get_selector_dict(self):
        """Get a dict of nodes keyed by their selector

        Returns:
            dict: A dict of nodes keyed by selector"""
        persist = {
            'dict': {}
        }

        def callback(
            callback_node, callback_selector,
            *arg, persist, **kwargs
        ):
            persist['dict'][callback_selector] = callback_node
            return callback_node
        self.walk_node_tree(callback, persist=persist)
        return persist['dict']

    def __str__(self):
        """Override of built-in method, displays node tree
        in a string formatted way.

        Returns:
            A string representation of the tree"""
        persist = {
            'string': ''
        }

        def callback(
            callback_node, callback_selector,
            parent_nodes, *args, persist
        ):
            persist['string'] = "%s%s" % (
                persist['string'],
                "%s%s%s%s%s" % (
                    "\n" if persist['string'] else '',
                    ''.rjust(len(parent_nodes), '-') if parent_nodes else '',
                    ">" if parent_nodes else '',
                    " " if parent_nodes else '',
                    str(callback_node)
                )
            )
            return callback_node
        self.walk_node_tree(callback, persist=persist)
        return persist['string']

    def merge_tree(
        self, node_tree, replace_nodes=True,
        merge_children=True, ignore_selector_errors=True
    ):
        """Recursively merges a node tree or list into this tree.

        Merges two trees together using the parameters specified below,
        however, you can also modify the tree using dicts keyed by selectors.

        For example to modify the children of a node without redefining
        the parent nodes do:

        [
            {
                'parent.child.subchild' : [
                    ChildNode(),
                    ChildNode()
                ]
            }
        ]

        This can be useful in menus where you want to add an extra option to
        another section that isn't being fully defined here, for example,
        adding a 'User Profile' menu item from the 'profiles' app to the
        menu created in the 'users' app.

        You can provide the following values in a dict within the tree:
        - A tree or listable object, this will be merged with the selected
            nodes children
        - Provide a node-type object to replace/merge the node selected
        - Provide a None value which will remove that node and it's children

        If a node does not exist, it can not be modified so will raise an
        exception if ignore_selector_errors is set to False.

        However by default such errors are ignored as for example if you
        wanted to remove a menu, but another app has already done that
        there's no point throwing an error. Additionally if a menu has been
        hidden/removed, there's no point adding children to it or modifying
        it's parameters as the parent menu has been deliberately removed at
        some stage.

        Args:
            node_tree (list): A node tree or standard list of nodes to merge
            replace_nodes (bool): If True will replace a node with the same
                name with the new one, if False keeps the original node
            merge_children (bool): If True if a matching node is found will
                combine the children of both nodes, if False the original
                node of either the new or existing node will be used
                (see replace_node param) (default is True)
            ignore_selector_errors (bool): If a selector dict is provided and
                contains a non-existent selector, True throw an exception,
                False ignore and skip. (default is True)

        Raises:
            NodeSelectorError: Raised if ignore_selector_errors is False and a
                non-existent selector is specified"""
        def do_merge(menu_a, menu_b, replace_nodes, merge_children):
            for node_b in menu_b:
                if isinstance(node_b, dict):
                    for selector, sub_menu_b in node_b.items():
                        if sub_menu_b is None:
                            menu_a.remove_node(selector)
                        elif hasattr(sub_menu_b, 'get_node_children'):
                            node_chain = menu_a.get_node_chain(selector)
                            if node_chain:  # Can't modify non-existent node
                                node_chain[-1:][0].set_node_name(
                                    sub_menu_b.get_node_name())
                                if len(node_chain) > 1:
                                    do_merge(
                                        node_chain[-2:][0].get_node_children(),
                                        [sub_menu_b],
                                        replace_nodes,
                                        merge_children
                                    )
                                else:
                                    do_merge(
                                        menu_a,
                                        [sub_menu_b],
                                        replace_nodes,
                                        merge_children
                                    )
                            elif not ignore_selector_errors:
                                raise NodeSelectorError(
                                    f'Cannot merge path selector {selector} as'
                                    + ' node does not exist.'
                                )
                        else:
                            node_a = menu_a.get_node(selector)
                            if node_a:
                                do_merge(node_a.get_node_children(
                                ), sub_menu_b, replace_nodes, merge_children)
                    continue
                node_found = False
                for index_a, node_a in enumerate(menu_a):
                    if node_a.get_node_name() == node_b.get_node_name():
                        other_children = node_b.get_node_children()
                        if replace_nodes:
                            menu_a[index_a] = node_b
                            other_children = node_a.get_node_children()
                        if merge_children:
                            do_merge(menu_a[index_a].get_node_children(
                            ), other_children, replace_nodes, merge_children)
                        node_found = True
                        break
                if not node_found:
                    menu_a.append(node_b)
        do_merge(self, node_tree, replace_nodes, merge_children)


class NodeTree(NodeTreeMixin, list):
    """A list that uses the NodeTreeMixin class"""


class NodeMixin(object):
    """A mixin to create a 'node-like' object"""

    def __init__(
        self, *args, node_name='unknown', node_selected=False,
        node_selected_parent=False, node_weight=1, node_children=None,
        node_tree_class=NodeTree, **kwargs
    ):
        """Initialises and sets up attributes on the parent object to make it node-like

        Args:
            *args: The standard args for the parent class, if any
            node_name (str): The name of this node (default is 'unknown')
            node_selected (bool): If the node is set as selected(default is
                False)
            node_selected_parent (bool): If the node is a selected parent (
                default is False)
            node_weight (int): The order weight of the node (default is 1)
            node_children (list): A list of initial child nodes (default is
                None)
            node_tree_class (class): The class to be used for the children
                list of this node (default NodeTree)"""
        if hasattr(super, '__init__'):
            super().__init__(*args, **kwargs)
        node_children = node_children or []
        self.node_tree_class = node_tree_class
        self.node_name = node_name
        self.node_selected = node_selected
        self.node_selected_parent = node_selected_parent
        self.node_weight = node_weight
        self.node_children = self.get_node_tree_class()(
            node_children) or self.get_node_tree_class()()

    def get_node_tree_class(self):
        """Get the configured class used for this node tree

        Returns:
            A NodeTree type class"""
        return self.node_tree_class

    def set_node_tree_class(self, tree_class):
        """Set the configured class  to be used to create child
        trees.

        Args:
            tree_class: The NodeTree type class to use"""
        self.node_tree_class = tree_class
        self.node_children = tree_class(list(self.node_children))

    def is_node_selected(self):
        """Whether or not node is set as being 'selected'

        Returns:
            bool: True if selected, False if not"""
        return self.node_selected

    def set_node_selected(self, is_selected):
        """Set node as being 'selected'

        Args:
            is_selected (bool): True to set as selected, False if not"""
        self.node_selected = is_selected

    def is_node_selected_parent(self):
        """Whether or not node is set as being a 'selected parent'

        A selected parent is a node than is considered to be containing
        a 'selected' node at some depth in its child heirarchy.

        Returns:
            bool: True if a selected parent, False if not"""
        return self.node_selected_parent

    def set_node_selected_parent(self, is_selected_parent):
        """Set node as being a 'selected parent' (contains a 'selected' node
        in some depth)

        Args:
            is_selected_parent: True if selected parent, False if not"""
        self.node_selected_parent = is_selected_parent

    def get_node_name(self):
        """Get the identifying node 'name' string for this node

        Returns:
            str: The name of the node"""
        return self.node_name

    def set_node_name(self, name):
        """Set node's name

        Args:
            name (str): The new name of the node"""
        self.node_name = name

    def get_node_children(self):
        """Get the direct child descendants of this node

        Returns:
            A NodeTree type list object containing the child nodes."""
        return self.node_children

    def set_node_children(self, node_list):
        """Set the node children for this node.

        This method does not directly replace the nodes NodeTree object but
        populates it with the nodes in the given list.

        Args:
            node_list: A node tree like object or list to replace the current
                children with"""
        self.node_children.clear()
        for node in node_list:
            self.node_children.append(node)

    def get_node_weight(self):
        """Get the ordering weight for this node

        Returns:
            int: A number defining this nodes weight"""
        return self.node_weight

    def set_node_weight(self, weight):
        """Set the ordering weight for this node

        Args:
            weight (int): The weight of this node"""
        self.node_weight = weight

    def get_child_node(self, name):
        """Get a child node by name

        Args:
            name (str): The name of the node to retrieve

        Returns:
            A node-like object or None if no node found."""
        for node in self.get_node_children():
            if node.get_node_name() == name:
                return node
        return None

    def get_child_node_index(self, name):
        """Get the numeric index of the given child within this node's children tree

        Args:
            name (str): The name of the node to find

        Returns:
            int: The index of the node or None if not found"""
        for index, node in enumerate(self.get_node_children()):
            if node.get_node_name() == name:
                return index
        return None

    def has_node_children(self):
        """Whether or not node has child nodes

        Returns:
            bool: True if has children, False if not"""
        return len(self.get_node_children()) > 0

    def __str__(self):
        """Override of built-in method, returns node name and status

        Returns:
            str: A string representation of the node with its attributes"""
        if not self.get_node_name():
            return 'unknown'
        return "%s/%s%s%s" % (
            self.__class__.__name__,
            self.get_node_name(),
            " SELECTED" if self.is_node_selected() else '',
            " SELECTED_PARENT" if self.is_node_selected_parent() else ''
        )


class Node(NodeMixin):
    """ A direct descendant of the NodeMixin class """


class TemplateNode(Node):
    """A renderable node that uses a template and context like a view"""

    template_name = None
    """The template used to render this node"""

    request = None
    """A local variable for storing the incoming request"""

    def get_context_data(self):
        """Get context to use for rendering node template

        Returns:
            dict: A dict containing context variables"""
        return {
            'node': self
        }

    def get_template_name(self):
        """Get the template path name to use to render this node

        Returns:
            str: The template path to use to render the node

        Raises:
            NotImplementedError: Raised if no template_name attribute was
                specified or method was not overridden"""
        if not self.template_name:
            raise NotImplementedError(
                'template_name must be specified or '
                + 'get_template_name overridden.'
            )
        return self.template_name

    def render(self, context=None):
        """Get context to use for rendering node template

        Args:
            context (dict): The existing context (default is None)

        Returns:
            str: The rendered node"""
        self.context = context or {}
        self.request = self.context.get('request')
        return render_to_string(
            self.template_name,
            context=self.get_context_data(),
            request=self.request
        )
