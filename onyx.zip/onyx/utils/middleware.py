"""General use middleware classes"""

from django.http import HttpResponseForbidden
from django.utils.deprecation import MiddlewareMixin


class RestrictedPathMiddleware(MiddlewareMixin):
    """A middleware to restrict access to a certain url path
    depending on various user conditions. This can be used in
    place of decorators such as 'login_required' to restrict
    users."""

    url_paths = []
    """A list of paths that this middleware will restrict based on this
    class's rules."""

    url_path_exceptions = []
    """A list of exceptions to the url_paths, for example if you want
    to make public a path that is contained with a restricted path."""

    staff_only = False
    """Whether the user viewing must be a staff member"""

    superuser_only = False
    """Whether the user viewing must be a superuser"""

    anonymous_only = False
    """Whether the user must be anonymous to view"""

    def is_user_permitted(self, user):
        """A method that determines if the user given matches
        the criteria. This method can be extended to add custom
        logic.

        Args:
            user: A Django user model

        Returns:
            True if user passes tests, otherwise False"""
        if not user.is_anonymous:
            if self.anonymous_only:
                return False
            if self.staff_only and not user.is_staff:
                return False
            if self.superuser_only and not user.is_superuser:
                return False
            return True
        return False

    def is_request_permitted(self, request):
        """Wrapper function to test if the incoming request
        is allowed to view it.

        Args:
            request: A Django request object

        Returns:
            True if passes, otherwise False"""
        path = request.get_full_path()
        is_restricted_path = self.is_restricted_path(path)
        if (
            not is_restricted_path or (
                is_restricted_path and self.is_exception_path(path)
            )
        ):
            return True
        if self.is_user_permitted(request.user):
            return True
        return False

    def get_restricted_paths(self):
        """Getter for restricted paths

        Returns:
            A list of restricted paths"""
        return self.url_paths

    def is_restricted_path(self, path):
        """Checks if the given path is restricted

        Args:
            path: The URL path to check

        Returns:
            True if restricted otherwise False"""
        return any(
            path.startswith(restricted_path)
            for restricted_path in self.get_restricted_paths()
        )

    def get_exception_paths(self):
        """Getter for paths that are exceptions to the
        rules.

        Returns:
            A list of exception paths"""
        return self.url_path_exceptions

    def is_exception_path(self, path):
        """Checks if the given path is an exception
        to the rules.

        Args:
            path: The URL path to check

        Returns:
            True if an exception otherwise False"""
        return any(
            path.startswith(unrestricted_path)
            for unrestricted_path in self.get_exception_paths()
        )

    def get_restricted_response(self, request):
        """Method for retrieving the correct response to
        this forbidden request

        Args:
            request: The incoming django request
        
        Returns:
            A Django response object."""
        return HttpResponseForbidden()

    def process_request(self, request):
        """Primary method of handling the incoming request, applies
        the rules of this class and returns the restricted response
        if it fails the tests.

        Args:
            request: The incoming django request
        
        Returns:
            A django response object or None if request is
            free to continue."""
        if not self.is_request_permitted(request):
            return self.get_restricted_response(request)
