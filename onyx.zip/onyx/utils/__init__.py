"""Various utilities for Django, python and others."""

import json
import importlib

from django.contrib.sites.shortcuts import get_current_site
from django.db.models import Model

from onyx import app_settings


def external_url(request):
    """Get the site's fully qualified url using
    using the request context.

    Args:
        request: The request context

    Returns:
        The fully qualified url of the site."""
    site = get_current_site(request)
    protocol = 'https' if request.is_secure() else 'http'
    return f"{protocol}://{site.domain}"


def external_url_approximate(host=None, secure=True, port=None):
    """Aproximate the site's fully qualified url using
    using the project's settings.

    Args:
        host: Optional, allows you to manually specify a value for hostname
        secure: Defaults to True, https vs. http
        port: Optional, allows you to manually specify a value for port

    Returns:
        The fully qualified url of the site."""
    if not host:
        host = app_settings.APP_HOSTNAME
    protocol = 'https' if secure else 'http'
    port = f':{port}' if port else ''
    return f"{protocol}://{host}{port}"


def get_real_ip(request):
    """Get a user's 'real' ip address i.e. pick up
    on HTTP_X_FORWARDED_FOR header. If no header is found
    defaults to REMOTE_ADDR.

    Args:
        request: The incoming django request

    Returns:
        The ip string discovered."""
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0]
    else:
        ip = request.META.get('REMOTE_ADDR')
    return ip


def import_dotted_path(path):
    """Programatically import a python module via a
    path string i.e. onyx.apps.moo.AClass

    Args:
        path: The path to import

    Raises:
        ModuleNotFoundError: When module is not found
        LookupError: When path is invalid

    Returns:
        The imported module, class or object"""
    result = None
    try:
        result = importlib.import_module(path)
    except (ModuleNotFoundError, LookupError):
        path_bits = path.rsplit('.', 1)
        if len(path_bits) != 2:
            raise
        return getattr(
            importlib.import_module(path_bits[0]),
            path_bits[1]
        )
    else:
        return result


def dotted_path_exists(path):
    """Check if a pythong path exists

    Args:
        path: The path to test

    Returns:
        True if exists, False if not"""
    try:
        import_dotted_path(path)
    except (ModuleNotFoundError, LookupError, AttributeError):
        return False
    else:
        return True


def convert_to_json_value(value):
    """A JSON conversion function that attempts
    to convert a value to JSON, if it fails but is
    a model, returns that model's id, otherwise convert
    the value to string via str()

    Args:
        value: The value to convert to a JSON safe value

    Returns:
        The json safe value (not json itself)"""
    if isinstance(value, (dict, list)):
        return to_json_safe_object(value)
    try:
        json.dumps(value)
    except TypeError:
        if isinstance(value, Model):
            return value.id
        else:
            return str(value)
    return value


def to_json_safe_object(obj):
    """Convert an object to something that
    can be stored in a JSON object.

    Args:
        obj: The object to convert

    Returns:
        A dict that can safely be serialized to JSON"""
    if isinstance(obj, dict):
        json_values = {}
        for key, value in obj.items():
            json_values[key] = convert_to_json_value(value)
        return json_values
    else:
        json_list = []
        for value in obj:
            json_list.append(
                convert_to_json_value(value)
            )
        return json_list
