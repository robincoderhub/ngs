"""A collection of classes to aid in creating a basic API"""

import json

from onyx.utils.conditionals import validate_conditions
from onyx.utils.api.exceptions import APIException


def sanitise_path(path):
    """Function to ensure all api paths are
    formatted the same way. No slash at start or
    end i.e. user/manage/update_profile

    Args:
        path: The path to reformat

    Returns:
        The reformatted path"""
    if path.startswith('/'):
        path = path[1:]
    if path.endswith('/'):
        path = path[:len(path) - 1]
    return path


class APIResponse(object):
    """An general api response object

    Args:
        message: Defaults to 'OK', a readable response message
        code: A numeric representation of the response type, typically
            copies http codes i.e. 404/200. But can be a custom specification
        data: A dict of data to return."""

    def __init__(self, message='OK', code=200, data=None):
        self.message = message
        self.code = code
        self.data = data or {}

    def get_message(self):
        """Getter for this response's message

        Returns:
            A response message string"""
        return self.message

    def is_success(self):
        """Whether or not this response is a success response.
        By default the response will determine this using the
        response's status code (200).

        Returns:
            True if success or False if error."""
        return (self.get_code() >= 200 and self.get_code() < 300)

    def get_code(self):
        """Get the response code for this response

        Returns:
            An integer repressenting the status."""
        return self.code

    def get_data(self):
        """Get additional data sent back by this response

        Returns:
            A dict of data"""
        return self.data

    def to_object(self):
        """Converts this class into a dict

        Returns:
            A dict containing all attributes of the class"""
        return {
            'success': self.is_success(),
            'message': self.get_message(),
            'code': self.get_code(),
            'data': self.get_data()
        }

    def to_json(self):
        """Converts this class into a JSON string using
        the to_object method.

        Returns:
            A JSON string"""
        return json.dumps(self.to_object())


class APIAction(object):
    """An API 'action', a view for the API

    Args:
        authenticated: Defaults to False, whether the user should be
            authenticated.
        permissions: Optional, a conditional object of permissions user must
            have.
        staff_only: Defaults to False, whether or not user must be staff
        superuser_only: Defaults to False, whether or not user must be
            a superuser"""

    authenticated = False
    """Whether the accessing user must be authenticated"""

    permissions = None
    """The permissions a user must have"""

    staff_only = False
    """Whether or not user must be a staff member"""

    superuser_only = False
    """Whether or not user must be a superuser"""

    def __init__(
        self, authenticated=False, permissions=None,
        staff_only=False, superuser_only=False
    ):
        self.authenticated = authenticated
        self.permissions = permissions
        self.staff_only = staff_only
        self.superuser_only = superuser_only

    def is_authenticated(self):
        """Getter for whether or not user must be
        authenticated

        Returns:
            True or False"""
        return self.authenticated

    def get_permissions(self):
        """Get permissions conditionals if set

        Returns:
            Conditional objects or None"""
        return self.permissions

    def is_staff_only(self):
        """Whether or not accessing user must be a staff member

        Returns:
            True or False"""
        return self.superuser_only

    def is_superuser_only(self):
        """Whether or not accessing user must be a supruser

        Returns:
            True or False"""
        return self.superuser_only

    def authenticate(self, method, user):
        """Authentication for this action, this can be extended to
        add custom logic.

        Args:
            method: The method user is accessing the action via
            user: The user accessing this action

        Returns:
            True if authenticated or False if failed checks"""
        if (
            self.authenticated
            or self.permissions
            or self.staff_only
            or self.superuser_only
        ):
            if not user or user.is_anonymous:
                return False
            if self.staff_only and not user.is_staff:
                return False
            if self.superuser_only and not user.is_superuser:
                return False
            if self.permissions:
                return validate_conditions(
                    lambda x, y: x.has_perm(y),
                    user,
                    self.permissions
                )
        return True

    def execute(self, method, options={}, data={}, files={}, user=None):
        """Execute this action, by default will check if this class has a
        method that matches a lowercase version of the method i.e. 'get()'

        Args:
            method: The method this action is being accessed by
            options: Optional, a dict of arguments being passed to the
                action. Usually GET params
            data: Optional, data being passed to this action (usually POST)
            files: Optional, a dict of file objects being passed
            user: Optional, the user accessing.

        Raises:
            APIException: Raises if method is not allowed

        Returns:
            An APIResponse object"""
        method = method.lower()
        if getattr(self, method, None):
            return getattr(self, method)(options, data, files, user)
        raise APIException("Request method not allowed", 403)

    def response(self, message='OK', code=200, data=None):
        """Class shortcut for returning an APIResponse object

        Args:
            message: Defaults to 'OK', the response message
            code: The status code of the response
            data: Any additional data being passed backk

        Returns:
            An APIResponse object"""
        return APIResponse(
            message=message,
            code=code,
            data=data or {}
        )


class API(object):
    """A base class for an API

    Args:
        actions: Optional, a dict of api paths -> ApiAction objects"""

    def __init__(self, actions=None):
        self.actions = {}
        if actions:
            for key, action in actions.items():
                self.register_action(key, action)

    def register_action(self, path, action):
        """Register an 'action' callable at a particular path

        Args:
            path: The path to register the callable at
            action: An APIAction instance to handle the request

        Raises:
            ValueError: If a path already is registered"""
        sane_path = sanitise_path(path)
        if self.actions.get(sane_path):
            raise ValueError(
                f'An action is already registered for path {sane_path}'
            )
        self.actions[sane_path] = action

    def unregister_action(self, path):
        """Unregister an action from a path

        Args:
            path: The path to unregister

        Returns:
            The action that was attached or None."""
        sane_path = sanitise_path(path)
        action = self.actions.get(sane_path)
        del self.actions[sane_path]
        return action

    def get_action(self, path):
        """Get an action for the given path

        Args:
            path: The path to look up

        Returns:
            An APIAction object or None if none found"""
        sane_path = sanitise_path(path)
        return self.actions.get(sane_path)

    def is_action_registered(self, path):
        """Is a path registered to an action

        Args:
            path: The path to check

        Returns:
            True if an action is registered for that path,
            False otherwise."""
        sane_path = sanitise_path(path)
        return self.get_action(sane_path) is not None

    def execute_action(
        self, method, path, options=None,
        data=None, files=None, user=None
    ):
        """Execute an action on this api and get an API response

        Args:
            method: The method you are acessing this action
            path: The path being accessed
            options: Optional, arguments passed to this action (usually GET)
            data: Optional, data passed to this action (usually POST)
            files: A dict of files passed to this api action
            user: The authenticated (or not) user accessing this action

        Returns:
            An APIResponse object"""
        sane_path = sanitise_path(path)
        action = self.get_action(sane_path)
        if not action:
            return APIResponse(
                'Action not found',
                404
            )
        try:
            if not action.authenticate(method, user):
                return APIResponse(
                    "Permission denied.",
                    403
                )
            response = action.execute(
                method=method,
                options=options or {},
                data=data or {},
                files=files or {},
                user=user
            )
            if not isinstance(response, APIResponse):
                raise ValueError(
                    f'Action {path} did not return a valid APIResponse object.'
                )
            return response
        except APIException as e:
            return APIResponse(
                e.get_message(),
                e.get_code()
            )
