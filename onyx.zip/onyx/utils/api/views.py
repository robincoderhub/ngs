"""API related views"""

from django.http import Http404, JsonResponse
from django.views.generic import View


class APIView(View):
    """A view design to serve an API object via a Django
    view

    Args:
        *args: Inherited arguments
        api: Defaults to None, the Api object to serve
        **kwargs: Inherited keyword arguments"""

    api = None
    """The API object to serve"""

    def __init__(self, *args, api=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.api = api or self.api

    def get_api(self):
        """Get the API attached to this view

        Raises:
            NotImplementedError: Thrown if no API has been specified

        Returns:
            An API object"""
        if not self.api:
            raise NotImplementedError(
                "Either the 'api' attribute must be set or get_api overridden"
            )
        return self.api

    def dispatch(self, request, path):
        """Override handles the incoming request using the attached
        API object.

        Args:
            request: The django request object
            path: The path being accessed

        Raises:
            Http404: If an action is not found.

        Returns:
            A Django JsonResponse object"""
        api = self.get_api()
        if not api.is_action_registered(path):
            raise Http404()
        response = self.get_api().execute_action(
            request.method,
            path,
            options=request.GET.copy(),
            data=request.POST.copy(),
            files=request.FILES.copy(),
            user=request.user
        )
        return JsonResponse(response.to_object())
