"""API related exceptions"""


class APIException(Exception):
    """Generic use API exception class,
    can be used to create an error APIResponse
    object.

    Args:
        message: The error message
        code: Defaults to 500, the status code of this exception"""

    def __init__(self, message, code=500):
        super().__init__(message)
        self.message = message
        self.code = code

    def get_message(self):
        """Get the error message

        Returns:
            The error string"""
        return self.message

    def get_code(self):
        """Get the status code of this error

        Returns:
            The error code"""
        return self.code
