"""A module of API-related utilities"""
