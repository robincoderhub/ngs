"""This module contains code related to django_tables2

TODO:
    - Probably worth renaming this to django_tables2"""
