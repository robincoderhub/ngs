"""Columns for use with django_tables2"""

from django_tables2 import Column


class JSONAttributeColumn(Column):
    """A column type to display a sub attribute of
    a Model's postgres JSONField.

    Args:
        field_name: The name of the attribute to display
        *args: Inherited arguments
        **kwargs: Inherited keyword arguments

    Example:
        JSONAttributeColumn(
            accessor='my_json_field', # The field on the model
            field_name='email' # The attribute in the JSON
        )

    TODO:
        - Probably worth changing this to 'attribute_name' for
        clarity."""
    def __init__(self, field_name, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.field_name = field_name
        self.orderable = False

    def render(self, value):
        """Render this column

        Args:
            value: The value to render, this class fetches out
                the JSON attribute from this value.

        Returns:
            The string value to display"""
        real_value = value.get(self.field_name)
        if not real_value:
            return '--'
        return real_value
