"""General use email backends for django"""

import fnmatch

from django.core.mail.backends.smtp import EmailBackend
from django.conf import settings


class PermittedRecipientsEmailBackend(EmailBackend):
    """An email bakend that filters out email addresses that are not
    permitted by the settings. This is typically used in testing
    sites to prevent emails being sent to 'real' email addresses during
    testing.

    This uses the EMAIL_PERMITTED_RECIPIENTS settings variable to determine
    patterns that are acceptable."""

    def is_address_permitted(self, email_address):
        """Test if a given email address is acceptable to send to.

        Args:
            email_address: The email address to be tested

        Returns:
            True if acceptable, false if not"""
        if not hasattr(settings, 'EMAIL_PERMITTED_RECIPIENTS'):
            return True

        # Get 'email' part of address
        email_parts = email_address.strip().split()
        email = email_parts[len(email_parts) - 1]\
            .replace('<', '')\
            .replace('>', '')

        # Check if it matches pattern
        recipient_patterns = settings.EMAIL_PERMITTED_RECIPIENTS
        for pattern in recipient_patterns:
            filtered = fnmatch.filter([email], pattern)
            if len(filtered) > 0:
                return True

        return False

    def send_messages(self, email_messages):
        """Extended send_messages method that filters out unacceptable
        email addresses in the email message.

        Args:
            email_messages: A list of EmailMessage objects to send

        Returns:
            The return value of the super class TODO clarify"""
        filter_attributes = ('to', 'cc', 'bcc')
        for email_message in email_messages:
            for attribute_name in filter_attributes:
                filtered_addresses = [
                    email_address
                    for email_address in getattr(email_message, attribute_name)
                    if self.is_address_permitted(email_address)
                ]
                setattr(email_message, attribute_name, filtered_addresses)
        return super().send_messages(email_messages)
