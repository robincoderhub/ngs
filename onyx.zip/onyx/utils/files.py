"""General use file utilities"""

import os
import base64

from django.conf import settings


def open_static_file(file_path, *args, **kwargs):
    """Shortcut function that opens a static file
    using a static relative file path.

    Args:
        file_path: The path relative to the static root
        *args: Arguments to pass to python 'open' function
        **kwargs: Keyword arguments to pass to python 'open' function

    Returns:
        A python file handle"""
    full_file_path = os.path.join(settings.STATIC_ROOT, file_path)
    return open(full_file_path, *args, **kwargs)


def read_static_file(file_path, *args, **kwargs):
    """Reads and returns the contents of a static file based on
    a static relative file path.

    Args:
        file_path: The path relative to the static root
        *args: Arguments to pass to python 'open' function
        **kwargs: Keyword arguments to pass to python 'open' function

    Returns:
        Contents of the file"""
    contents = None
    with open_static_file(file_path, *args, **kwargs) as static_file:
        contents = static_file.read()
    return contents


def open_media_file(file_path, *args, **kwargs):
    """Shortcut function that opens a media file
    using a media relative file path.

    Args:
        file_path: The path relative to the media root
        *args: Arguments to pass to python 'open' function
        **kwargs: Keyword arguments to pass to python 'open' function

    Returns:
        A python file handle"""
    full_file_path = os.path.join(settings.MEDIA_ROOT, file_path)
    return open(full_file_path, *args, **kwargs)


def read_media_file(file_path, *args, **kwargs):
    """Reads and returns the contents of a media file based on
    a media relative file path.

    Args:
        file_path: The path relative to the media root
        *args: Arguments to pass to python 'open' function
        **kwargs: Keyword arguments to pass to python 'open' function

    Returns:
        Contents of the file"""
    contents = None
    with open_media_file(file_path, *args, **kwargs) as media_file:
        contents = media_file.read()
    return contents


def base64_encode_file(file_path):
    """Base64 encode a file and return the resultant string

    Args:
        file_path: The full file path to the file

    Returns:
        A base64 encoded string of the file"""
    encoded_data = None
    with open(file_path, 'rb') as target_file:
        encoded_data = base64.b64encode(target_file.read())
    return encoded_data


def get_base64_data_uri(file_path, content_type):
    """Base64 encode a file and return the resultant string
    as a data uri

    Example output:
        data:image/png;base64,iVBORw0...

    Args:
        file_path: The full file path to the file
        content_type: The content data type i.e. 'image/png'

    Returns:
        A base64 encoded uri of the file"""
    encoded_file = base64_encode_file(file_path)
    return f'data:{content_type};base64,{encoded_file}'
