"""Conditional specification that allows 'OR' statements joined with
the bitwise | character

Examples:
    ```
    def validator(user, value):
        return user.has_perm(value)

    validate_conditions(
        validator,
        user,
        'user.view_user',
        OR('user.add_user) | OR('user.change_user')
    )
    ```
    The above will check if user has 'view' permission and either 'add'
    or 'change' permissions

    AND statements are just lists or additional params ['user.view_user', ...]
    ```
    validate_conditions(
        validator,
        user,
        ['user.view_user', 'user.add_user'],
        'user.change_user'
    )
    ```
    The above must have all 3 permissions.

    The OR class can be passed other P objects, lists, or values."""


class ORList(list):
    """A list type to differentiate a list of
    'or' conditional values vs. a regular list."""
    pass


class OR(object):
    """An operator that produces an ORList from a bitwise
    OR separated list of values.

    Args:
        conditional_value: The conditional value to check"""

    def __init__(self, conditional_value):
        self.conditional_value = conditional_value

    def __or__(self, other):
        """Override of the bitwise OR operator to combine
        values into an ORList to indicate they are 'either or'
        conditionals.

        Args:
            The other value to combine with"""
        return ORList(
            [
                self.conditional_value,
                other.conditional_value if isinstance(other, OR) else other
            ]
        )


def validate_conditions(validator, variable, *args):
    """Validate a conditonal 'object' (a combination of ORList's, lists or values)
    against a function that determines if that condition is met.

    Example:
        ```
        def validate_as_number(value, number):
            return value == number

        validate_conditions(
            validate_as_number,
            6,
            Or(5) | OR(3),
        ) # returns false as 6 is neither 5 or 3
        ```

    Args:
        validator: The function to test values with, must by my_function(value, *args)
        variable: The variable to test
        *args: Conditional values to test against the variables

    Returns:
        True if conditions are met, False otherwise"""
    for arg in args:
        is_valid = False
        if arg is None:
            is_valid = True
        elif isinstance(arg, list) or isinstance(arg, tuple):
            is_or_list = isinstance(arg, ORList)
            all_matched = True
            one_matched = False
            for sub_arg in arg:
                if isinstance(sub_arg, ORList):
                    match = validate_conditions(validator, variable, sub_arg)
                elif isinstance(sub_arg, list) or isinstance(sub_arg, tuple):
                    match = validate_conditions(validator, variable, *sub_arg)
                else:
                    match = validator(variable, sub_arg)
                if match:
                    one_matched = True
                else:
                    all_matched = False
                if (
                    (is_or_list and one_matched)
                    or (not is_or_list and not all_matched)
                ):
                    break
            if (
                (not is_or_list and all_matched)
                or (is_or_list and one_matched)
            ):
                is_valid = True
        elif isinstance(arg, OR):
            is_valid = validate_conditions(
                validator,
                variable,
                arg.conditional_value
            )
        else:
            is_valid = validator(variable, arg)
        if not is_valid:
            return False
    return True
