/* SERVER CONSTANTS */

{% block content %}
    {% for constant, value in constants.items %}
        var {{ constant }} = {{ value|safe }};
    {% endfor %}
{% endblock %}
