from django.core.management.base import BaseCommand

from onyx.apps.cms.register import create_system_chunks


class Command(BaseCommand):
    """Management command to trigger the creation of the
    system chunks defined in the settings.py

    Args:
        *args: Command arguments
        **options: Command keyword options"""

    help = 'Creates project-defined chunks'
    """Defines the help text for this command"""

    def handle(self, *args, **options):
        create_system_chunks()
