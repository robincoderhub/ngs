"""Management classes for the onyx library and sub apps go here"""
