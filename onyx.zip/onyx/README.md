# Onyx
Onyx is a combination of a number of Django apps and modules designed to make building bespoke sites easier and quicker.

# Setting up for development
If you're planning on modifying the library the easiest way to do it is to mount it within the onyx_foundation style project via the `docker-compose.yml` file.

Adding the following line to the volumes section:
```
volumes:
    ...
    - ./containers/app/lib/:/app/code/lib/
    ...
```

The create a new folder in `/containers/app/` called `lib/` then clone the onyx repository inside in a folder called `onyx/`. This will now mount you library folder internally inside the container when it's launched.

**It's worth noting** that the version of Onyx inside the container at build time and the version in your local directory may not be the same, this could theoretically cause issues at build time where the project relies on the your version but is being built with whatever version is defined in your `config/externals/repos.txt`. So it's worth changing this temporarily to your development branch, just be sure to change it back to a tagged release after!

# API documentation
At time of writing all Onyx code has been documented and can be used to generate API documentation, currently it hasn't been decided if this should reside somewhere more permenantly or within this repo itself. However, the tools have been added to generate HTML documentation by following the following steps:
```
docker-compose up
./bin/enter app
./bin/utils/pdoc --html onyx -o code/src/docs
```

This will output a directory in your `src/` folder called `docs/` you can open these up in your browser by going to `docs/onyx/index.html`.

# The app structure
This is the app structure of the Onyx library. Instructions for use of these apps can be found in the `__init__.py` file of each app.

- `onyx/` - Onyx is the main app and should be included when using any subset of the included apps, this app contains general use code and utilities to speed up development.
  - `apps/` - All 'sub apps' are stored here.
    - `admin/` - This is a reskinnable admin framework that can be extended with your own custom apps, it's used as the base for all other built in onyx apps which need admin functionality.
      - `cms/` - This is a base admin app for anything shared between CMS related admin apps
        - `chunks/` - This is an admin app that allows the creation and management of Chunks (content areas that contain widgets).
        - `cms_forms/` - This is an admin app that allows the creation and management of CMS forms.
        - `menus/` - This is an admin app for creation and management of menus.
        - `navigator/` - This is an admin app for including the Navigator media manager in the admin interface, allowing users to manage their uploaded files.
        - `pages/` - This is an admin app that allows the creation and management of CMS pages.
        - `redirects/` - This is an admin app that allows the creation and management of redirects.
      - `users/` - A basic user administration admin app, allows the creation and management of users and groups and their permissions.
    - `audit/` - The audit app includes code for auditing model changes across the whole site, you can register models with this apps global register and it will attempt to log each change, who changed it etc.
    - `cms/` - This is the 'common' app for CMS content, all core CMS functionality is stored here.
      - `cms_forms/` - Provides the models and functionality for building various types of forms with customisable handlers and fields and then displaying them on the front end and capturing their responses.
      - `menus/` - Provides functionality for creating CMS managed menus and displaying them.
      - `navigator/` - App that provides a media management interface for use both in form inputs and on it's own, allowing users to manage their uploaded files.
      - `redirects/` - App to provide functionality to create database defined redirects.
    - `cookies/` - An app for handling cookie consent, comes with middleware to restrict cookies being set and an installable cookie bar to accept and manage cookie preferences.
    - `errors/`  - An app that provides handlers for every error code in a nice consistent style.
    - `mockups/` - A small app for serving templates out of a directory without needing views for each, intended to help front end development.
    - `sso/` - Core app for single sign on services.
    - `sso/mtlogin/` - Handlers and functionality for Mercurytide's SSO service.

