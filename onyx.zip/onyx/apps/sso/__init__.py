"""
# SSO app

This app provides shared code for Single Sign On Apps (SSO)

## Requirements
- onyx

## Installation

To install this app just add it to your INSTALLED_APPS config
```
INSTALLED_APPS = [
    ...
    'onyx.apps.sso',
]
```
"""

default_app_config = 'onyx.apps.sso.config.SSOConfig'
