"""App config for SSO sub app"""

from onyx.config import AbstractOnyxConfig


class SSOConfig(AbstractOnyxConfig):
    """Default app config for SSO app"""

    name = "onyx.apps.sso"
    """The python path to the app"""

    verbose_name = "Onyx - SSO"
    """The human readable name of the app"""

    label = "onyx_sso"
    """The internal Django name of the app"""
