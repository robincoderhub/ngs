"""
# MTLogin SSO app

This is mercurytide's single sign on app designed to be used with the client hub (hub.mercurytide.co.uk).

## Requirements
- onyx
- onyx.apps.sso

## Installation

To install this app just add it to your INSTALLED_APPS config
```
INSTALLED_APPS = [
    ...
    'onyx.apps.sso.mtlogin',
]
```

Then add the urls file to the root `urls.py` of your site.
```
from django.urls import path

urlpatterns = [
    ...
    path('', include('onyx.apps.sso.mtlogin.urls')),
]
```

Boom!

## Adding a user to the mtlogin list

To add a user to the the list of users that can be logged into (typically the superuser) you have to set the user's
password attribute to 'mtlogin' , **Important** NOT using `set_password` but done directly i.e.
```
> from django.contrib.auth import get_user_model
> user = get_user_model().objects.get(is_superuser=True)
> user.password = 'mtlogin'
> user.save()
```

## Setting up a site for the first time with mtlogin

When you first set up a site the MTLOGIN_SECRET value must be populated, this is a deployment-side key containing exactly
256 characters and contains a-z, A-Z, 0-9 and the !@#$%^&*(-_=+) special characters. By default onyx_foundation has this
set up as an environment variable that will automatically generate the first time the `./bin/configure` tool is run and
saved.

Once you have a key set up for your deployment, you'll need to log into to https://hub.mercurytide.co.uk/ then go to
https://hub.mercurytide.co.uk/settings/cas/ click 'add service' where you then enter the sites details, url and secret
key and set to 'enabled'. This will complete the set up.

## TODO
- Move MTLOGIN_SECRET app variable into this app
"""

default_app_config = 'onyx.apps.sso.mtlogin.config.SSOMTLoginConfig'
