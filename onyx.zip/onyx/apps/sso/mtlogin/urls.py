"""URL patterns for the mockups app

This should be included at the root of the site."""

from django.urls import path

from onyx.apps.sso.mtlogin import views


app_name = 'mtlogin'
urlpatterns = [
    path('mtlogin/', views.mtlogin),
]
