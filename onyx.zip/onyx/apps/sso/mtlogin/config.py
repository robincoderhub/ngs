"""App config for mtlogin app"""

from onyx.config import AbstractOnyxConfig


class SSOMTLoginConfig(AbstractOnyxConfig):
    """Default app config for mtlogin app"""

    name = "onyx.apps.sso.mtlogin"
    """The python path to the app"""

    verbose_name = "Onyx - SSO - MTLogin"
    """The human readable name of the app"""

    label = "onyx_sso_mtlogin"
    """The internal Django name of the app"""
