"""Views related to the mtlogin app

TODO:
    - Rewrite documentation
    - Rewrite app

Notes:
    This code was converted from the original mtlogin app which
    desperately needs re-written. I'm unsure why this is so
    convoluted."""

from django.http import (
    HttpResponse,
    HttpResponseRedirect,
    HttpResponseForbidden
)
from django.contrib.auth import login, logout
from django.contrib.sessions.middleware import SessionMiddleware

from onyx.apps.sso.mtlogin import sso


def get_remote_ip(request):
    """Identify the IP address from which the request originated. If the
    request was proxied (i.e. the X-Forwarded-For header is present), there
    is a risk of the IP address being forged, but we have no choice other than
    to use it.

    Args:
        request: The incoming django request

    Returns:
        The ip address string found"""
    ip = request.META['REMOTE_ADDR']
    forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if forwarded_for:
        ip = forwarded_for.split(',')[0].strip()
    return ip


def _process_login(request, get_users, get_auth_backend):
    """Attempt to process a login from a request then
    redirects the user to the preferred location specified

    Args:
        request: The django request object
        get_users: A callable to fetch acceptable users to login to
        get_auth_backed: A callable to fetch the auth backend

    Returns:
        A Django response"""

    def do_login(request, user):
        user.backend = get_auth_backend()
        login(request, user)

    session_middleware = SessionMiddleware()
    session_middleware.process_request(request)

    # Kill any current authentication
    logout(request)

    # Expire the SSO session at browser close
    session = request.session
    # FIXME this may be < v1 check, need to check this is still needed
    try:
        session.set_expiry
    except AttributeError:
        pass
    else:
        session.set_expiry(0)

    service = sso.get_service(request)

    # If we have a service ticket, we try to use it to login the user.
    ticket = request.GET.get('ticket')
    if ticket:

        # Determine whether the service ticket is valid, and if so, which local
        # user it identifies.
        uid = sso.verify_cas1(ticket, service)

        # If the ticket is valid, we login as that user.
        if uid:
            user = get_users().get(uid, None)
            if not user:
                raise ValueError('Could not identify user.')
            do_login(request, user)
            response = HttpResponseRedirect(request.GET.get('next', '/'))
        # An invalid ticket results in a 403 error
        else:
            response = HttpResponseForbidden(
                '<h1>Forbidden</h1><p>Invalid authentication ticket.</p>'
            )

    # If we have no service ticket, redirect the user to the single sign on
    # login page.
    else:
        url = sso.login_url(service, sso.get_ip(
            service, get_remote_ip(request)))
        response = HttpResponseRedirect(url)

    # Ensure the session cookie as added to the response
    session_middleware.process_response(request, response)

    return response


def _process_list_users(request, list_users_ticket, get_users):
    """Fetch and return a list of users that can be logged into

    Args:
        request: The incoming Django request
        list_users_ticket: Erm.. TODO
        get_users: A callable to fetch users

    Returns:
        A Django response"""
    session_middleware = SessionMiddleware()
    session_middleware.process_request(request)

    service = sso.get_service(request)
    uids = get_users().keys()
    ult = sso.send_users(
        list_users_ticket,
        service,
        sso.get_ip(
            service,
            get_remote_ip(request)
        ),
        uids
    )
    if ult:
        url = sso.choose_user_url(service, ult)
        response = HttpResponseRedirect(url)
    else:
        response = HttpResponseForbidden(
            '<h1>Forbidden</h1><p>Invalid list_users ticket.</p>'
        )

    # Ensure the session cookie as added to the response
    session_middleware.process_response(request, response)

    return response


def mtlogin(request, get_users=None, get_auth_backend=None):
    """Execute mtlogin action

    Args:
        request: The incoming django request
        get_users: A callable to fetch acceptable users to login
        get_auth_backend: A callable to fetch the auth backend

    Returns:
        A Django response"""
    if get_users is None:
        def get_users():
            return sso.get_mtlogin_users({})

    if get_auth_backend is None:
        def get_auth_backend():
            return sso.get_mtlogin_auth_backend({})

    # The mercurytide.admin login page sends an empty AJAX request to test if
    # mtlogin is present, so we return a simple 200 response to confirm it is.
    try:
        is_ajax = request.is_ajax
    except AttributeError:  # FIXME check if is <v1 check, if so, remove
        def is_ajax():
            return (
                request.META.get(
                    'HTTP_X_REQUESTED_WITH'
                ) == 'XMLHttpRequest'
            )

    if is_ajax():
        return HttpResponse()

    list_users_ticket = request.GET.get('list_users')
    if list_users_ticket:
        return _process_list_users(request, list_users_ticket, get_users)
    else:
        return _process_login(request, get_users, get_auth_backend)
