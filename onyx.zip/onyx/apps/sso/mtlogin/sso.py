"""The core code of mtlogin SSO

TODO:
    - Rewrite documentation
    - Rewrite app

Notes:
    This code was converted from the original mtlogin app which
    desperately needs re-written. I'm unsure why this is so
    convoluted.

    There is a weird mix of UTF-8 and Latin1 encoding in this file
    due to unspecific encoding in original python 2.X script."""

import hmac
import os
import socket
from hashlib import sha1 as sha_hmac

from urllib.parse import urlencode, urljoin, urlparse, urlsplit, urlunsplit
from urllib.request import Request, urlopen

from django.contrib.auth import get_user_model


MTLOGIN_VERSION = '1.0'
"""The version of mtlogin protocol this SSO is using"""

def get_secret(service):
    from django.conf import settings
    return settings.MTLOGIN_SECRET


def is_private_network(ip):
    bits = list(map(int, ip.split('.')))
    return \
        (bits[0] == 10) or \
        (bits[0] == 127) or \
        (bits[0] == 172 and 16 <= bits[1] <= 31) or \
        (bits[0] == 192 and bits[1] == 168)


def get_ip(service, remote_addr):
    __, service_hostname, __, __, __, __ = urlparse(service)
    service_ip = socket.gethostbyname(service_hostname.split(':')[0])
    __, server_hostname, __, __, __, __ = urlparse(server_url())
    server_ip = socket.gethostbyname(server_hostname.split(':')[0])

    private_user = is_private_network(remote_addr)
    private_service = is_private_network(service_ip)
    private_server = is_private_network(server_ip)

    if private_user and private_service and not private_server:
        return urlopen('http://icanhazip.com').read().decode('latin1').strip()
    else:
        return remote_addr


def server_url():
    return os.environ.get('MTLOGIN_SERVER', 'https://hub.mercurytide.co.uk/cas/')


def login_url(service, ip):
    """Determine the single sign on login URL"""
    hash_msg = '#'.join([service, MTLOGIN_VERSION, ip]).encode('utf8')
    auth_hash = hmac.new(
        hash_msg,
        get_secret(service).encode('latin1'),
        sha_hmac
    ).hexdigest()
    params = {
        'service': service,
        'v': MTLOGIN_VERSION,
        'h': auth_hash,
    }
    url_base = urljoin(server_url(), 'login')
    url_params = urlencode(params)
    return f'{url_base}?{url_params}'


def send_users_url():
    """Determine the single sign on send_users URL"""
    return urljoin(server_url(), 'send_users')


def choose_user_url(service, ticket):
    """Determine the single sign on choose_users URL"""
    params = {
        'service': service,
        'ticket': ticket,
    }
    url_base = urljoin(server_url(), 'choose_user')
    url_params = urlencode(params)
    return f'{url_base}?{url_params}'


def verify_cas1(ticket, service):
    """Verifies CAS 1.0 authentication ticket.

    Returns username on success and None on failure.
    """
    params = {'ticket': ticket, 'service': service}
    url_base = urljoin(server_url(), 'validate')
    url_params = urlencode(params)
    url = f'{url_base}?{url_params}'
    page = urlopen(url)
    try:
        verified = page.readline().decode('latin1').strip()
        if verified == 'yes':
            return page.readline().decode('latin1').strip()
        else:
            return None
    finally:
        page.close()


def send_users(list_users_ticket, service, ip, uids):
    """
    Posts the `uids` to the single sign on server. Returns the ULT if
    successful, otherwise `None`.
    """
    uids_serialized = ','.join(uids)

    hash_msg = '#'.join([
        service,
        MTLOGIN_VERSION,
        ip,
        uids_serialized
    ]).encode('utf8')
    auth_hash = hmac.new(
        hash_msg,
        get_secret(service).encode('latin1'),
        sha_hmac
    ).hexdigest()

    url = send_users_url()
    data = urlencode((
        ('service', service),
        ('v', MTLOGIN_VERSION),
        ('uids', uids_serialized),
        ('ip', ip),
        ('h', auth_hash),
        ('ticket', list_users_ticket),
    ))

    page = urlopen(Request(url, data.encode('utf-8')))
    try:
        verified = page.readline().decode('latin1').strip()
        if verified == 'yes':
            return page.readline().decode('latin1').strip()
        else:
            return None
    finally:
        page.close()


def get_mtlogin_users(config_dict):
    """
    Determine which users ...
    """
    func = config_dict.get('get_mtlogin_users')
    if func:
        return func()
    else:
        User = get_user_model()
        filter_users = User.objects.filter
        users = filter_users(
            is_superuser__exact=True,
            password__exact='mtlogin',
        )

        try:
            backend = get_mtlogin_auth_backend(config_dict)
        except:  # FIXME should catch specific exceptions - R
            backend = ''

        def identifier_email(user):
            return user.email

        if 'email' in backend.lower():
            identifier = identifier_email
        else:
            from django.core.exceptions import FieldDoesNotExist
            try:
                User._meta.get_field('username')
            except FieldDoesNotExist:
                identifier = identifier_email
            else:
                def identifier_username(user):
                    return user.username
                identifier = identifier_username

        return dict([(identifier(u), u) for u in users])


def get_mtlogin_auth_backend(config_dict):
    """
    Determine which authentication backend should be faked...
    """
    func = config_dict.get('get_mtlogin_auth_backend')
    if func:
        return func()
    else:
        from django.conf import settings
        return settings.AUTHENTICATION_BACKENDS[0]


def get_service(request):
    """
    Determine the canonical URL of the 'service' value that is used by the
    single sign on server to identify this site. 
    """
    next = request.GET.get('next', '/')
    if 'SCRIPT_URI' in request.META:
        base_uri = request.META['SCRIPT_URI']
    else:
        protocol = request.is_secure() and 'https' or 'http'
        host = request.META['HTTP_HOST']
        path = request.path or '/mtlogin/'
        base_uri = f'{protocol}://{host}{path}'
    if os.environ.get('HTTPS') == 'on' and base_uri[:6] != 'https:':
        base_uri = urlunsplit(('https',) + urlsplit(base_uri)[1:])
    return urljoin(base_uri, '?' + urlencode({'next': next}))
