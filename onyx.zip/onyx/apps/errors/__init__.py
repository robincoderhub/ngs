"""
# Errors app

This app provides static error pages for all error codes,
this can be used by nginx or by a django project.

## Requirements
- onyx

## Installation (django)

To install this app just add it to your INSTALLED_APPS config
```
INSTALLED_APPS = [
    ...
    'onyx.apps.errors',
]
```

Then in your root urls.py add this line:
```
from onyx.apps.errors.url_handlers import *
```

This will add all the django error handler functions required to
display the right page for each error code.

## Installation (nginx)

In your server config add the following to define where the template folder is
and include the file itself.
```
location /errors {
    alias /path/to/onyx/templates/onyx/apps/errors/;
    internal;
}

include /path/to/onyx/apps/errors/nginx-include.conf;
```

"""

default_app_config = 'onyx.apps.errors.config.ErrorsConfig'
