"""This module generates functions to handle the various error codes and
assigns them to the global scope. This module can then by included in the
project's root urls.py by adding `from onyx.apps.errors.url_handlers import *`
at the top of the file. Django will then pick up handler404, handler405 etc."""

from django.template.loader import select_template
from django.template.exceptions import TemplateDoesNotExist
from django.views.generic import TemplateView


# We'll populate this below
__all__ = []

# Go through each error code and create a function to
# match all valid codes.
for error_code in range(400, 600):
    handler_name = f"handler{error_code}"
    template_name = f'onyx/apps/errors/{error_code}.html'
    if error_code == 500:
        # For some reason this only accepts string references
        # not template paths.
        globals()[handler_name] = 'onyx.apps.errors.views.error_500_handler'
        __all__.append(handler_name)
        continue
    try:
        select_template([template_name])
    except TemplateDoesNotExist:
        continue
    else:
        globals()[handler_name] = TemplateView.as_view(
            template_name=template_name
        )
        __all__.append(handler_name)
