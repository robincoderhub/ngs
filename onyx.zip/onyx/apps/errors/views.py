"""Error related views"""

from django.views.generic import TemplateView

from sentry_sdk import last_event_id

from onyx import app_settings


class Error500Handler(TemplateView):
    """A 500 error view than allows user's to provide
    feedback to Sentry about what they where doing when
    the error occurred.

    This requires the SENTRY_DSN setting to be set.

    See also: https://docs.sentry.io/"""

    template_name = 'onyx/apps/errors/500_django.html'
    """The path to the template for this view"""

    status = 500
    """The HTTP status to use for this response"""

    def get_context_data(self, **kwargs):
        """Extends context data to add sentry dsn key
        and a reference to the most recent exception

        Args:
            **kwargs: The current context data

        Returns:
            The updated context data dict"""
        context = super().get_context_data(**kwargs)
        context.update({
            'sentry_dsn': app_settings.SENTRY_DSN,
            'sentry_event_id': last_event_id(),
        })
        return context


def error_500_handler(*args, **kwargs):
    """Django seems to require a function to handle 500
    errors and won't accept class-based views. So this
    is just a wrapper to display the class

    Args:
        *args: The view arguments
        **kwargs: The view keyword arguments

    Returns:
        A Django response."""
    return Error500Handler.as_view()(*args, **kwargs)
