"""Errors app App config classes"""

from onyx.config import AbstractOnyxConfig


class ErrorsConfig(AbstractOnyxConfig):
    """Default errors app config"""

    name = "onyx.apps.errors"
    """The python path to the app"""

    verbose_name = "Onyx - Errors"
    """The human readable name of the app"""

    label = "onyx_errors"
    """The internal Django name of the app"""
