from django.http import Http404

from onyx.apps.cms.models import SiteNode
from onyx.apps.cms.register import (
    get_node_type,
    get_ordered_resolvers,
    register_request_resolver
)


def resolve_to_response(request):
    """Resolve a request against registered request resolvers
    and return the resultant response, or None if no resolvers
    matched the request.

    Args:
        request: The Django request object

    Returns:
        A Django response object or None if no resolver found."""
    resolvers = get_ordered_resolvers()
    for resolver in resolvers:
        try:
            response = resolver.handle_request(request)
        except Http404:
            continue
        else:
            if response:
                return response
    return None


class AbstractRequestResolver(object):
    """Abstract resolver base class, implements
    the handle_request method."""

    @classmethod
    def handle_request(cls, request):
        """Abstract method to handle a request or return
        None if cannot handle/doesn't match.
        Args:
            request: The Django request

        Raises:
            NotImplementedError: Thrown if method not overridden.

        Returns:
            A django response or None"""
        raise NotImplementedError(
            'handle_request method must be overidden'
        )


class PathResolver(AbstractRequestResolver):
    """Request resolver for resolving a given request path
    against a SiteNode and returning the resultant response."""

    @classmethod
    def handle_request(cls, request):
        """Handle request, check against SiteNode objects and return
        response if found.

        Args:
            request: The incoming request object

        Returns:
            A Django response or None if can't handle request."""
        try:
            node = SiteNode.objects.get(path=request.path)
        except SiteNode.DoesNotExist:
            return None
        if not node.published:
            return None
        node_type = get_node_type(node.node_type)
        return node_type.handle_request(request, node)


DEFAULT_RESOLVERS = {
    'path_resolver': (3, PathResolver)
}
"""A dict of default resolvers to register on ready."""


def register_default_resolvers():
    """Register default resolvers defined in the
    DEFAULT_RESOLVERS variable."""
    global DEFAULT_RESOLVERS
    for name, value in DEFAULT_RESOLVERS.items():
        register_request_resolver(name, value[1], value[0])
