"""CMS related forms"""

from django import forms

from onyx.apps.cms.models import Chunk


class BasicTemplateForm(forms.Form):
    """A form for BasicTemplateType template type class"""

    view_title = forms.CharField(label='Title')
    """The title of the page"""

    view_description = forms.CharField(label='Description', required=False)
    """The meta description of the page"""

    view_keywords = forms.CharField(label='Keywords', required=False)
    """The meta keywords for the page"""


class ChunkWidgetTypeForm(forms.Form):
    """Widget type form for the ChunkWidget class

    Args:
        *args: Inherited form arguments
        **kwargs: Inherited form keywords"""

    chunk_name = forms.ChoiceField(choices=[])
    """The internal name of the chunk to display"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['chunk_name'].choices = [
            (chunk.chunk_name, f"{chunk.label} ({chunk.chunk_name})")
            for chunk in Chunk.objects.filter(global_chunk=True)
        ]
