"""CMS app config classes"""

from onyx.config import AbstractOnyxConfig


class CMSConfig(AbstractOnyxConfig):
    """Default CMS config class"""

    name = "onyx.apps.cms"
    """The python path to the app"""

    verbose_name = "Onyx - CMS"
    """The human readable name of the app"""

    label = "onyx_cms"
    """The internal Django name of the app"""

    def ready(self):
        """Loads all CMS default widgets, field types, url
        resolvers and CMS nodes types."""
        from onyx.apps.cms.widgets.fields import (
            register_default_field_types,
            register_extra_widget_field_types
        )
        from onyx.apps.cms.widgets.loader import discover_widgets
        from onyx.apps.cms.app_settings import AUTOLOAD_WIDGET_DATA
        from onyx.apps.cms.register import (
            register_widget_type
        )
        from onyx.apps.cms.widgets import ChunkWidgetType
        from onyx.apps.cms.resolvers import register_default_resolvers
        from onyx.apps.cms.nodes import register_default_nodes

        if AUTOLOAD_WIDGET_DATA:
            register_widget_type('chunk', ChunkWidgetType)
            register_default_field_types()
            register_extra_widget_field_types()
            discover_widgets()
        register_default_resolvers()
        register_default_nodes()
