"""URL patterns for the navigator app"""

from django.urls import path

from onyx.apps.cms.navigator import views


app_name = 'navigator'
urlpatterns = [
    path('api/', views.NavigatorAPIView.as_view(), name='api'),
    path('api/<path:path>', views.NavigatorAPIView.as_view(), name='api'),
    path('template/', views.NavigatorTemplateView.as_view(), name='template'),
    path('page_mode/', views.NavigatorPageView.as_view(), name='page_mode')
]
