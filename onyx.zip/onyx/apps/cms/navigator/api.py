"""Navigator API actions and class"""

import os

from pathlib import Path

from onyx.utils.api.core import API, APIAction, APIResponse
from onyx.utils.api.exceptions import APIException
from onyx.apps.cms.navigator.core import get_navigator
from onyx.apps.cms.navigator.exceptions import NavigatorError


navigator = get_navigator()


API_INSTANCE = None
"""Global instance of the NavigatorAPI class"""


def get_navigator_api():
    """Get method to fetch the global instance
    of the NavigatorAPI class.

    Returns:
        A NavigatorAPI instance."""
    global API_INSTANCE
    if not API_INSTANCE:
        API_INSTANCE = NavigatorAPI()
    return API_INSTANCE


class BaseAPIAction(APIAction):
    """A base APIAction class for all navigator actions,
    sets all actions to be authenticated staff members.

    Args:
        *args: Inherited class arguments
        **kwargs: Inherited class keyword arguments"""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.authenticated = True
        self.staff_only = True


class ListDirectoryAction(BaseAPIAction):
    """API action for listing the specified directory"""

    def get(self, options, data, files, user):
        """GET method handler, returns an api response
        with the requested directories information and the list
        of paths inside it.

        Options:
            path: The path to list

        Args:
            options: The api options passed to this action,
            data: The data passed to this action
            files: The files dict passed to this action.
            users: The user accessing this action.

        Returns:
            An APIResponse object"""
        path = options.get('path')
        root_path = navigator.get_navigator_path(path)
        dir_list = navigator.list_directory(user, path)
        return self.response(
            data={
                'dir': root_path.to_object() if root_path else None,
                'paths': [item.to_object() for item in dir_list]
            }
        )


class CreateDirectoryAction(BaseAPIAction):
    """API action for creating a directory."""

    def post(self, options, data, files, user):
        """POST method handler, creates a directory at
        the path specified.

        Data:
            path: The path to create the directory in
            name: The directory name to use

        Args:
            options: The api options passed to this action,
            data: The data passed to this action
            files: The files dict passed to this action.
            users: The user accessing this action.

        Raises:
            APIException: Thrown if not all required data attributes
                are passed.

        Returns:
            An APIResponse object"""
        path = data.get('path')
        dirname = data.get('name')
        if not path or not dirname:
            raise APIException('Both path and name must be passed.')
        navigator.create_directory(
            user,
            path,
            dirname
        )
        return self.response()


class CopyAction(BaseAPIAction):
    """API action for copying files or folders from one
    place to another."""

    def post(self, options, data, files, user):
        """POST method handler, copies one or more paths from
        one place to another.

        Data:
            paths: The paths to move, seperated by the pipe
                character.
            dest: The path to move files to

        Args:
            options: The api options passed to this action,
            data: The data passed to this action
            files: The files dict passed to this action.
            users: The user accessing this action.

        Returns:
            An APIResponse object"""
        paths = data.get('paths').split('|')
        destination = data.get('dest')
        for path in paths:
            navigator.copy(
                user,
                path,
                os.path.join(destination, Path(path).name)
            )
        return self.response()


class CutAction(BaseAPIAction):
    """API action for removing files or folders from one
    place and moving them somewhere else."""

    def post(self, options, data, files, user):
        """POST method handler, copies specified paths
        from one place to the other, removing the original
        files.

        Data:
            paths: A list of paths separated by the pipe character
            dest: The path to copy files to.

        Args:
            options: The api options passed to this action,
            data: The data passed to this action
            files: The files dict passed to this action.
            users: The user accessing this action.

        Returns:
            An APIResponse object"""
        paths = data.get('paths').split('|')
        destination = data.get('dest')
        for path in paths:
            navigator.move(
                user,
                path,
                os.path.join(destination, Path(path).name)
            )
        return self.response()


class RenameAction(BaseAPIAction):
    """API action for renaming a file or folder to a new
    name."""

    def post(self, options, data, files, user):
        """POST method handler, renames a file or folder
        to a new name.

        Data:
            path: The path to rename
            name: The name to rename it to.

        Args:
            options: The api options passed to this action,
            data: The data passed to this action
            files: The files dict passed to this action.
            users: The user accessing this action.

        Returns:
            An APIResponse object"""
        path = data.get('path')
        name = data.get('name')
        navigator.move(
            user,
            path,
            os.path.join(Path(path).parent, name)
        )
        return self.response()


class DeleteAction(BaseAPIAction):
    """API action for deleting one or more files or folders."""

    def post(self, options, data, files, user):
        """POST method handler, deletes one or more
        files or folders specified.

        Data:
            paths: The paths to delete seperated by the pipe character

        Args:
            options: The api options passed to this action,
            data: The data passed to this action
            files: The files dict passed to this action.
            users: The user accessing this action.

        Returns:
            An APIResponse object"""
        paths = data.get('paths').split('|')
        for path in paths:
            navigator.delete(
                user,
                path
            )
        return self.response()


class UploadAction(BaseAPIAction):
    """APIAction to upload files to a path."""

    def post(self, options, data, files, user):
        """POST method handler, uploads files to the given
        path.

        Data:
            path: The path to upload to

        Files:
            Any and all files passed will be uploaded.

        Args:
            options: The api options passed to this action,
            data: The data passed to this action
            files: The files dict passed to this action.
            users: The user accessing this action.

        Returns:
            An APIResponse object containing the number of
            files sent."""
        path = data.get('path')
        for uploaded_file in files.values():
            navigator.upload(
                user,
                path,
                uploaded_file.file.read(),
                uploaded_file.name
            )
        return self.response(
            f"{len(files.keys())} files"
        )


class NavigatorAPI(API):
    """The main API class, contains all the actions by default."""

    def __init__(self):
        super().__init__({
            'list': ListDirectoryAction(),
            'create_directory': CreateDirectoryAction(),
            'copy': CopyAction(),
            'cut': CutAction(),
            'rename': RenameAction(),
            'delete': DeleteAction(),
            'upload': UploadAction()
        })

    def execute_action(self, *args, **kwargs):
        """Extends the execute_action method to catch any
        NavigatorError exceptions and convert them to APIResponse
        objects.

        Args:
            *args: Inherited arguments
            **kwargs: Inherited keyword arguments.

        Returns:
            An APIResponse object."""
        try:
            return super().execute_action(*args, **kwargs)
        except NavigatorError as e:
            return APIResponse(
                str(e),
                500
            )
