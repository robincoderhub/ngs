"""Views for navigator app"""

from django.views.generic import TemplateView

from onyx.utils.api.views import APIView
from onyx.apps.cms.navigator.api import get_navigator_api


class NavigatorTemplateView(TemplateView):
    """A view for displaying the navigator template"""
    template_name = 'onyx/apps/cms/navigator/template.html'


class NavigatorPageView(TemplateView):
    """A view for displaying a full page version of the navigator."""
    template_name = 'onyx/apps/cms/navigator/page_mode_full.html'


class NavigatorAPIView(APIView):
    """A view for serving the navigator API"""

    def get_api(self):
        """Override to return navigator API

        Returns:
            A NavigatorAPI instance."""
        return get_navigator_api()
