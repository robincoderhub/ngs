"""App that provides a media resource navigator that can be used to select
or manage uploaded files."""

default_app_config = 'onyx.apps.cms.navigator.config.CMSNavigatorConfig'
