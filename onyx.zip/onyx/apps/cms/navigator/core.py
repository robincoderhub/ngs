"""Core navigator classes"""

import os
import shutil
from urllib.parse import urljoin
from pathlib import Path

from django.utils import timezone

from onyx.apps.cms.navigator import app_settings, exceptions
from onyx.utils.conditionals import validate_conditions


NAVIGATOR_INSTANCE = None
"""Global instance of the Navigator class"""


def get_navigator():
    """Getter for global instance of Navigator class

    Returns:
        The global Navigator class"""
    global NAVIGATOR_INSTANCE
    if not NAVIGATOR_INSTANCE:
        NAVIGATOR_INSTANCE = Navigator()
    return NAVIGATOR_INSTANCE


class NavigatorSource(object):
    """A class representing a file source, a path that can be
    browsed.

    Args:
        alias: A name for this source, this will be listed in 'root'
            filesystem.
        path: The system path to the directory to navigate.
        url_path: Optional, the public url of the root of the folder,
            this is used to determine urls for contained paths.
        read_only: Defaults to False, if True can view this source but
            not modify it.
        read_only_paths: Optional, allows you to specify individual paths
            within this source that area read only.
        hidden_paths: Optional, allows you to specify paths that will be
            hidden from the user.
        view_permissions: Permissions the user must have to view this source.
        write_permissions: Permissions the user must have to write to the
            source."""
    def __init__(
        self, alias, path, url_path=None, read_only=False,
        read_only_paths=[], hidden_paths=[],
        view_permissions=[], write_permissions=[]
    ):
        self.alias = alias
        self.path = path
        self.url_path = url_path
        self.read_only = read_only
        self.read_only_paths = read_only_paths
        self.hidden_paths = hidden_paths
        self.view_permissions = view_permissions
        self.write_permissions = write_permissions

    def get_alias(self):
        """Get the alias name for this source

        Returns:
            The string alias name"""
        return self.alias

    def get_path(self):
        """Get the system path for this source.

        Returns:
            The path to the source directory."""
        return self.path

    def get_url_path(self):
        """Get the url path of this source.

        Returns:
            The url path of this source."""
        return self.url_path

    def is_read_only(self):
        """Whether or not this source is read only.

        Returns:
            True if read only, otherwise False."""
        return self.read_only

    def get_read_only_paths(self):
        """Get paths in this source that are considered
        read only.

        Returns:
            A list of read only paths."""
        return self.read_only_paths

    def get_hidden_paths(self):
        """Get paths that should be hidden in this source.

        Returns:
            A list of hidden paths."""
        return self.hidden_paths

    def get_read_permissions(self):
        """Get read permissions for this source.

        Returns:
            A set of conditional object permissions."""
        return self.view_permissions

    def get_write_permissions(self):
        """Get write permissions for this source.

        Returns:
            A set of conditional object permissions"""
        return self.write_permissions


class NavigatorPath(object):
    """A NavigatorPath object represents a path used by Navigator to
    represent a directory or file.

    Args:
        navigator: The Navigator instance this path belongs to
        path: A navigator path, this typically starts with the alias
            name as a directory for example if a source is named 'jim'
            something like /jim/my/real/folder/image.jpg"""

    def __init__(self, navigator, path):
        if not path.startswith('/'):
            path = f"/{path}"
        path = os.path.abspath(path)
        alias = path[1:].split('/', 1)[0]
        source = navigator.get_source(alias)
        if not source:
            raise exceptions.NavigatorRestrictedPathError(
                'Path is outside allowed navigator paths.'
            )
        neutered_path = path.replace(f'/{alias}', '', 1)
        while neutered_path.startswith('/'):
            neutered_path = neutered_path.replace('/', '', 1)
        # os.path.join can be dangerous, os.join('/app/data/', '/') = '/'
        system_path = os.path.abspath(
            os.path.join(
                source.get_path(),
                neutered_path
            )
        )
        if not system_path.startswith(source.get_path()):
            raise exceptions.NavigatorRestrictedPathError(
                'Path is outside allowed navigator paths.'
            )
        self.navigator = navigator
        self.source = source
        self.source_path = path
        self.system_path = system_path

    def is_writable(self, user=None):
        """Whether or not this path is writable, if a user
        is passed, checks permissions of this path.

        Args:
            user: Optional, if passed checks the user has
                the right permissions to write, otherwise
                just checks if the path is generally writable.

        Returns:
            True if is writable, False otherwise."""
        if not self.is_system_writable():
            return False
        if self.is_read_only():
            return False
        if self.is_hidden():
            return False
        if user:
            if not self.user_has_write_permissions(user):
                return False
        return True

    def is_protected(self):
        """Check if a path is protected, i.e. if path is hidden
        or read only.

        Returns:
            True if directory is protected, False otherwise."""
        source = self.get_source()
        system_path = f"{self.get_system_path()}/"
        if system_path == source.get_path():
            return True
        for read_only_path in source.get_read_only_paths():
            read_only_sys_path = os.path.abspath(
                os.path.join(
                    source.get_path(),
                    read_only_path
                )
            ) + '/'
            if (
                system_path.startswith(read_only_sys_path)
                or read_only_sys_path.startswith(system_path)
            ):
                return True
        for hidden_path in source.get_hidden_paths():
            hidden_sys_path = os.path.abspath(
                os.path.join(
                    source.get_path(),
                    hidden_path
                )
            ) + '/'
            if (
                system_path.startswith(hidden_sys_path)
                or hidden_sys_path.startswith(system_path)
            ):
                return True
        return False

    def is_readable(self, user=None):
        """Check if path is readable.

        Args:
            user: Optional, if a user is passed, checks if the
                user has the required permissions to read this
                directory. Otherwise just checks if path is generally
                readable.

        Returns:
            True if path is readable, False otherwise"""
        if not self.is_system_readable():
            return False
        if self.is_hidden():
            return False
        if user:
            if not self.user_has_read_permissions(user):
                return False
        return True

    def is_system_writable(self):
        """Check if path is writable on system side.

        Returns:
            True if writable, False otherwise."""
        if self.exists():
            return os.access(self.get_system_path(), os.W_OK)
        else:
            return os.access(
                str(
                    Path(
                        self.get_system_path()
                    ).parent
                ),
                os.W_OK
            )

    def is_system_readable(self):
        """Checks if path is readable system side.

        Returns:
            True if readable, False otherwise."""
        if self.exists():
            return os.access(self.get_system_path(), os.R_OK)
        else:
            return os.access(str(Path(self.get_system_path()).parent), os.R_OK)

    def is_hidden(self):
        """Whether or not this path is considered 'hidden' and
        should not be displayed.

        Returns:
            True if directory is hidden, False otherwise."""
        source = self.get_source()
        system_path = f"{self.get_system_path()}/"
        for hidden_path in source.get_hidden_paths():
            hidden_sys_path = os.path.abspath(
                os.path.join(
                    source.get_path(),
                    hidden_path
                )
            ) + '/'
            if system_path.startswith(hidden_sys_path):
                return True
        return False

    def is_read_only(self):
        """Whether this path is considered read only.

        Returns:
            True if path is read only, False otherwise."""
        source = self.get_source()
        system_path = f"{self.get_system_path()}/"
        if source.is_read_only():
            return True
        for read_only_path in source.get_read_only_paths():
            read_only_sys_path = os.path.abspath(
                os.path.join(
                    source.get_path(),
                    read_only_path
                )
            ) + '/'
            if system_path.startswith(read_only_sys_path):
                return True
        return False

    def is_url_accessible(self):
        """Whether the resource this path represents can be
        accessed via a url.

        Returns:
            True if has a url, false otherwise."""
        return self.get_source().get_url_path() is not None

    def get_url(self):
        """Get the url for this resource

        Returns:
            The url for this path or None if none configured."""
        if not self.is_url_accessible():
            return None
        source_path = self.get_system_path().replace(
            self.get_source().get_path(),
            '',
            1
        )
        if source_path.startswith('/'):
            source_path = source_path.replace('/', '', 1)
        return urljoin(
            self.get_source().get_url_path(),
            source_path
        )

    def user_has_write_permissions(self, user):
        """Checks if given user has write permissions

        Args:
            user: The user to check

        Returns:
            True if user has write permissions, False otherwise."""
        if self.is_read_only() or self.is_hidden():
            return False
        permissions = self.get_source().get_write_permissions()
        if permissions:
            return validate_conditions(
                lambda x, y: x.has_perm(y),
                user,
                permissions
            )
        return True

    def user_has_read_permissions(self, user):
        """Check if given user has read permissionsd.

        Args:
            user: The user to checkk

        Returns:
            True if user has read permissions, False otherwise."""
        if self.is_hidden():
            return False
        permissions = self.get_source().get_read_permissions()
        if permissions:
            return validate_conditions(
                lambda x, y: x.has_perm(y),
                user,
                permissions
            )
        return True

    def exists(self):
        """Check if this path actually exists on the file system.

        Returns:
            True if path exists, False otherwise."""
        return os.path.exists(self.get_system_path())

    def is_file(self):
        """Check if this path is a file.

        Returns:
            True if path is a file, False otherwise."""
        return os.path.isfile(self.get_system_path())

    def is_directory(self):
        """Check if this path is a directory.

        Returns:
            True if path is a directory, False otherwise."""
        return os.path.isdir(self.get_system_path())

    def get_name(self):
        """Get the filename/directory name of this path.

        Returns:
            The string name of the path."""
        if self.get_system_path() == self.get_source().get_path():
            return self.get_source().get_alias()
        return Path(self.get_system_path()).name

    def get_extension(self):
        """Get the file extension of this path (if applicable)

        Returns:
            The file extension of this path, or None if none found."""
        if self.is_directory():
            return None
        name = self.get_name()
        name_bits = name.rsplit('.', 1)
        return name_bits[1] if len(name_bits) == 2 else None

    def get_category(self):
        """Get the Navigator category this path falls into.

        Returns:
            The string id of the category."""
        categories = app_settings.NAVIGATOR_PATH_CATEGORIES
        extensions = app_settings.NAVIGATOR_PATH_EXTENSIONS
        if self.is_directory():
            return categories['DIRECTORY']
        extension = self.get_extension()
        for category_key, extensions in extensions.items():
            if extension in extensions:
                return categories[category_key]
        return categories[app_settings.NAVIGATOR_DEFAULT_CATEGORY]

    def get_parent_path(self):
        """Get the parent directory of this path.

        Returns:
            A NavigatorPath pointing to the parent directory or None if
            can't go any higher."""
        parent_path = self.get_source_path().rsplit('/', 1)[0]
        if parent_path == '/' or parent_path == '':
            return None
        return NavigatorPath(
            self.get_navigator(),
            parent_path
        )

    def get_size(self):
        """Get the size of this path.

        Returns:
            An integer size in bytes or None if is a directory."""
        if self.is_directory():
            # Technically a directory has a size but users will think
            # size = size of contents, which would be expensive to calculate
            return None
        return os.path.getsize(self.get_system_path())

    def get_human_size(self):
        """Get the size of this path as a human readable string using
        unit suffixes such as mb or gb.

        Returns:
            A string representation of this or None if is a directory."""
        size = self.get_size()
        if size is None:
            return None
        for unit in ['', 'K', 'M', 'G', 'T', 'P', 'E', 'Z']:
            if abs(size) < 1024.0:
                return "%3.1f%s%s" % (size, unit, 'B')
            size /= 1024.0
        return "%.1f%s%s" % (size, 'Y', 'B')

    def get_last_modified(self):
        """Get the last modified stamp of this path as a datetime.

        Returns:
            A datetime of the last modified stamp."""
        return timezone.datetime.fromtimestamp(
            os.path.getmtime(self.get_system_path())
        )

    def get_human_last_modified(self):
        """Get last modified date as a human readable string.

        Returns:
            The human readable last modified."""
        last_modified = self.get_last_modified()
        day = last_modified.day
        return "%s%s of %s" % (
            last_modified.strftime("%H:%M %d"),
            'th'
            if 11 <= day <= 13
            else {
                1: 'st', 2: 'nd', 3: 'rd'
            }.get(
                day % 10,
                'th'
            ),
            last_modified.strftime("%B %Y"),
        )

    def get_navigator(self):
        """Getter for the instance of Navigator this path
        belongs to.

        Returns:
            A Navigator instance."""
        return self.navigator

    def get_source(self):
        """Get the parent 'source' this path belong to.

        Returns:
            A NavigatorSource instance."""
        return self.source

    def get_source_path(self):
        """Get the path of this path relative to the source, this will
        be prefixed with that source's alias and not be a 'true' path.
        i.e. if source is aliased 'my-media' an example path would be
        /my-media/real/dir/structure/image.jpg

        Returns:
            The source path"""
        return self.source_path

    def get_system_path(self):
        """Get the 'real' system path to this file/directory.

        Returns:
            The system path to this resource."""
        return self.system_path

    def __str__(self):
        """Override, return a string representation of this path

        Returns:
            The source path of this resource."""
        return self.get_source_path()

    def to_object(self, user=None, include_system_path=False):
        """Conver this path to a dict, this is typically used in api responses.

        Args:
            user: Optional, if passed will be used to work out read/write
                permissions against the given user.
            include_system_path: Defaults to False, if True will include the
                real system path of this resource in the resultant object.

        Returns:
            A dict containing various information about this path."""
        return {
            'name': self.get_name(),
            'category': self.get_category(),
            'readable': self.is_readable(user),
            'writable': self.is_writable(user),
            'source': self.get_source().get_alias(),
            'path': self.get_source_path(),
            'system_path': (
                self.get_system_path()
                if include_system_path
                else None
            ),
            'extension': self.get_extension(),
            'protected': self.is_protected(),
            'size': self.get_size(),
            'size_human': self.get_human_size(),
            'last_modified': str(self.get_last_modified()),
            'last_modified_human': self.get_human_last_modified(),
            'url': self.get_url(),
            'is_directory': self.is_directory(),
            'is_file': self.is_file(),
            'is_read_only': self.is_read_only(),
            'is_hidden': self.is_hidden()
        }


class Navigator(object):
    """Main Navigator class, this acts more or less like an API of
    navigator functionality.

    Args:
        source_definitions: Optional a list of dicts defining NavigatorSource
            objects' keyword arguments. By default this will used the
            NAVIGATOR_SOURCES settings variable."""
    def __init__(self, source_definitions=None):
        sources = {}
        source_definitions = (
            source_definitions
            or app_settings.NAVIGATOR_SOURCES
        )
        for kwargs in source_definitions:
            source = NavigatorSource(**kwargs)
            sources[source.get_alias()] = source
        self.sources = sources

    def get_navigator_path(self, path):
        """Convert a string source path to a NavigatorPath object.

        Args:
            The 'source' path to convert.

        Returns:
            A NavigatorPath object or None if path could not be
            determined."""
        try:
            return NavigatorPath(self, path)
        except exceptions.NavigatorError:
            return None

    def upload(self, user, dest_path, file_data, filename):
        """Upload a file action.

        Args:
            user: The user doing the uploading.
            dest_path: The path to upload to, this can be a NavigatorPath or a
                string 'source path.
            file_data: The file data of the file to upload.
            filename: The resultant filename of the upload.

        Raises:
            NavigatorWritePermissionsError: Thrown if user does not have
                permission to upload to this path.
            NavigatorFileExistsError: Thrown if a file already exists at the
                given path."""
        if not isinstance(dest_path, NavigatorPath):
            dest_path = NavigatorPath(self, dest_path)
        if not dest_path.is_writable(user):
            raise exceptions.NavigatorWritePermissionsError(
                'You do not have permission to write to destination path.'
            )
        file_path = NavigatorPath(
            self,
            os.path.join(
                dest_path.get_source_path(),
                filename
            )
        )
        if file_path.exists():
            raise exceptions.NavigatorFileExistsError(
                'A file already exists at destination path.'
            )
        with open(file_path.get_system_path(), 'wb') as dest_file:
            dest_file.write(file_data)
            dest_file.close()

    def create_directory(self, user, dest_path, name):
        """Create a directory at given path with given name.

        Args:
            user: The user who is creating the directory.
            dest_path: The path to the directory to create the directory
                inside.
            name: The name of the directory to create.

        Raises:
            NavigatorWritePermissionsError: Thrown if user does not have
                permission to create directory in this path.
            NavigatorFileExistsError: Thrown if a file/directory already
                exists at the given path."""
        if not isinstance(dest_path, NavigatorPath):
            dest_path = NavigatorPath(self, dest_path)
        folder_path = NavigatorPath(
            self,
            os.path.join(
                dest_path.get_source_path(),
                name
            )
        )
        if not dest_path.is_writable(user):
            raise exceptions.NavigatorWritePermissionsError(
                'You do not have permission to write to destination path.'
            )
        if folder_path.exists():
            raise exceptions.NavigatorFileExistsError(
                'A file already exists at destination path.'
            )
        os.mkdir(folder_path.get_system_path())

    def list_directory(self, user, path, include_hidden=False):
        """List the given directory, retrieve a list of paths.

        Args:
            user: The user listing the directory.
            path: The 'source' path to list..
            include_hidden: Defaults to False, if True will include 'hidden'
                directories.

        Raises:
            NavigatorInvalidPathError: Raised if given path is not a directory.

        Returns:
            A list of NavigatorPath objects."""
        listing_paths = []
        if os.path.abspath(path) == '/':
            for alias in self.get_sources().keys():
                listing_path = NavigatorPath(self, f'/{alias}')
                if not listing_path.exists():
                    os.makedirs(listing_path.get_system_path(), exist_ok=True)
                if listing_path.is_readable(user):
                    listing_paths.append(
                        listing_path
                    )
        else:
            if not isinstance(path, NavigatorPath):
                path = NavigatorPath(self, path)
            if not path.is_directory():
                raise exceptions.NavigatorInvalidPathError(
                    'Path must be a directory.'
                )
            for listing in os.listdir(path.get_system_path()):
                if listing in ['.', '..']:
                    continue
                listing_path = NavigatorPath(
                    self,
                    os.path.join(path.get_source_path(), listing)
                )
                if (
                    (listing_path.is_hidden() and not include_hidden)
                    or not listing_path.is_readable(user)
                ):
                    continue
                listing_paths.append(listing_path)
        return listing_paths

    def move(self, user, src_path, dest_path):
        """Move a file or directory from one place to another.

        Args:
            src_path: The path of the resource to move, in 'source' format.
            dest_path: The path to move the resource to, in 'source' format.

        Raises:
            NavigatorWritePermissionsError: Thrown if user does not have
                permission to modify the source, or cannot write to the
                destination.
            NavigatorFileExistsError: Thrown if there is already a file at
                the destination path.
            NavigatorMalformedPathError: Thrown if you attempt to move a folder
                inside itself."""
        if not isinstance(src_path, NavigatorPath):
            src_path = NavigatorPath(self, src_path)
        if not isinstance(dest_path, NavigatorPath):
            dest_path = NavigatorPath(self, dest_path)
        if not src_path.is_writable(user):
            raise exceptions.NavigatorWritePermissionsError(
                'You do not have permission to modify source path.'
            )
        if src_path.is_protected():
            raise exceptions.NavigatorWritePermissionsError(
                'The path specified is protected and cannot be'
                + ' moved or renamed.'
            )
        if not dest_path.is_writable(user):
            raise exceptions.NavigatorWritePermissionsError(
                'You do not have permission to write to destination path.'
            )
        if dest_path.exists():
            raise exceptions.NavigatorFileExistsError(
                'A file already exists at destination path.'
            )
        if dest_path.get_system_path().startswith(src_path.get_system_path()):
            raise exceptions.NavigatorMalformedPathError(
                'You cannot move a folder inside itself.'
            )
        shutil.move(
            src_path.get_system_path(),
            dest_path.get_system_path()
        )

    def copy(self, user, src_path, dest_path):
        """Copy a file or folder from one place to another.

        Args:
            user: The user doing the copy
            src_path: The path of the source resource to copy, in 'source'
                path format.
            dest_path: The path of the destination to copy resource to, in
                source path format.

        Raises:
            NavigatorReadPermissionsError: Thrown if user does not have
                permissiont to read source path.
            NavigatorWritePermissionsError: Thrown if user does not have
                permission to write to the destination path.
            NavigatorFileMissingError: Thrown if src path does not exist.
            NavigatorFileExistsError: Thrown if a resource already exists
                at the destination path."""
        if not isinstance(src_path, NavigatorPath):
            src_path = NavigatorPath(self, src_path)
        if not isinstance(dest_path, NavigatorPath):
            dest_path = NavigatorPath(self, dest_path)
        if not src_path.is_readable(user):
            raise exceptions.NavigatorReadPermissionsError(
                'You do not have permission to modify source path.'
            )
        if not dest_path.is_writable(user):
            raise exceptions.NavigatorWritePermissionsError(
                'You do not have permission to write to destination path.'
            )
        if not src_path.exists():
            raise exceptions.NavigatorFileMissingError(
                'Source file does not exist and cannot be copied.'
            )
        if dest_path.exists():
            raise exceptions.NavigatorFileExistsError(
                'A file already exists at destination path.'
            )
        if src_path.is_directory():
            shutil.copytree(
                src_path.get_system_path(),
                dest_path.get_system_path()
            )
        else:
            shutil.copyfile(
                src_path.get_system_path(),
                dest_path.get_system_path()
            )

    def delete(self, user, src_path):
        """Delete resource at given path.

        Args:
            user: The user doing the deleting.
            src_path: The path to delete in 'source' path format.

        Raises:
            NavigatorWritePermissionsError: Raised if user does not
                have permission to delete this file or if the file is
                protected.
            NavigatorFileMissingError: Raised if the file for deletion
                doesn't exist."""
        if not isinstance(src_path, NavigatorPath):
            src_path = NavigatorPath(self, src_path)
        if not src_path.is_writable(user):
            raise exceptions.NavigatorWritePermissionsError(
                'You do not have permission to modify source path.'
            )
        if src_path.is_protected():
            raise exceptions.NavigatorWritePermissionsError(
                'The path specified is protected and cannot be deleted.'
            )
        if not src_path.exists():
            raise exceptions.NavigatorFileMissingError(
                'Source file does not exist and cannot be deleted.'
            )
        if src_path.is_directory():
            shutil.rmtree(src_path.get_system_path())
        else:
            os.remove(src_path.get_system_path())

    def register_source(self, source):
        """Register a NavigatorSource object with this Navigator instance.

        Args:
            source: A NavigatorSource object."""
        if source.get_alias() in self.sources:
            raise ValueError(
                f'A source with alias {source.get_alias()}'
                + ' is already registered.'
            )
        self.sources[source.get_alias()] = source

    def unregister_source(self, source):
        """Remove a given source from this Navigator instance.

        Args:
            source: A NavigatorSource object to remove.

        Returns:
            The removed NavigatorSource object or None if none found."""
        if source.get_alias() in self.sources:
            del self.sources[source.get_alias()]
            return source
        return None

    def get_source(self, alias):
        """Get a registered NavigatorSource by it's alias.

        Args:
            alias: The string alias for the source.

        Returns:
            Either the NavigatorSource instance or None if not found."""
        return self.sources.get(alias)

    def get_sources(self):
        """Get a dict of sources keyed by alias.

        Returns:
            A dict of NavigatorSource objects."""
        return self.sources
