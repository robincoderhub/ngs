class NavigatorError(Exception):
    """Base exception class for a navigator error"""
    pass


class NavigatorPathError(NavigatorError):
    """Base exception class for an error to do with a path"""
    pass


class NavigatorInvalidPathError(NavigatorError):
    """Exception for if an invalid path was specified."""
    pass


class NavigatorMalformedPathError(NavigatorInvalidPathError):
    """Exception for if a badly formatted path was specified."""
    pass


class NavigatorRestrictedPathError(NavigatorInvalidPathError):
    """Exception for if a path being accessed is restrcited and
    cannot be accessed."""
    pass


class NavigatorMissingPathError(NavigatorInvalidPathError):
    """Exception if a path is valid but has no resource at it."""
    pass


class NavigatorFileError(NavigatorPathError):
    """Base exception for if an error occurred with the file being
    manipulated."""
    pass


class NavigatorFileExistsError(NavigatorFileError):
    """Exception for if an action is attempting to move a file or
    folder to a place that already has a resource at it."""
    pass


class NavigatorFileMissingError(NavigatorFileError):
    """Exception for if a file being specified does not exist"""
    pass


class NavigatorPermissionsError(NavigatorPathError):
    """Base class for a system permissions error."""
    pass


class NavigatorWritePermissionsError(NavigatorPermissionsError):
    """Exception for a file writing permissions error."""
    pass


class NavigatorReadPermissionsError(NavigatorPermissionsError):
    """Exception for a file reading permissions error."""
    pass
