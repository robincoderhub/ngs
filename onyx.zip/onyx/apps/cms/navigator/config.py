"""Navigator APP config classes"""

from onyx.config import AbstractOnyxConfig


class CMSNavigatorConfig(AbstractOnyxConfig):
    """Default config for navigator app"""

    name = "onyx.apps.cms.navigator"
    """The python path to the app"""

    verbose_name = "Onyx - CMS - Navigator"
    """The human readable name of the app"""

    label = "onyx_cms_navigator"
    """The internal Django name of the app"""
