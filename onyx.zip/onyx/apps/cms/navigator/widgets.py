from django.forms.widgets import Input

from django.urls import reverse_lazy


class NavigatorInput(Input):
    """A base navigator input widget class, displays a button
    to open the navigator and inserts the path selected.

    Args:
        attrs: Optional, specify attributes for this field
        system_paths: Defaults to True, displays system path sources,
            i.e. non media file paths.
        url_paths: Defaults to True display url path sources, i.e.
            media paths that can be accessed via url.
        select_url: Defaults to False, when a user selects a path,
            insert the system path into the input. If True, inserts
            the relative url into the input.
        select_full_url: Defaults to False, if select_url is True and this
            is True, will insert the fully qualified url of file into the
            input.
        sources: Optional, allows you to specify the names of specific
            sources to browse."""

    input_type = 'text'
    """Sets the input 'type' attribute."""

    template_name = 'onyx/apps/cms/navigator/widget.html'
    """The widget template path."""

    def __init__(
        self, attrs=None, system_paths=True,
        url_paths=True, select_url=False,
        select_full_url=False, sources=None
    ):
        attrs = attrs or {}
        attrs['data-api-url'] = reverse_lazy('navigator:api')
        attrs['data-system-paths'] = '1' if system_paths else '0'
        attrs['data-url-paths'] = '1' if url_paths else '0'
        attrs['data-select-url'] = '1' if select_url else '0'
        attrs['data-select-full-url'] = '1' if select_full_url else '0'
        attrs['data-sources'] = "|".join(sources) if sources else '*'
        super().__init__(attrs=attrs)


class NavigatorURLInput(NavigatorInput):
    """A form widget for selecting a url of a navigator path

    Args:
        attrs: Optional, attributes to set on the input
        select_full_url: Defaults to False, if True will insert
            the fully qualified url of the path into the input.
        sources: Allows you to specify the specific names of the sources
            to browse."""
    def __init__(self, attrs=None, select_full_url=False, sources=None):
        super().__init__(
            attrs,
            system_paths=False,
            url_paths=True,
            select_url=True,
            select_full_url=select_full_url,
            sources=sources
        )


class NavigatorPathInput(NavigatorInput):
    """A form widget for selecting a the system path of a navigator path

    Args:
        attrs: Optional, attributes to set on the input
        sources: Allows you to specify the specific names of the sources
            to browse."""
    def __init__(self, attrs=None, sources=None):
        super().__init__(
            attrs,
            system_paths=True,
            url_paths=False,
            select_url=False,
            sources=sources
        )
