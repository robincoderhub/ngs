"""Settings related to navigator app"""

from django.conf import settings


NAVIGATOR_SOURCES = getattr(settings, 'NAVIGATOR_SOURCES', [])
"""A list of dicts defining NavigatorSource objects for the navigator,
these are the directories to be managed by the navigator app. Dicts are
used as keyword arguments for initialisation for NavigatorSource objects."""


NAVIGATOR_PATH_CATEGORIES = getattr(
    settings,
    'NAVIGATOR_PATH_CATEGORIES',
    {
        'AUDIO': 'audio',
        'ARCHIVE': 'archive',
        'CODE': 'code',
        'DATABASE': 'database',
        'DOCUMENT': 'document',
        'DIRECTORY': 'directory',
        'DISK': 'disk',
        'EXECUTABLE': 'executable',
        'FONT': 'font',
        'IMAGE': 'image',
        'OTHER': 'other',
        'PRESENTATION': 'presentation',
        'SYSTEM': 'system',
        'VIDEO': 'video'
    }
)
"""The categories and human names for various 'path' types, the
key is the 'id' and the value is the human name displayed."""


NAVIGATOR_DEFAULT_CATEGORY = 'OTHER'
"""The default category for paths that cannot be identified, this
typically won't need changed."""


NAVIGATOR_PATH_EXTENSIONS = getattr(
    settings,
    'NAVIGATOR_PATH_EXTENSIONS',
    {
        'AUDIO': [
            'aif', 'cda', 'mid', 'midi', 'mp3',
            'mpa', 'ogg', 'wav', 'wma', 'wpl'
        ],
        'ARCHIVE': [
            'tar.gz', 'tar', 'gz', '7z', 'arj',
            'deb', 'pkg', 'rar', 'rpm', 'z',
            'zip'
        ],
        'CODE': [
            'py', 'asp', 'aspx', 'cfm', 'cgi',
            'pl', 'css', 'htm', 'html', 'js',
            'jsp', 'part', 'php', 'rss', 'xhtml',
            'c', 'class', 'cpp', 'cs', 'h',
            'java', 'swift', 'vb'
        ],
        'DATABASE': [
            'csv', 'dat', 'db', 'dbf', 'log',
            'mdb', 'sav', 'sql', 'xml', 'ods',
            'xlr', 'xls', 'xlsx'
        ],
        'DOCUMENT': [
            'doc', 'docx', 'pdf', 'rtf', 'tex',
            'txt', 'wks', 'wps', 'wpd', 'md'
        ],
        'DISK': [
            'bin', 'dmg', 'iso', 'toast', 'vcd'
        ],
        'EXECUTABLE': [
            'apk', 'bat', 'bin', 'com', 'exe',
            'gadget', 'jar', 'pyc', 'wsf', 'sh'
        ],
        'FONT': [
            'fnt', 'fon', 'otf', 'ttf'
        ],
        'IMAGE': [
            'ai', 'ico', 'ps', 'tif', 'tiff',
            'gif', 'jpeg', 'jpg', 'jif', 'jfif',
            'jp2', 'jpx', 'j2k', 'j2c', 'fpx',
            'pcd', 'png', 'bmp', 'ppm', 'pgm',
            'pbm', 'pnm', 'webp', 'hdr', 'heif',
            'bat', 'svg'
        ],
        'PRESENTATION': [
            'odp', 'pps', 'ppt', 'pptx'
        ],
        'SYSTEM': [
            'bak', 'cab', 'cfg', 'cpl', 'cur',
            'dll', 'dmp', 'srv', 'icns', 'ini',
            'conf', 'lnk', 'msi', 'sys', 'tmp',
            'key', 'cert', 'pem'
        ],
        'VIDEO': [
            '3g2', '3gp', 'avi', 'flv', 'h264',
            'm4v', 'mkv', 'mov', 'mp4', 'mpg',
            'mpeg', 'rm', 'swf', 'vob', 'wmv'
        ]
    }
)
"""A dict keyed by path category 'id' -> value is a list of
file extensions that fall into those categories"""
