"""Settings for the CMS app and their defaults"""

from django.conf import settings


AUTOLOAD_WIDGET_DATA = getattr(settings, 'AUTOLOAD_WIDGET_DATA', True)
"""Whether or not to automatically load all widget data on load"""


EXTRA_WIDGET_FIELDS = getattr(settings, 'EXTRA_WIDGET_FIELDS', {})
"""A dict keyed by internal name -> field class python path. This adds
additional field type to widgets. This must be loaded before widgets."""


SYSTEM_CHUNKS_SETTINGS = getattr(settings, 'SYSTEM_CHUNKS', {})
"""A dict of 'system' chunks to create with the create_system_chunks management
command. Any chunks that are part of the design of the site and must exist
should go here. The format is key = internal name of chunk i.e. 'company_info'
and the value is a dict containing keyword argumments for chunk fields.

Example:
    ```
    SYSTEM_CHUNKS = {
        'company_registration': {
            'label': 'Company Registration',
            'description': 'Company registration information in the footer'
        }
    }
    ```
"""
