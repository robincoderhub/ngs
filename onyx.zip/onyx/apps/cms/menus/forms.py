"""Forms related to the CMS menus app."""

from django import forms

from onyx.apps.cms.menus.core import get_menu_item_types
from onyx.forms.fields import FlexibleURLField, InternalNameField


class MenuItemTypeForm(forms.Form):
    """Global form for a menu item type, all menu items have
    these values.

    Args:
        *args: Inherited arguments
        **kwargs: Inherited keyword arguments."""

    label = forms.CharField()
    """Field for the human readable name of the item."""

    name = InternalNameField(label='Internal Name')
    """The internal name for this menu item."""

    item_type = forms.ChoiceField()
    """The menu item type, this is the string alias of the menu item."""

    weight = forms.IntegerField(label='Order', min_value=0)
    """Weight or order of the menu item, defines position in menu."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        choices = []
        for key, typeTuple in get_menu_item_types().items():
            choices.append(
                (key, typeTuple[0])
            )
        self.fields['item_type'].choices = sorted(choices, key=lambda x: x[1])


class MenuItemForm(forms.Form):
    """Form for basic MenuItem type."""

    url = FlexibleURLField(required=False)
    """An optional url field, accepts relative and absolute urls."""

    class_names = forms.CharField(
        help_text='CSS class names seperated by spaces.',
        required=False
    )
    """Additional CSS classes to add to menu item."""
