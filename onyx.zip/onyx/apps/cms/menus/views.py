"""View related to the CMS menus app."""

from django.http import Http404
from django.views.generic import TemplateView

from onyx.apps.cms.menus.core import get_menu_item_class
from onyx.apps.cms.menus.forms import MenuItemTypeForm


class MenuEditorView(TemplateView):
    """A view providing for editing menu items, processes and
    renders a form to be fetched via ajax in the CMS."""

    template_name = 'onyx/apps/admin/cms/menus/widgets/menu_editor_form.html'
    """The template name of the form template"""

    def dispatch(self, request):
        """Dispatch override, handles request

        Args:
            request: The django request object.

        Returns:
            A Django response instance."""
        status_code = 200
        item_type = request.GET.get('item_type', 'menu_item')
        item_class = get_menu_item_class(item_type)
        if not item_class:
            raise Http404()
        item_form_class = item_class.get_item_form_class()
        data = request.POST if request.method == 'POST' else None
        type_form = MenuItemTypeForm(
            data=data,
            initial={
                'item_type': item_type
            }
        )
        item_form = item_form_class(
            data=data
        )
        if request.method == 'POST':
            all_valid = all([type_form.is_valid(), item_form.is_valid()])
            if not all_valid:
                status_code = 400
        return self.render_to_response({
            'type_form': type_form,
            'item_form': item_form
        }, status=status_code)
