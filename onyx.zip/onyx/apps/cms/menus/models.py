"""Models related to the CMS menus app."""

from django.db import models
from django.contrib.postgres.fields import JSONField

from onyx.models.fields import InternalNameField
from onyx.apps.cms.menus.items import MenuItemTree
from onyx.apps.cms.menus.core import get_menu_item_class


class Menu(models.Model):
    """Represents a CMS managed menu"""

    title = models.CharField(max_length=255)
    """A human readable title for this menu."""

    name = InternalNameField()
    """An internal name to reference this menu easily."""

    def __str__(self):
        """Returns a representation of this menu

        Returns:
            The human readable title of this menu."""
        return self.title

    def to_menu_tree(self):
        """Convert this menu and all it's sub models into a menu
        tree for use in templates.

        Returns:
            A MenuItemTree instance."""
        def recursive_add(item):
            item_class = get_menu_item_class(item.type_key)
            item_instance = item_class(
                name=item.name,
                label=item.label,
                node_weight=item.weight,
                data=item.data
            )
            for child in item.children.all():
                item_instance.node_children.append(recursive_add(child))
            return item_instance
        tree = MenuItemTree()
        for item in self.items.filter(parent=None):
            tree.append(recursive_add(item))
        return tree


class MenuItem(models.Model):
    """A model representing a menu item."""

    menu = models.ForeignKey(
        Menu,
        on_delete=models.CASCADE,
        related_name='items'
    )
    """The menu this model belongs to"""

    parent = models.ForeignKey(
        'onyx_cms_menus.MenuItem',
        on_delete=models.CASCADE,
        related_name='children',
        null=True,
        default=None
    )
    """The parent menu menu item of this item, optional."""

    label = models.CharField(max_length=255)
    """The human readable name of this item."""

    name = InternalNameField(blank=True)
    """An internal name alias for this menu item, used to reference
    this item in selecctors."""

    type_key = models.CharField(max_length=255)
    """The menu item type alias, relates to globally registered types."""

    weight = models.IntegerField(default=0)
    """The weight or order of this menu item."""

    data = JSONField()
    """A JSON field for storing data related to the menu item form."""

    def __str__(self):
        """Get a representation of this model

        Returns:
            The human readable label of this item."""
        return self.label
