"""Menu item type node classes"""

from django.core.exceptions import ValidationError

from onyx.utils import nodes
from onyx.utils.conditionals import validate_conditions
from onyx.forms.utils import to_internal_name
from onyx.apps.cms.menus.forms import MenuItemForm


class MenuItemTree(nodes.NodeTree):
    """A node tree with additional functionality for handling menu items."""

    def prune_by_permissions(self, user):
        """Prune a menu by the permissions needed for each item, i.e. removes
        items if given user does not have the required permissions to view
        them.

        Args:
            user: The user to test the permissions of."""

        def permissions_validator(user, permission):
            return user.has_perm(permission)

        def prune_nodes(node_tree):
            kill_nodes = []
            for node in node_tree:
                permissions = node.get_required_permissions()
                if (
                    permissions
                    and not validate_conditions(
                        permissions_validator,
                        user,
                        permissions
                    )
                ):
                    kill_nodes.append(node)
                else:
                    prune_nodes(node.get_node_children())
            for node in kill_nodes:
                node_tree.remove_node(node_tree.get_node_selector(node))
        prune_nodes(self)

    def get_node_by_url(self, url):
        """Get a menu item node by the given url

        Args:
            url: The url to test for

        Returns:
            A menu item node or None if not found."""
        persist = {'found_node': None}

        def callback(callback_node, callback_selector, *args, persist):
            if (
                hasattr(callback_node, 'get_url')
                and callback_node.get_url() == url
            ):
                persist['found_node'] = callback_node
                return True
            return callback_node
        self.walk_node_tree(callback, persist=persist)
        return persist['found_node']

    def get_breadcrumbs(self, node):
        """Get breadcrumbs for a given node

        Args:
            node: The node to get crumbs for.

        Returns:
            A list of tuples containing (human label, url)"""
        chain = self.get_node_chain(self.get_node_selector(node))
        crumbs = []
        for parent_node in chain:
            crumbs.append(
                (
                    parent_node.get_label(),
                    parent_node.get_url()
                )
            )
        return crumbs


class BaseMenuItem(nodes.TemplateNode):
    """Base menu item type class

    Args:
        label: The human readable label of this item
        name: Optional, the internal name of this item, if not given generates
            a name from the label.
        data: Optional, The associated data dict for this item, the config.
        required_permissions: Optional, a conditional object of permissions
        **kwargs: Inherited keyword arguments"""

    item_form_class = None
    """The form class for getting the configuration data for this item
    type."""

    @classmethod
    def get_item_form_class(cls):
        """Get the form class used for getting the configuration data for this item
        type.

        Raises:
            NotImplementedError: Thrown if no item_form_class attribute is set
                or method has not been overidden.

        Returns:
            A form class."""
        if not cls.item_form_class:
            raise NotImplementedError('item_form_class has not been defined')
        return cls.item_form_class

    def __init__(
        self, label, name=None, data=None,
        required_permissions=None, **kwargs
    ):
        super().__init__(
            node_name=name or to_internal_name(label),
            node_tree_class=MenuItemTree,
            **kwargs
        )
        self.label = label
        self.data = data or {}
        self.required_permissions = required_permissions
        self.item_form = self.__class__.get_item_form_class()(data=self.data)
        self.item_form.is_valid()  # Call once to populate errors/data

    def get_context_data(self, **kwargs):
        """Get context data for rendering this menu item

        Args:
            **kwargs: The existing context keywords

        Returns:
            The updated context dict."""
        context = super().get_context_data(**kwargs)
        form = self.get_item_form()
        if not form.is_valid():
            raise ValidationError('This nodes data does not validate')
        context['item'] = self
        context['name'] = self.get_node_name()
        context['label'] = self.get_label()
        context['data'] = form.cleaned_data
        return context

    def get_label(self):
        """Get human readable label for this item.

        Returns:
            The string label."""
        return self.label

    def get_item_form(self):
        """Get the item form instance for this item.

        Returns:
            A form instance."""
        return self.item_form

    def get_required_permissions(self):
        """Get required permissions to view this menu item.

        Returns:
            A conditional object or None if none specified."""
        return self.required_permissions

    def get_data(self):
        """Get the config data for this menu item.

        Returns:
            A dict of values."""
        return self.data

    def get_cleaned_data(self):
        """Get the cleaned data from this menu items form.

        Raises:
            ValdiationError: Thrown if current data is invalid.

        Returns:
            A dict of 'cleaned' data from this forms type form."""
        if not self.get_item_form().is_valid():
            raise ValidationError(
                f'Menu item "{self.get_node_name()}" is not valid!'
            )
        return self.get_item_form().cleaned_data

    def is_valid(self):
        """Whether or not the data set for this item is valid.

        Returns:
            True if valid, False otherwise."""
        return self.get_item_form().is_valid()

    def get_url(self):
        """Get url for this menu item.

        Returns:
            The string url or None if not set."""
        return self.get_cleaned_data().get('url')


class MenuItem(BaseMenuItem):
    """A basic menu item, optional url with a label."""

    item_form_class = MenuItemForm
    """The form class for this item."""

    template_name = 'onyx/apps/cms/menus/items/item.html'
    """The template name for this item."""


DEFAULT_ITEM_TYPES = {
    'menu_item': ('Basic Menu Item', MenuItem)
}
"""A dict of default menu item types to register on ready."""


def register_default_item_types():
    """Register default menu item types with the global register."""
    from onyx.apps.cms.menus.core import register_menu_item_type
    global DEFAULT_ITEM_TYPES
    for key, value in DEFAULT_ITEM_TYPES.items():
        register_menu_item_type(
            key,
            value[0],
            value[1]
        )
