"""Global registers to allow apps to register menu item types.

TODO:
    - Rename to register.py"""

from copy import deepcopy


MENU_ITEM_TYPES = {}
"""A register to contain different menu item classes and their human
readable titles"""


def register_menu_item_type(key, title, menu_item_class):
    """Register a menu item class with the global register

    Args:
        key: The key or alias for the menu item type
        title: The human readable name of the item type
        menu_item_class: The class of the menu item type."""
    global MENU_ITEM_TYPES
    MENU_ITEM_TYPES[key] = (
        title,
        menu_item_class
    )


def get_menu_item_title(key):
    """Get the human-readable title of a menu item type

    Args:
        key: The key or alias for the menu item type.

    Returns:
        The string title of the item type or None if not found."""
    global MENU_ITEM_TYPES
    item = MENU_ITEM_TYPES.get(key)
    return item[0] if item else None


def get_menu_item_class(key):
    """Get the class of a menu item type

    Args:
        key: The key or alias for the menu item type.

    Returns:
        A menu item type class or None if not found."""
    global MENU_ITEM_TYPES
    item = MENU_ITEM_TYPES.get(key)
    return item[1] if item else None


def get_menu_item_types():
    """Get a copy of the menu item register

    Returns:
        A dict keyed by alias to a tuple in format (human name, class)"""
    global MENU_ITEM_TYPES
    return deepcopy(MENU_ITEM_TYPES.copy())
