"""App for defining and displaying CMS managed menus."""

default_app_config = 'onyx.apps.cms.menus.config.CMSMenusConfig'
