"""Form widgets related to the CMS menus app"""

from django.forms.widgets import Input


class MenuEditorWidget(Input):
    """A menu editing widget, generates JSON data to be
    used in creating menus.

    Args:
        *args: Inherited arguments
        menu: Optional, the existing menu to edit
        **kwargs: Inherited keyword arguments."""
    template_name = 'onyx/apps/admin/cms/menus/widgets/menu_editor.html'

    def __init__(self, *args, menu=None, **kwargs):
        self.menu = menu
        super().__init__(*args, **kwargs)

    def get_context(self, *args, **kwargs):
        """Get context for rendering this widget, adds menu
        to context.

        Returns:
            The updated context dict."""
        context = super().get_context(*args, **kwargs)
        context['menu'] = self.menu
        return context
