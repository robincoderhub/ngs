"""Url patterns for the CMS menus app."""

from django.urls import path

from onyx.apps.cms.menus import views


app_name = 'menus'
urlpatterns = [
    path('editor/', views.MenuEditorView.as_view(), name='menu_editor_ajax')
]
