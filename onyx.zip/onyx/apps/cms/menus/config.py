"""App config classes for CMS menus app."""

from onyx.config import AbstractOnyxConfig


class CMSMenusConfig(AbstractOnyxConfig):
    """Default app config for CMS menus."""

    name = "onyx.apps.cms.menus"
    """The python path to the app"""

    verbose_name = "Onyx - CMS - Menus"
    """The human readable name of the app"""

    label = "onyx_cms_menus"
    """The internal Django name of the app"""

    def ready(self):
        """Register default menu item types on load."""
        from onyx.apps.cms.menus.items import register_default_item_types
        register_default_item_types()
