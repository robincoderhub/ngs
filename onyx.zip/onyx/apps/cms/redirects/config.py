"""App configs for redirects app"""

from onyx.config import AbstractOnyxConfig


class CMSRedirectsConfig(AbstractOnyxConfig):
    """Default config for redirects app"""

    name = "onyx.apps.cms.redirects"
    """The python path to the app"""

    verbose_name = "Onyx - CMS - Redirects"
    """The human readable name of the app"""

    label = "onyx_cms_redirects"
    """The internal Django name of the app"""
