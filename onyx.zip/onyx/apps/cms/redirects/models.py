"""Models for redirects app"""

from django.db import models

from onyx.models.fields import FlexibleURLField


class Redirect(models.Model):
    """Model representing a configured redirect"""

    from_path = FlexibleURLField(unique=True)
    """The path or url to redirect 'from'"""

    to_path = FlexibleURLField()
    """The path or url to redirect 'to'"""

    permanent = models.BooleanField(default=True)
    """Whether or not this is a permanant (301) or temporary (302)
    redirect, defaults to True."""
