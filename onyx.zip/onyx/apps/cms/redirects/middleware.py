"""Middleware for the redirects app"""

from django.shortcuts import redirect

from onyx.apps.cms.redirects.models import Redirect


class RedirectMiddleware:
    """Middleware class to return redirect responses for configured
    redirect.

    Args:
        get_response: The passed callable to get the natural
            response for the request."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request, *args, **kwargs):
        """Handle request, if request path matches a redirect
        model, redirect to specified path.

        Args:
            request: The incoming request object
            *args: The request arguments
            **kwargs: The request kwargs
        
        Returns:
            A django response object."""
        try:
            matching = Redirect.objects.get(from_path=request.path)
        except Redirect.DoesNotExist:
            return self.get_response(request, *args, **kwargs)
        else:
            return redirect(
                matching.to_path,
                permanent=matching.permanent
            )
