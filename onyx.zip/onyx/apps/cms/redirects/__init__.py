"""An app for defining database driven redirects."""

default_app_config = 'onyx.apps.cms.redirects.config.CMSRedirectsConfig'
