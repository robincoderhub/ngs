"""CMS related middleware"""

from django.urls import is_valid_path

from onyx.apps.cms.resolvers import resolve_to_response


class SiteNodeMiddleware:
    """Middleware for serving SiteNode content

    Args:
        get_response: The passed method to fetch and return
            a response."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request, *args, **kwargs):
        """Main middleware call, serves SiteNode content
        if the path matches unless there is a 'real' view
        at that path. Otherwise returns the response as normal.

        Args:
            request: The incoming django request
            *args: The request arguments
            **kwargs: The request keyword arguments"""
        if is_valid_path(request.path):
            return self.get_response(request, *args, **kwargs)
        response = resolve_to_response(request)
        if response:
            return response
        return self.get_response(request, *args, **kwargs)
