"""CMS related models"""

from django.core.exceptions import ValidationError
from django.db import models
from django.contrib.postgres.fields import JSONField

from onyx.models.fields import InternalNameField, URLPathField
from onyx.apps.cms.register import get_widget_type, get_node_type


class SiteNode(models.Model):
    """A SiteNode represents a piece of CMS content at a url"""

    path = URLPathField(unique=True)
    """The url path to respond on i.e. /my-page/"""

    internal_name = models.CharField(max_length=255, blank=True, null=True)
    """An internal name to reference this particular page/node"""

    node_type = models.CharField(max_length=255)
    """The internal name of the 'type' of node this is"""

    last_updated = models.DateTimeField(auto_now=True)
    """Last update stamp"""

    published = models.BooleanField(default=False)
    """Whether or not this is published, only published nodes will display"""

    data = JSONField()
    """A postgres JSON field that contains the information required to display this
    node"""

    def __str__(self):
        """Renders a string representation of this SiteNode

        Returns:
            A string representation of the node, if the type cannot
            be found will return 'Unknown Node'."""
        node_type = get_node_type(self.node_type)
        if node_type:
            return f"{node_type.get_label()} at {self.path}"
        return f"Unknown Node at {self.path}"


class Widget(models.Model):
    """A widget, a peice of content inside a chunk which will
    render on the front end."""

    widget_type = models.CharField(max_length=255)
    """The internal name of the widget type this is"""

    data = JSONField()
    """The related data and options of this widget."""

    order = models.PositiveIntegerField(default=0)
    """The order of this widget in the parent chunk"""

    def __str__(self):
        """Renders a string representation of this widget

        Returns:
            A string representation of the widget, if the type cannot
            be found will return 'Unknown Widget'."""
        if self.widget_type:
            widget_type = get_widget_type(self.widget_type)
            if widget_type:
                return f"{widget_type.get_label()} Widget"
        return "Unknown Widget"


class Chunk(models.Model):
    """A chunk is a container for widgets, a chunk can belong
    to anything."""

    chunk_name = InternalNameField(max_length=255)
    """The internal name of the chunk, this is used to reference
    this chunk."""

    label = models.CharField(max_length=255)
    """The human readable label of this chunk"""

    description = models.CharField(max_length=255, blank=True)
    """The human readable description of this chunk"""

    widgets = models.ManyToManyField(Widget, related_name='chunks')
    """A manytomany field of widgets"""

    global_chunk = models.BooleanField(default=False)
    """If set to True, this chunk can be referenced by template tags
    anywhere by name."""

    system_chunk = models.BooleanField(default=False)
    """Whether or not this chunk is a 'system' chunk and therefore
    should not be removed as it is part of the design of the site."""

    def clean(self):
        """Extended clean method to ensure if chunk is global there isn't
        another chunk of the same name.

        Raises:
            ValidationError: If name conflicts with another global chunk"""
        super().clean()
        if self.global_chunk:
            existing_chunks = Chunk.objects.filter(
                chunk_name=self.chunk_name,
                global_chunk=True
            )
            if (
                existing_chunks.count() == 1
                and existing_chunks[0].id != self.id
            ):
                raise ValidationError('Global chunk names must be unique.')

    def __str__(self):
        """Returns a string representation of this chunk.

        Returns:
            The string represenation of this Chunk"""
        if self.label:
            return f"{self.label} Chunk"
        elif self.chunk_name:
            return f"{self.chunk_name} Chunk"
        return super().__str__()

    def delete(self):
        """Extended delete method to delete associated
        widgets.
        
        Returns:
            The default return value of the delete method"""
        for widget in self.widgets.all():
            widget.delete()
        return super().delete()


class Page(models.Model):
    """A model representing a CMS page."""

    node = models.OneToOneField(
        SiteNode,
        primary_key=True,
        on_delete=models.CASCADE
    )
    """The SiteNode that points to this page."""

    template_type = models.CharField(max_length=255)
    """The template type of this page."""

    data = JSONField()
    """The associated data for this template type"""

    chunks = models.ManyToManyField(Chunk, related_name='pages')
    """The chunks that are part of this pages."""

    def __str__(self):
        """String representation of this Page

        Returns:
            The string representation of this page."""
        try:
            return str(self.node)
        except SiteNode.DoesNotExist:
            return super().__str__()

    def delete(self):
        """Extended delete method to delete related chunks

        Returns:
            The inherited delete method return value"""
        for chunk in self.chunks.all():
            if not chunk.global_chunk:
                chunk.delete()
        return self.node.delete()
