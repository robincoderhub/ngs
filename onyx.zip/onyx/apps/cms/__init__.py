"""
# CMS app

This app contains the 'bedrock' of CMS handled content including
storing content and pages in the database.

"""

default_app_config = 'onyx.apps.cms.config.CMSConfig'
