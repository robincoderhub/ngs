"""SiteNode type definitions"""

from django.http import Http404, HttpResponse

from onyx.apps.cms.register import register_node_type, get_template_type


class NodeType(object):
    """The base class for SiteNode types, all type should inherit
    from this class"""

    label = 'Untitled Node Type'
    """The human readable label of this SiteNode"""

    description = None
    """The human readable description of this SiteNode"""

    node_form_class = None
    """The form class used to retrieve the data needed for this node"""

    @classmethod
    def get_label(cls):
        """Static method to get the label for this node
        type.

        Returns:
            The string label of this node type."""
        return cls.label

    @classmethod
    def get_description(cls):
        """Static method to get the description for this node
        type.

        Returns:
            The string description of this node type."""
        return cls.description

    @classmethod
    def get_node_form_class(cls):
        """Static method to get the form class used to get
        the data for this node type.

        Returns:
            The string label of this node type."""
        return cls.node_form_class

    @classmethod
    def get_edit_url(cls, node):
        """Get the edit url for this nodes

        Args:
            node: The SiteNode to get an edit url for
        Returns:
            A url or None if none found."""
        return None

    @classmethod
    def handle_request(cls, request, node):
        """Abstract method for handling a request.

        Args:
            request: The incoming Django request
            node: The SiteNode that matched this request.

        Returns:
            A Django response."""
        raise NotImplementedError(
            'handle_request must be overidden!'
        )


class PlaceholderNodeType(NodeType):
    """Placeholder node type, this is a path that
    doesn't go anywhere but functions as a placeholder for
    other nodes to extend off of"""

    label = 'Placeholder'
    """The human readable label of this node type"""

    description = 'An empty placeholder node'
    """The human readable description of this node type."""

    @classmethod
    def handle_request(cls, request, node):
        """Return a 404 status

        Raises:
            Http404: Always"""
        raise Http404()


class PageNodeType(NodeType):
    """CMS page SiteNode type, displays a page"""

    label = 'CMS Page'
    """The human readable label of the node"""

    description = 'A CMS page'
    """The human readable description of this node type"""

    @classmethod
    def handle_request(cls, request, node):
        """Handle request and display associated page.

        Args:
            request: The incoming django request
            node: The matching SiteNode for this page.

        Raises:
            ValueError: Raises if a sitenode is passed whose
                template type cannot be found.

        Returns:
            A django response"""
        page = node.page
        template_type = get_template_type(page.template_type)
        if not template_type:
            raise ValueError(
                f'Template type "{page.template_type}" used by page'
                + f' id:{page.id} is not registered.'
            )
        return HttpResponse(template_type.render(request, page))


DEFAULT_NODES = {
    'placeholder': PlaceholderNodeType,
    'page': PageNodeType
}
"""Default 'built in' node types"""


def register_default_nodes():
    """Registers the default node types into the global
    register"""
    global DEFAULT_NODES
    for name, type_class in DEFAULT_NODES.items():
        register_node_type(name, type_class)
