"""Module that contains various global registers to store various
widget, template etc. types from various different apps."""

from copy import deepcopy


TEMPLATE_TYPES = {}
"""A dict of template type classes keyed
by internal name -> type class"""


def register_template_type(name, type_class):
    """Register a template type with the global register

    Args:
        name: The internal name of the type i.e. 'my_type'
        type_class: The TemplateType class variant to register"""
    global TEMPLATE_TYPES
    TEMPLATE_TYPES[name] = type_class


def get_template_types():
    """Get all template types as a dict keyed by internal name

    Returns:
        A dict keyed by internal name -> type class"""
    global TEMPLATE_TYPES
    return deepcopy(TEMPLATE_TYPES)


def get_template_type(name):
    """Get the template type class by internal name

    Args:
        name: The internal name of the type to retrieve.

    Returns:
        The template type class or None if not found."""
    global TEMPLATE_TYPES
    return TEMPLATE_TYPES.get(name)


def is_template_type_registered(name):
    """Check if given has a type class registered

    Args:
        name: The internal name of the type to check

    Returns:
        True if registered otherwise False."""
    return get_template_type(name) is not None


WIDGET_TYPES = {}
"""A dict of widget type classes keyed
by internal name -> type class"""


def register_widget_type(name, type_class):
    """Register a widget type class to the global register

    Args:
        name: The internal name to register
        type_class: The widget type class to register"""
    global WIDGET_TYPES
    WIDGET_TYPES[name] = type_class


def get_widget_types():
    """Get a copy of the register dict keyed by internal
    name -> class

    Returns:
        A copy of the register dict"""
    global WIDGET_TYPES
    return deepcopy(WIDGET_TYPES)


def get_widget_type(name):
    """Get the widget class type registered to the
    given internal name.

    Returns:
        The widget class or None if not registered"""
    global WIDGET_TYPES
    return WIDGET_TYPES.get(name)


def is_widget_type_registered(name):
    """Check if given internal name is registered to
    a widget type class

    Returns:
        True if registered, otherwise False."""
    return get_widget_type(name) is not None


WIDGET_FIELD_TYPES = {}
"""A dict of widget field type classes keyed
by internal name -> type class"""


def register_widget_field_type(name, type_class):
    """Register a widget field type class

    Args:
        name: The internal name to use for the field
        type_class: The field type class"""
    global WIDGET_FIELD_TYPES
    WIDGET_FIELD_TYPES[name] = type_class


def get_widget_field_types():
    """Get a copy of the field type registered, keyed by
    internal name -> type class.

    Returns:
        A dict of widget field types."""
    global WIDGET_FIELD_TYPES
    return deepcopy(WIDGET_FIELD_TYPES)


def get_widget_field_type(name):
    """Get a widget field type class by name.

    Args:
        name: The internal name of the widget type class to
            retrieve.
    Returns:
        The field type class or None if not found."""
    global WIDGET_FIELD_TYPES
    return WIDGET_FIELD_TYPES.get(name)


def is_widget_field_type_registered(name):
    """Check whether a given internal name is registered to a field type.

    Args:
        name: The internal name to check

    Returns:
        True if registered, otherwise False."""
    return get_widget_field_type(name) is not None


def create_system_chunks():
    """Create Chunks that are defined in the project's settings."""
    from onyx.apps.cms.app_settings import SYSTEM_CHUNKS_SETTINGS
    from onyx.apps.cms.models import Chunk
    from django.forms.utils import pretty_name
    for chunk_name, chunk_details in SYSTEM_CHUNKS_SETTINGS.items():
        if isinstance(chunk_details, str):
            # Allow Name -> Label defining
            label = pretty_name(chunk_details)
            chunk_details = {}
        else:
            label = chunk_details.get('label')
            if not label:
                label = pretty_name(chunk_name)
        description = chunk_details.get('description', '')

        try:
            existing_chunk = Chunk.objects.get(
                chunk_name=chunk_name,
                global_chunk=True
            )
        except Chunk.DoesNotExist:
            Chunk(
                chunk_name=chunk_name,
                label=label,
                description=description,
                global_chunk=True,
                system_chunk=True
            ).save()
            print(f'Created system chunk "{chunk_name}"')
        else:
            if not existing_chunk.system_chunk:
                existing_chunk.system_chunk = True
                existing_chunk.save()
                print(
                    f'Updated existing chunk "{chunk_name}" to be a system chunk.'
                )
            else:
                print(
                    f'System chunk "{chunk_name}" already exists, skipping..'
                )


NODE_TYPES = {}
"""A dict of SiteNode type classes keyed
by internal name -> type class"""


def register_node_type(name, node_type):
    """Register a node type class

    Args:
        name: The internal name to use for the node
        node_type: The node type class"""
    global NODE_TYPES
    NODE_TYPES[name] = node_type


def is_node_type_registered(name):
    """Whether or not a node type is registered at the given
    name.

    Args:
        name: The internal name of the node to check

    Returns:
        True if registered, False otherwise"""
    global NODE_TYPES
    return NODE_TYPES.get(name) is not None


def get_node_type(name):
    """Get a node type class registered with the given internal
    name.

    Args:
        name: The internal name of the class to get

    Returns:
        A node type class or None if not found."""
    global NODE_TYPES
    return NODE_TYPES.get(name)


def get_node_types():
    """Get a copy of the node type register dict.

    Returns:
        A dict of node type classes keyed by internal name"""
    global NODE_TYPES
    return deepcopy(NODE_TYPES)


REQUEST_RESOLVERS = {}
"""A dict of request resolvers to be used by the middleware to determine
what to server."""


def register_request_resolver(name, resolver, order):
    """Register a request resolver class.

    Args:
        name: The internal name to register it under
        resolve: The resolver class to register.
        order: The order in which it should accessed."""
    global REQUEST_RESOLVERS
    REQUEST_RESOLVERS[name] = [order, resolver]


def unregister_request_resolver(name):
    """Remove a resolve from the register with the given
    internal name.

    Args:
        name: the internal name of the resolver to unregister"""
    global REQUEST_RESOLVERS
    if name in REQUEST_RESOLVERS:
        del REQUEST_RESOLVERS[name]


def modify_request_resolver_order(name, order):
    """Change the order of a registered resolver.

    Args:
        name: The internal name of the resolver to modify
        order: The new order to set."""
    global REQUEST_RESOLVERS
    REQUEST_RESOLVERS[name][0] = order


def get_request_resolver(name):
    """Get request resolver by internal name

    Args:
        name: The internal name to lookup

    Returns:
        The resolver class or None if not found."""
    global REQUEST_RESOLVERS
    entry = REQUEST_RESOLVERS.get(name)
    return entry[1] if entry else None


def get_request_resolver_order(name):
    """Get the order for a particular resolver by
    internal name.

    Args:
        name: The internal name to check

    Returns:
        The numeric order or None if not found"""
    global REQUEST_RESOLVERS
    entry = REQUEST_RESOLVERS.get(name)
    return entry[0] if entry else None


def get_request_resolvers():
    """Get a copy of the request resolvers dict

    Returns:
        A dict of request resolver keyed by internal name =>
        a tuple containing (order, class)"""
    global REQUEST_RESOLVERS
    return deepcopy(REQUEST_RESOLVERS)


def get_ordered_resolvers():
    """Get order classes in a list ordered by their
    defined order.

    Returns:
        A list of resolver classes in order."""
    global REQUEST_RESOLVERS
    resolver_objects = [
        resolver_obj
        for resolver_obj in REQUEST_RESOLVERS.values()
    ]
    resolver_objects.sort(key=lambda x: x[0])
    return [
        resolver_obj[1]
        for resolver_obj in resolver_objects
    ]
