"""Module for loading template-based widgets."""

import os
import json
from copy import deepcopy

from django import forms
from django.template.loader import get_template, TemplateDoesNotExist
from django.forms.utils import pretty_name

from onyx.utils.template import get_template_list
from onyx.apps.cms.widgets import TemplateWidgetType
from onyx.apps.cms.register import register_widget_type, get_widget_field_type


def generate_widget_form(fields):
    """Generate a form for a widget

    Args:
        fields: A dict based on the json object loaded
            for this widget.

    Returns:
        A django form"""
    class GeneratedForm(forms.Form):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            for field_name, field_data in fields.items():
                if isinstance(field_data, str):
                    # allow 'name' => 'type'  with no options
                    field_type = field_data
                    field_data = {}
                field_type = field_data['type'].lower()
                if field_type == 'group':
                    raise ValueError(
                        'Cannot define a field group inside a field group!'
                    )
                else:
                    field_kwargs = deepcopy(field_data)
                    del field_kwargs['type']
                    type_class = get_widget_field_type(field_type)
                    self.fields[field_name] = type_class\
                        .get_field_instance(
                            **field_kwargs
                        )
    return GeneratedForm


def load_widget_from_template(template_name, settings_template_name=None):
    """Load a widget from a given template and the detected or passed settings
    object.

    Args:
        template_name: The template path for this widget.
        settings_template_name: Optional, a path to settings json
            file for this widget, if none is provided will detect
            if there's a file with the same name but with a 'json'
            extension i.e. 'widgets/banner.html' -> 'widgets/banner.json'

    Returns:
        A tuple containing (widget name, widget class)"""
    file_name = os.path.basename(template_name)
    widget_name = file_name.split('.')[0]
    widget_label = pretty_name(widget_name)
    widget_description = None
    widget_class_prefix = widget_name.capitalize().replace(
        '_', ''
    )
    widget_class_name = f"{widget_class_prefix}GeneratedWidget"
    if not settings_template_name:
        settings_template_name = (
            f"{os.path.dirname(template_name)}/{widget_name}.json"
        )
    settings_tpl = None
    widget_forms = {}
    try:
        settings_tpl = get_template(settings_template_name)
    except TemplateDoesNotExist:
        widget_forms['basic_details'] = forms.Form
    else:
        settings_object = json.loads(settings_tpl.template.source)
        widget_label = settings_object.get('label', widget_label)
        widget_description = settings_object.get('description')
        widget_name = settings_object.get('name', widget_name)
        widget_class_name = settings_object.get('class_name', widget_name)
        groups = {}
        fields = json.loads(settings_tpl.template.source).get('fields', {})
        for key, field in fields.items():
            if field['type'] == 'group':
                groups[key] = field
        for key in groups.keys():
            del fields[key]
        widget_forms['basic_details'] = generate_widget_form(fields)
        for key, group in groups.items():
            group_form = generate_widget_form(group.get('fields'))
            formset_options = {
                'can_delete': True
            }
            formset_options.update(group)
            del formset_options['type']
            del formset_options['fields']
            widget_forms[key] = forms.formset_factory(
                group_form,
                **formset_options
            )
    widget_class = type(
        widget_class_name,
        (
            TemplateWidgetType,
        ),
        {
            "template_name": template_name,
            "label": widget_label,
            "description": widget_description,
            "widget_form_classes": widget_forms
        }
    )
    return (widget_name, widget_class)


def discover_widgets(register_widgets=True):
    """Discover and register template based widgets, this
    functio will look in any template path that contains
    'cms_widgets/' folder.

    Args:
        register_widgets: Defaults to True, whether or not to
            register the widgets that are found with the global
            register.

    Returns:
        A list of tuples containing (widget name, widget class)"""
    templates = get_template_list()
    widgets = []
    for template_name in templates:
        if 'cms_widgets/' in template_name and not template_name.endswith(
            '.json'
        ):
            widget_name, widget_class = load_widget_from_template(
                template_name
            )
            if register_widgets:
                register_widget_type(widget_name, widget_class)
            widgets.append((widget_name, widget_class))
    return widgets
