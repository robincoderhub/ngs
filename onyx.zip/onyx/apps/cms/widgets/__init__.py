"""Widget core module for CMS app"""

from django.template.loader import render_to_string

from onyx.apps.cms.forms import ChunkWidgetTypeForm


class WidgetType(object):
    """Base class for a widget type, defines the parameters
    and behaviour of a widget."""

    label = 'Untitled Widget'
    """The human readable title of the widget."""

    description = None
    """The human readable description of the widget."""

    widget_form_classes = None
    """A dict of form classes to use for defining this widget
    keyed by alias."""

    @classmethod
    def get_widget_form_class(cls, key):
        """Get the form class with the passed key

        Args:
            The key/alias of the form

        Returns:
            A form class or None if not found."""
        return (
            cls.widget_form_classes.get(key)
            if cls.cls.widget_form_classes
            else None
        )

    @classmethod
    def get_widget_form_classes(cls):
        """Get dict form classes keyed by their alias for
        this template type.

        Returns:
            A dict of form classes keyed by alias"""
        return cls.widget_form_classes

    @classmethod
    def get_label(cls):
        """Getter for human name of this widget

        Returns:
            The string title of this widget."""
        return cls.label

    @classmethod
    def get_description(cls):
        """Getter for human description of this widget.

        Returns:
            The string description of this widget."""
        return cls.description

    @classmethod
    def render(cls, context, widget_data):
        """Render the widget to a string

        Attrs:
            context: The template context
            widget_data: A dict of options keyed by the related
                form classes alias.

        Raises:
            NotImplementedError: Override this method.

        Returns:
            A rendered string of the widget."""
        raise NotImplementedError('Must define render method.')


class TemplateWidgetType(WidgetType):
    """Base class for a widget that uses a template to render
    itself."""

    template_name = None
    """The name of the template for this widget."""

    @classmethod
    def get_template_name(cls):
        """Get the template name to use for rendering
        this widget.

        Raises:
            NotImplementedError: Raises if no template_name attribute
                was specified or if this method was not overidden.
        
        Returns:
            The template path for this widget."""
        if not cls.template_name:
            raise NotImplementedError(
                'Must provide a template_name or override get_template_name'
            )
        return cls.template_name

    @classmethod
    def get_context_data(cls, context, widget_data, **kwargs):
        """Get context data for the template, by default adds
        the widget_data configured to the context.

        Args:
            context: The page's context
            widget_data: The data configured for this widget keyed
                by form alias.
            **kwargs: The current context dict for this widget.

        Returns:
            The updated context dict"""
        kwargs.update(widget_data)
        return kwargs

    @classmethod
    def render(cls, context, widget_data):
        """Renders the widget from a template

        Args:
            context: The page's context
            widget_data: The data configured for this widget
                keyed by form alias.
        
        Returns:
            The rendered widget as a string."""
        return render_to_string(
            cls.get_template_name(),
            cls.get_context_data(context, widget_data),
            context.get('request')
        )


class ChunkWidgetType(TemplateWidgetType):
    """A widget that displays a global chunk."""

    label = 'Chunk'
    """The human name of this widget."""

    description = 'Insert a pre-defined content chunk'
    """The human description of this widget."""

    template_name = 'onyx/apps/cms/widgets/chunk.html'
    """The template used for this widget."""

    widget_form_classes = {
        'basic_details': ChunkWidgetTypeForm
    }
    """The widget forms for this widget."""
