"""Widget form field classes, these are used for automatically generating
widgets and their forms from detected 'template' style widgets."""

from phonenumber_field.formfields import PhoneNumberField

from django import forms

from onyx.utils import import_dotted_path
from onyx.forms.fields import TinyMCEField, InternalNameField, FlexibleURLField
from onyx.apps.cms.navigator.widgets import NavigatorURLInput
from onyx.apps.cms.app_settings import EXTRA_WIDGET_FIELDS
from onyx.apps.cms.register import register_widget_field_type


class WidgetFieldType(object):
    """A definition for a widget field."""

    field_class = None
    """The form field class to use to create this field."""

    field_kwargs = None
    """Optional, the keyword arguments to pass to the field."""

    widget_class = None
    """Optional, the widget class to use."""

    @classmethod
    def get_field_instance(cls, **kwargs):
        """Create and return an instance of this field

        Args:
            **kwargs: Keywords to pass to the field.

        Returns:
            A Django form field class"""
        return cls.get_field_class()(
            **cls.get_field_kwargs(**kwargs)
        )

    @classmethod
    def get_field_class(cls):
        """Get the field class for this definition

        Returns:
            The field class"""
        return cls.field_class

    @classmethod
    def get_field_kwargs(cls, **kwargs):
        """Get keyword arguments for creating this form field.

        Args:
            **kwargs: The current field kwargs

        Returns:
            The updated keyword arguments."""
        if cls.field_kwargs:
            kwargs.update(cls.field_kwargs)
        kwargs['widget'] = cls.get_field_widget()
        return kwargs

    @classmethod
    def get_field_widget(cls):
        """Get the field widget instance

        Returns:
            The field widget instance or None if no widget
            is specified."""
        return cls.widget_class() if cls.widget_class else None


class TextFieldType(WidgetFieldType):
    """Field type for a CharField"""
    field_class = forms.CharField


class TextAreaFieldType(TextFieldType):
    """Field type for a CharField with a Textarea widget"""
    widget_class = forms.Textarea


class EmailFieldType(WidgetFieldType):
    """Field type for a EmailField"""
    field_class = forms.EmailField


class IntegerFieldType(WidgetFieldType):
    """Field type for an IntegerField"""
    field_class = forms.IntegerField()


class DateFieldType(WidgetFieldType):
    """Field type for a DateField"""
    field_class = forms.DateField


class DateTimeFieldType(WidgetFieldType):
    """Field type for a DateTimeField"""
    field_class = forms.DateTimeField


class TimeFieldType(WidgetFieldType):
    """Field type for a TimeField"""
    field_class = forms.TimeField


class URLFieldType(WidgetFieldType):
    """Field type for an onyx FlexbileURLField (relative and full
    urls)"""
    field_class = FlexibleURLField


class ImageURLFieldType(WidgetFieldType):
    """Field type for an onyx FlexbileURLField (relative and full
    urls) with a NavigatorURLInput widget."""
    field_class = FlexibleURLField
    widget_class = NavigatorURLInput


class DecimalFieldType(WidgetFieldType):
    """Field type for a DecimalField"""
    field_class = forms.DecimalField


class PhoneNumberFieldType(WidgetFieldType):
    """Field type for a PhoneNumberField"""
    field_class = PhoneNumberField


class IPAddressFieldType(WidgetFieldType):
    """Field type for a GenericIPAddressField"""
    field_class = forms.GenericIPAddressField


class ChoiceFieldType(WidgetFieldType):
    """Field type for a ChoiceField"""
    field_class = forms.ChoiceField


class MultipleChoiceFieldType(WidgetFieldType):
    """Field type for a MultipleChoiceField"""
    field_class = forms.MultipleChoiceField


class BooleanFieldType(WidgetFieldType):
    """Field type for a BooleanField"""
    field_class = forms.BooleanField


class TinyMCEFieldType(WidgetFieldType):
    """Field type for a TinyMCEField editor"""
    field_class = TinyMCEField


class InternalNameFieldType(WidgetFieldType):
    """Field type for an onyx InternalNameField"""
    field_class = InternalNameField


DEFAULT_FIELD_TYPES = {
    'html': TinyMCEFieldType,
    'text': TextFieldType,
    'textarea': TextAreaFieldType,
    'email': EmailFieldType,
    'number': IntegerFieldType,
    'date': DateFieldType,
    'datetime': DateTimeFieldType,
    'time': TimeFieldType,
    'url': URLFieldType,
    'image': ImageURLFieldType,
    'decimal': DecimalFieldType,
    'phone': PhoneNumberFieldType,
    'ip': IPAddressFieldType,
    'choice': ChoiceFieldType,
    'choice_multi': MultipleChoiceFieldType,
    'boolean': BooleanFieldType,
    'internal': InternalNameFieldType
}


def register_default_field_types():
    """Register default field types in register"""
    for name, type_class in DEFAULT_FIELD_TYPES.items():
        register_widget_field_type(name, type_class)


def register_extra_widget_field_types():
    """Register additional field widget types defined in settings
    by the EXTRA_WIDGET_FIELDS setting."""
    for field_name, dotted_path in EXTRA_WIDGET_FIELDS:
        register_widget_field_type(
            field_name,
            import_dotted_path(dotted_path)
        )
