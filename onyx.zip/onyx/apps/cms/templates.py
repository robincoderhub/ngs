"""CMS template related code."""

from django.template.loader import render_to_string

from onyx.apps.cms.forms import BasicTemplateForm


class TemplateType(object):
    """Template type base class, this class defines a CMS
    template to be used on the front end"""

    label = 'Untitled Template'
    """The human readable name of the template"""

    description = 'No description'
    """The human readable description of the template"""

    type_form_class = None
    """A form class for getting the information required for this
    template, template variables. An example would be the title of
    the page etc."""

    template_name = None
    """The path to the django template"""

    chunks = []
    """A list of Chunk models to be used when creating an instance
    of this template."""

    @classmethod
    def get_label(cls):
        """Get human readable name of this template

        Returns:
            The string name"""
        return cls.label

    @classmethod
    def get_description(cls):
        """Get human readable description of this template

        Returns:
            The string description"""
        return cls.description

    @classmethod
    def get_type_form_class(cls):
        """Get the type form for this template

        Returns:
            The template form class"""
        return cls.type_form_class

    @classmethod
    def get_chunks(cls):
        """Get the list of Chunk models
        associated with this template.

        Returns:
            A list of Chunk models"""
        return cls.chunks

    @classmethod
    def get_template_name(cls):
        """Get django template to be used for rendering
        this template.

        Returns:
            The path to the template."""
        return cls.template_name

    @classmethod
    def get_context_data(cls, request, page):
        """Get context data to be used when rendering this template

        Args:
            request: The incoming Django request
            page: The Page model found for this page.

        Returns:
            A dict of context data."""
        context = {}
        context.update(page.data)
        context['chunks'] = {
            chunk.chunk_name: chunk
            for chunk in page.chunks.all()
        }
        return context

    @classmethod
    def render(cls, request, page):
        """Render this template and return a response

        Args:
            request: The incoming Django request
            page: The Page model that matches this page.

        Returns:
            A django response."""
        return render_to_string(
            cls.get_template_name(),
            context=cls.get_context_data(request, page),
            request=request
        )


class BasicTemplateType(TemplateType):
    """A basic template type that contains title and meta
    data associated with most templates."""

    type_form_class = BasicTemplateForm
    """Define the form class for this type."""
