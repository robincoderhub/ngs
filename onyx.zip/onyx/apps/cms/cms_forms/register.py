"""Global register for CMS field types and form handlers."""

from copy import deepcopy


CMS_FORM_HANDLERS = {}
"""A dict of form handlers keyed by alias -> handler class"""


CMS_FIELD_TYPES = {}
"""A dict of field type classes keyed by alias -> field type class"""


def register_field_type(key, type_class):
    """Register a field type class with the global register

    Args:
        key: The internal name to register the field type as
        type_class: The field type class to register."""
    global CMS_FIELD_TYPES
    CMS_FIELD_TYPES[key] = type_class


def get_field_type(key):
    """Get field type class by internal name/key

    Returns:
        Either the field type class or None if none found."""
    global CMS_FIELD_TYPES
    return CMS_FIELD_TYPES.get(key)


def get_field_types():
    """Get copy of field types register dict.

    Returns:
        A dict keyed by field type name -> field type class"""
    global CMS_FIELD_TYPES
    return deepcopy(CMS_FIELD_TYPES)


def register_form_handler(key, handler_class):
    """Register a form handler with the global register.

    Args:
        key: The internal name to register the handler under
        handler_class: the class to register."""
    global CMS_FORM_HANDLERS
    CMS_FORM_HANDLERS[key] = handler_class


def get_form_handler(key):
    """Get form handler by key/internal name

    Returns:
        Either the form handler or None if not found."""
    global CMS_FORM_HANDLERS
    return CMS_FORM_HANDLERS.get(key)


def get_form_handlers():
    """Get a copy of the form handlers dict

    Returns:
        A dict keyed by form handler name -> handler class."""
    global CMS_FORM_HANDLERS
    return deepcopy(CMS_FORM_HANDLERS)
