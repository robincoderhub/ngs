"""Classes for defining form field types and their handlers."""

import os

from pycountry import countries

from captcha.fields import ReCaptchaField
from captcha import widgets as captcha_widgets

from phonenumbers import region_code_for_country_code

from phonenumber_field.formfields import PhoneNumberField
from phonenumber_field.widgets import (
    PhoneNumberPrefixWidget,
    PhoneNumberInternationalFallbackWidget
)

from django import forms
from django.core.exceptions import ValidationError

import onyx.app_settings as common_settings
from onyx.apps.cms.cms_forms.register import register_field_type
from onyx.apps.cms.cms_forms import forms as app_forms


class CMSFieldType(object):
    """A base class for defining a CMS forms field type, essentially this
    represents an input element of some kind that can be used to build
    a CMS form."""

    label = 'Untitled Field Type'
    """The human readable name of the form field type."""

    type_form_class = None
    """The form class to get configuration for this field type"""

    field_class = None
    """The form field class to be used."""

    widget_class = None
    """The form field widget  to be passed to the form field class"""

    @classmethod
    def get_label(cls):
        """Get the human readable name of this form field type.

        Returns:
            The string label."""
        return cls.label

    @classmethod
    def get_type_form_class(cls):
        """Get the type form for this field class to be used
        to get the options for displaying this form field.

        Returns:
            A form class"""
        return cls.type_form_class

    @classmethod
    def get_field_kwargs(cls, type_form_data, **kwargs):
        """Get the form field keyword arguments for creating a field
        instance.

        Args:
            type_form_data: The data from this fields type form.
            **kwargs: The current context data

        Returns:
            The updated form context."""
        return kwargs

    @classmethod
    def get_field_class(cls, type_form_data):
        """Get the field class for this field type

        Args:
            type_form_data: The data from this field's type form

        Raises:
            NotImplementedError: Thrown if no form_field_class attribute
                is specified or get_field_class hasn't be overidden.

        Returns:
            The field class for this type"""
        if not cls.field_class:
            raise NotImplementedError(
                'Either the field_class attribute should be defined or' +
                'the get_field_class method should be overidden.'
            )
        return cls.field_class

    @classmethod
    def get_field_instance(cls, type_form_data, **kwargs):
        """Get an instance of this field

        Args:
            type_form_data: The data from this field's type form
            **kwargs: Keyword arguments to be passed to the field

        Raises:
            NotImplementedError: Thrown if no form_field_class attribute
                is specified or get_field_class hasn't be overidden.

        Returns:
            An instance of this field types field class."""
        field_class = cls.get_field_class(type_form_data)
        if 'widget' not in kwargs:
            kwargs['widget'] = cls.get_field_widget(type_form_data)
        return field_class(
            **cls.get_field_kwargs(type_form_data, **kwargs)
        )

    @classmethod
    def get_field_widget(cls, type_form_data):
        """Get an instance of the widget to be used for this field.

        Args:
            type_form_data: The data from this field's type from.

        Returns:
            A form widget instance."""
        if cls.widget_class:
            return cls.widget_class()
        return None


class GenericFieldTypeMixin(object):
    """A mixin for a generic field type (text input)"""

    type_form_class = app_forms.GenericFieldTypeForm
    """The form class to get configuration for this field type"""

    @classmethod
    def get_field_instance(cls, type_form_data, **kwargs):
        """Extends method, set the placeholder attribute on whatever
        widget the field has.

        Args:
            type_form_data: The type data for this form field type
            **kwargs: The kwargs to pass to the field

        Returns:
            An instance of the field class"""
        field = super().get_field_instance(type_form_data, **kwargs)
        field.widget.attrs['placeholder'] = type_form_data['placeholder']
        return field


class TextFieldType(GenericFieldTypeMixin, CMSFieldType):
    """A field type for a CharField"""

    label = 'Text Field'
    """The human readable label for this field type."""

    field_class = forms.CharField
    """The Django field class for this type."""

    type_form_class = app_forms.TextFieldTypeForm
    """The form class to get configuration for this field type"""

    @classmethod
    def get_field_kwargs(cls, type_form_data, **kwargs):
        """Extends method to add min/max length settings

        Args:
            type_form_data: The field type data
            **kwargs: The keyword arguments for the field.

        Returns:
            The updated keyword arguments."""
        kwargs = super().get_field_kwargs(type_form_data, **kwargs)
        if type_form_data['min_length']:
            kwargs['min_length'] = type_form_data['min_length']
        if type_form_data['max_length']:
            kwargs['max_length'] = type_form_data['max_length']
        return kwargs


class TextAreaFieldType(TextFieldType):
    """A field type for a CharField with a Textarea widget"""

    label = 'Text Area Field'
    """The human readable label for this field type."""

    widget_class = forms.Textarea
    """The widget class to be passed to this field type."""


class EmailFieldType(GenericFieldTypeMixin, CMSFieldType):
    """A field type for a EmailField"""

    label = 'Email Field'
    """The human readable label for this field type."""

    field_class = forms.EmailField
    """The Django field class for this type."""


class DateFieldType(GenericFieldTypeMixin, CMSFieldType):
    """A field type for a DateField"""

    label = 'Date Field'
    """The human readable label for this field type."""

    field_class = forms.DateField
    """The Django field class for this type."""


class DateTimeFieldType(GenericFieldTypeMixin, CMSFieldType):
    """A field type for a DateTimeField"""

    label = 'DateTime Field'
    """The human readable label for this field type."""

    field_class = forms.DateTimeField
    """The Django field class for this type."""


class TimeFieldType(GenericFieldTypeMixin, CMSFieldType):
    """A field type for a TimeField"""

    label = 'Time Field'
    """The human readable label for this field type."""

    field_class = forms.TimeField
    """The Django field class for this type."""


class URLFieldType(GenericFieldTypeMixin, CMSFieldType):
    """A field type for a URLField"""

    label = 'URL Field'
    """The human readable label for this field type."""

    field_class = forms.URLField
    """The Django field class for this type."""


class IntegerFieldType(GenericFieldTypeMixin, CMSFieldType):
    """A field type for an IntegerField"""

    label = 'Number Field'
    """The human readable label for this field type."""

    field_class = forms.IntegerField
    """The Django field class for this type."""

    type_form_class = app_forms.IntegerFieldTypeForm
    """The form class to get configuration for this field type"""

    @classmethod
    def get_field_kwargs(cls, type_form_data, **kwargs):
        """Extends method to add min/max values to keyword arguments

        Args:
            type_form_data: The type data for this field
            **kwargs: The keyword arguments for the field.

        Returns:
            The updated keyword arguments."""
        kwargs = super().get_field_kwargs(type_form_data, **kwargs)
        if type_form_data['min_value'] is not None:
            kwargs['min_value'] = type_form_data['min_value']
        if type_form_data['max_value'] is not None:
            kwargs['max_value'] = type_form_data['max_value']
        return kwargs


class DecimalFieldType(GenericFieldTypeMixin, CMSFieldType):
    """A field type for a DecimalField"""

    label = 'Decimal number field'
    """The human readable label for this field type."""

    field_class = forms.DecimalField
    """The Django field class for this type."""

    type_form_class = app_forms.DecimalFieldTypeForm
    """The form class to get configuration for this field type"""

    @classmethod
    def get_field_kwargs(cls, type_form_data, **kwargs):
        """Extends method to add min/max values and max decimal places
        to keyword arguments

        Args:
            type_form_data: The type data for this field
            **kwargs: The keyword arguments for the field.

        Returns:
            The updated keyword arguments."""
        kwargs = super().get_field_kwargs(type_form_data, **kwargs)
        if type_form_data['min_value'] is not None:
            kwargs['min_value'] = type_form_data['min_value']
        if type_form_data['max_value'] is not None:
            kwargs['max_value'] = type_form_data['max_value']
        if type_form_data['max_decimal_places'] is not None:
            kwargs['decimal_places'] = type_form_data['max_decimal_places']
        return kwargs


class PhoneNumberFieldType(GenericFieldTypeMixin, CMSFieldType):
    label = 'Phone number field'
    """The human readable label for this field type."""

    field_class = PhoneNumberField
    """The Django field class for this type."""

    type_form_class = app_forms.PhoneNumberFieldTypeForm
    """The form class to get configuration for this field type"""

    @classmethod
    def get_field_instance(cls, type_form_data, **kwargs):
        """Get the field instance for this field, adds region validation
        if specified by the type_form_data.

        Args:
            type_form_data: The type form data for this field.
            **kwargs: The keywords being passed to this field.

        Returns:
            A field instance."""
        field_class = cls.field_class
        field_kwargs = cls.get_field_kwargs(type_form_data, **kwargs)
        if type_form_data['region']:
            field_kwargs['region'] = type_form_data['region']

            def region_validator(value):
                from phonenumber_field.phonenumber import to_python
                number = to_python(value)
                if number and number.is_valid():
                    number_region = region_code_for_country_code(
                        number.country_code
                    )
                    country = countries.get(alpha_2=type_form_data['region'])
                    if number_region != type_form_data['region']:
                        raise ValidationError(
                            f'Must be a valid local number ({country.name}).'
                        )

            class GeneratedFieldClass(field_class):
                def __init__(self, *args, **kwargs):
                    super().__init__(*args, **kwargs)
                    self.validators.append(region_validator)
            field_class = GeneratedFieldClass
        return field_class(
            **field_kwargs,
            widget=cls.get_field_widget(type_form_data)
        )

    @classmethod
    def get_field_widget(cls, type_form_data):
        """Get the field widget type for this field, changes widget
        depending on whether separate inputs are required.

        Args:
            type_form_data: The type form data for this field.

        Returns:
            A PhoneNumberPrefixWidget or PhoneNumberInternationalFallbackWidget"""
        widget_class = (
            PhoneNumberPrefixWidget
            if type_form_data.get('separate_inputs')
            else PhoneNumberInternationalFallbackWidget
        )
        return widget_class()


class IPAddressFieldType(GenericFieldTypeMixin, CMSFieldType):
    label = 'IP address field'
    """The human readable label for this field type."""

    field_class = forms.GenericIPAddressField
    """The Django field class for this type."""


class ChoiceFieldType(CMSFieldType):
    label = 'Choice field'
    """The human readable label for this field type."""

    field_class = forms.ChoiceField
    """The Django field class for this type."""

    type_form_class = app_forms.ChoiceFieldTypeForm
    """The form class to get configuration for this field type"""

    @classmethod
    def get_field_kwargs(cls, type_form_data, **kwargs):
        """Extends method to add choices to field and placeholder
        if a select field.

        Args:
            type_form_data: The type data for this field
            **kwargs: The keyword arguments for the field.

        Returns:
            The updated keyword arguments."""
        kwargs = super().get_field_kwargs(type_form_data, **kwargs)
        choices = [
            (value.strip(), value.strip())
            for value in type_form_data['choices'].split("\n")
        ]
        if not type_form_data['radio_buttons']:
            placeholder = type_form_data['placeholder']
            if not placeholder:
                placeholder = '----'
            choices.insert(0, (None, placeholder))
        kwargs['choices'] = choices
        return kwargs

    @classmethod
    def get_field_widget(cls, type_form_data):
        """Get the field widget type for this field, changes widget
        depending on whether it should be a radio button choice field.

        Args:
            type_form_data: The type form data for this field.

        Returns:
            The widget instance"""
        if type_form_data['radio_buttons']:
            return forms.RadioSelect()
        return super().get_field_widget(type_form_data)


class MultipleChoiceFieldType(CMSFieldType):
    label = 'Multiple choice field'
    """The human readable label for this field type."""

    field_class = forms.MultipleChoiceField
    """The Django field class for this type."""

    type_form_class = app_forms.MultipleChoiceFieldTypeForm
    """The form class to get configuration for this field type"""

    @classmethod
    def get_field_kwargs(cls, type_form_data, **kwargs):
        """Extends method to add choices to keyword arguments

        Args:
            type_form_data: The type data for this field
            **kwargs: The keyword arguments for the field.

        Returns:
            The updated keyword arguments."""
        kwargs = super().get_field_kwargs(type_form_data, **kwargs)
        kwargs['choices'] = [
            (value.strip(), value.strip())
            for value in type_form_data['choices'].split("\n")
            if value.strip()
        ]
        return kwargs

    @classmethod
    def get_field_widget(cls, type_form_data):
        """Get the field widget type for this field, changes widget
        depending on whether it should be a checkboxes widget or not.

        Args:
            type_form_data: The type form data for this field.

        Returns:
            The widget instance"""
        if type_form_data['checkboxes']:
            return forms.CheckboxSelectMultiple()
        return super().get_field_widget(type_form_data)


class BooleanFieldType(CMSFieldType):
    label = 'Yes/No field'
    """The human readable label for this field type."""

    field_class = forms.BooleanField
    """The Django field class for this type."""


class FileFieldType(CMSFieldType):
    label = 'File field'
    """The human readable label for this field type."""

    field_class = forms.FileField
    """The Django field class for this type."""

    type_form_class = app_forms.FileFieldTypeForm
    """The form class to get configuration for this field type"""

    @classmethod
    def get_field_kwargs(cls, type_form_data, **kwargs):
        """Extends method to add acceptable file extension validation to field

        Args:
            type_form_data: The type data for this field
            **kwargs: The keyword arguments for the field.

        Returns:
            The updated keyword arguments."""
        kwargs = super().get_field_kwargs(type_form_data, **kwargs)
        if type_form_data['accepted_file_extensions']:
            specified_extensions = []
            for extension in type_form_data['accepted_file_extensions'].split(
                "\n"
            ):
                if not extension.strip():
                    continue
                if extension[0] != '.':
                    extension = f".{extension}"
                specified_extensions.append(extension.lower())
            if len(specified_extensions) > 0:
                joined_extensions = ', '.join(specified_extensions)

                def validate_extensions(value):
                    extension = os.path.splitext(value.name)[1].lower()
                    if extension not in specified_extensions:
                        raise ValidationError(
                            f'Only accepts ({joined_extensions}) files'
                        )
                kwargs['validators'] = [validate_extensions]
                if 'help_text' not in kwargs or not kwargs['help_text']:
                    kwargs['help_text'] = (
                        f'Accepts ({joined_extensions}) files'
                    )
        return kwargs


class RecaptchaFieldType(CMSFieldType):
    label = 'Recaptcha Field'
    """The human readable label for this field type."""

    field_class = ReCaptchaField
    """The Django field class for this type."""

    type_form_class = app_forms.RecaptchaFieldTypeForm
    """The form class to get configuration for this field type"""

    @classmethod
    def get_field_kwargs(cls, type_form_data, **kwargs):
        """Extends method to add recaptcha public/private keys to keyword arguments

        Args:
            type_form_data: The type data for this field
            **kwargs: The keyword arguments for the field.

        Returns:
            The updated keyword arguments."""
        super().get_field_kwargs(type_form_data, **kwargs)
        public_key = type_form_data.get('recaptcha_public_key')
        private_key = type_form_data.get('recaptcha_private_key')
        if public_key or private_key:
            kwargs['public_key'] = public_key
            kwargs['private_key'] = private_key
        return kwargs

    @classmethod
    def get_field_widget(cls, type_form_data):
        """Get the field widget type for this field, changes widget
        depending on what version of recaptcha is defined in the type
        data.

        Args:
            type_form_data: The type form data for this field.

        Returns:
            The widget instance"""
        recaptcha_version = common_settings.RECAPTCHA_VERSION
        if recaptcha_version == 'v2':
            return captcha_widgets.ReCaptchaV2Checkbox()
        elif recaptcha_version == 'v2_invisible':
            return captcha_widgets.ReCaptchaV2Invisible()
        return captcha_widgets.ReCaptchaV3()


DEFAULT_FIELD_TYPES = {
    'text_field': TextFieldType,
    'text_area_field': TextAreaFieldType,
    'email_field': EmailFieldType,
    'date_field': DateFieldType,
    'date_time_field': DateTimeFieldType,
    'time_field': TimeFieldType,
    'url_field': URLFieldType,
    'number_field': IntegerFieldType,
    'decimal_field': DecimalFieldType,
    'phone_number_field': PhoneNumberFieldType,
    'ip_address_field': IPAddressFieldType,
    'choice_field': ChoiceFieldType,
    'multiple_choice_field': MultipleChoiceFieldType,
    'yesno_field': BooleanFieldType,
    'file_field': FileFieldType,
    'recaptcha_field': RecaptchaFieldType
}
"""A dict of the default field types to register."""


def register_default_field_types(excluding=None):
    """Method to register default field types

    Args:
        excluding: Optional, can pass a list of field type names
            to exclude from registering."""
    excluding = excluding or []
    for field_name, field_type_class in DEFAULT_FIELD_TYPES.items():
        if field_name in excluding:
            continue
        register_field_type(field_name, field_type_class)
