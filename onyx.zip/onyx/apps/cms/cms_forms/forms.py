from phonenumbers import SUPPORTED_REGIONS
from pycountry import countries

from django import forms

from onyx.forms.fields import FlexibleURLField


PHONE_NUMBER_REGION_CHOICES = [
    (
        region_code,
        countries.get(alpha_2=region_code).name
    )
    for region_code in SUPPORTED_REGIONS
    if countries.get(alpha_2=region_code)
]
"""Choices for acceptable regions in phone numbers."""
PHONE_NUMBER_REGION_CHOICES.sort(key=lambda x: x[1])
PHONE_NUMBER_REGION_CHOICES.insert(0, (None, 'Any Region'))


class MinMaxValueMixin(object):
    """A mixin for cleaning min/max values."""

    def clean(self):
        """Extends method to check for dodgy min/max values.

        Returns:
            A dict of cleaned data"""
        min_value = self.cleaned_data.get('min_value')
        max_value = self.cleaned_data.get('max_value')
        if min_value is not None and max_value is not None:
            if min_value > max_value:
                self.add_error(
                    'min_value',
                    "Minimum value cannot be larger than max value."
                )
        return self.cleaned_data


class GenericFieldTypeForm(forms.Form):
    """A generic field form for 'input'/text type inputs"""

    placeholder = forms.CharField(required=False)
    """Placholder text for the field."""


class TextFieldTypeForm(GenericFieldTypeForm):
    """A type form for a text field"""

    min_length = forms.IntegerField(min_value=0, required=False)
    """Variable for configuring minimum length of input."""

    max_length = forms.IntegerField(min_value=1, required=False)
    """Variable for configuring maximum length of input."""

    def clean(self):
        """Extends method to validate min/max length of field.

        Returns:
            A dict of cleaned data"""
        min_length = self.cleaned_data.get('min_length')
        max_length = self.cleaned_data.get('max_length')
        if min_length is not None and max_length is not None:
            if min_length > max_length:
                self.add_error(
                    'min_length',
                    'Minimum length cannot be larger than max length.'
                )
        return self.cleaned_data


class IntegerFieldTypeForm(MinMaxValueMixin, GenericFieldTypeForm):
    """A type form for an integer field."""

    min_value = forms.IntegerField(required=False)
    """Minimum value of field."""

    max_value = forms.IntegerField(required=False)
    """Maximum value of field"""


class DecimalFieldTypeForm(MinMaxValueMixin, GenericFieldTypeForm):
    """Decimal field type form"""

    min_value = forms.DecimalField(required=False)
    """Minimum value of field."""

    max_value = forms.DecimalField(required=False)
    """Maximum value of field."""

    max_decimal_places = forms.IntegerField(
        min_value=0,
        required=False
    )
    """Maximum number of decimal places for input."""


class PhoneNumberFieldTypeForm(GenericFieldTypeForm):
    """A type form for a phone number field."""

    region = forms.ChoiceField(
        choices=PHONE_NUMBER_REGION_CHOICES,
        help_text=(
            'If set, rejects phone numbers starting'
            + ' with non-selected countries prefix.'
        ),
        required=False
    )
    """An optional region field to select what regions are acceptable."""

    separate_inputs = forms.BooleanField(
        required=False,
        help_text=(
            'If selected will display a drop down for the country code'
            + ' and the phone number.'
        )
    )
    """Whether or not to display as two inputs (region and number) or a combined
    single free-form input."""

    def clean(self):
        """Clean method, tests validity of configuration options

        Returns:
            A dict of cleaned data."""
        region = self.cleaned_data.get('region')
        separate_inputs = self.cleaned_data.get('separate_inputs')
        if separate_inputs and region:
            self.add_error(
                'separate_inputs',
                'Cannot select region AND show international call codes.'
            )
        return self.cleaned_data


class ChoiceFieldTypeForm(forms.Form):
    """A single choice field type form."""

    placeholder = forms.CharField(
        initial='Select an option',
        help_text='Used by select drop down as starting option',
        required=False
    )
    """Placeholder text for select field"""

    choices = forms.CharField(
        widget=forms.Textarea(),
        help_text='One choice per line'
    )
    """Choices seperated by line breaks."""

    radio_buttons = forms.BooleanField(required=False)
    """If True displays choice field as radio buttons instead
    of a select."""


class MultipleChoiceFieldTypeForm(forms.Form):
    """A multiple choice field type form."""

    choices = forms.CharField(
        widget=forms.Textarea(),
        help_text='One choice per line'
    )
    """Choices to display seperated by line breaks."""

    checkboxes = forms.BooleanField(required=False)
    """If True displays multiple choice as checkboxes."""


class FileFieldTypeForm(forms.Form):
    """Form for a file field form."""

    accepted_file_extensions = forms.CharField(
        widget=forms.Textarea(),
        help_text='One file extension per line e.g. .jpg',
        required=False
    )
    """Accepted file extensions seperated by line breaks."""


class RecaptchaFieldTypeForm(forms.Form):
    """A type form for a recaptch form field."""
    recaptcha_public_key = forms.CharField(
        max_length=255,
        required=False,
        help_text='Optional, specific a different public key than the default'
    )
    """The recaptcha public key, by default uses RECAPTCHA_PUBLIC_KEY setting."""

    recaptcha_private_key = forms.CharField(
        max_length=255,
        required=False,
        help_text='Optional, specific a different private key than the default'
    )
    """The recaptcha private key, by default uses RECAPTCHA_PRIVATE_KEY setting."""

    def clean(self):
        """Clean method, ensures both keys are specified if one has been.

        Returns:
            A dict of cleaned data."""
        cleaned_data = self.cleaned_data
        public_key = cleaned_data.get('recaptcha_public_key')
        private_key = cleaned_data.get('recaptcha_private_key')
        if public_key or private_key:
            if not public_key:
                self.add_error(
                    'recaptcha_public_key',
                    'If private key is specified, must provide public key.'
                )
            if not private_key:
                self.add_error(
                    'recaptcha_private_key',
                    'If public key is specified, must provide private key.'
                )
        return cleaned_data


class ContactHandlerForm(forms.Form):
    """Contact form handler form, sends emails to adminsitrators and submitters
    with details of the data submitted."""

    send_to_email = forms.EmailField(
        help_text='The email address the contact form will send to.'
    )
    """Email address to send the contact message to."""

    subject = forms.CharField(initial='New Message Received')
    """The subject line of the contact message email."""

    redirect_url = FlexibleURLField(
        help_text=(
            'The url to redirect on submission, leave blank for no redirect.'
        ),
        required=False
    )
    """A url to redirect the submitter to after submission."""

    send_receipt = forms.ChoiceField(
        initial=False,
        choices=(
            (True, 'Yes'),
            (False, 'No'),
        )
    )
    """Whether or not to send a receipt email to the submitter."""

    receipt_field_name = forms.CharField(
        help_text='The name of the form field to send a receipt email to.',
        required=False
    )
    """The field of the form to use to send the receipt email to i.e. an
    email field."""

    receipt_subject = forms.CharField(required=False)
    """The subject line of the receipt email."""

    receipt_message = forms.CharField(widget=forms.Textarea(), required=False)
    """The receipt message for the receipt email i.e. "Thanks for contacting us"."""

    def clean_send_receipt(self):
        """Cleans send receipt value, booleans returned as strings.

        Returns:
            A boolean True/False value."""
        return (self.cleaned_data['send_receipt'] == 'True')

    def clean(self):
        """Clean method, ensures the correct field have been filled out
        depending on options specified.

        Returns:
            A dict of cleaned data."""
        data = self.cleaned_data
        if data['send_receipt']:
            if not data['receipt_field_name']:
                self.add_error(
                    'receipt_field_name',
                    'Must supply a field name to send receipt to'
                )
            if not data['receipt_subject']:
                self.add_error(
                    'receipt_subject',
                    'Must supply a subject line for receipt email'
                )
            if not data['receipt_message']:
                self.add_error(
                    'receipt_message',
                    'Must supply a receipt message.'
                )
        return data
