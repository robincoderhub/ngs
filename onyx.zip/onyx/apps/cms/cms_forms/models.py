"""Models for the CMS forms app"""

import os

from django import forms
from django.db import models
from django.core.exceptions import ValidationError
from django.contrib.postgres.fields import JSONField

from onyx.models import fields
from onyx.apps.cms.cms_forms.register import get_field_type, get_form_handler
from onyx.apps.cms.cms_forms.app_settings import (
    CMS_FORM_ARG,
    CMS_FORM_MEDIA_ROOT
)


class CMSForm(models.Model):
    """A model representing a CMS managed form"""

    label = models.CharField(max_length=255)
    """The human readable name of the form."""

    name = fields.InternalNameField(unique=True)
    """The internal name of the form, this is how the form can be
    globally referenced."""

    form_handler = fields.InternalNameField()
    """The internal name of the form handler for this form."""

    handler_data = JSONField(default=dict)
    """Configuration data for this form."""

    save_responses = models.BooleanField(default=True)
    """Whether or not to save responses for this form to the
    database."""

    def __str__(self):
        """Get string representation of this model.

        Returns:
            The human readable name of this form."""
        return self.label

    def clean(self):
        """Extends clean method, ensures handle_data validates against
        the specified handler class.

        Raises:
            ValidationError: Thrown if a validation error occurrs

        Returns:
            A dict of cleaned data."""
        handler_class = get_form_handler(self.form_handler)
        if not handler_class:
            raise ValidationError(
                f'An invalid form handler was specified, "{self.form_handler}"'
                + ' does not appear to be registered.'
            )
        if self.handler_data:
            if self.id:
                # This prevents situations were existing model data is
                # invalid but the data being inserted is valid.
                if (
                    CMSForm.objects.get(id=self.id).handler_data
                    == self.handler_data
                ):
                    return
            handler_form = handler_class.get_handler_form_class()(
                data=self.handler_data
            )
            if not handler_form.is_valid():
                raise ValidationError('CMS form handler data is invalid.')

    def to_form_class(self):
        """Convert this model and it's sub field into a Django form class

        Returns:
            A django form class."""
        form_name = self.name
        fields = self.fields.all().order_by('order')

        class GeneratedForm(forms.Form):
            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)
                field_orders = []
                for field in fields:
                    field_type = get_field_type(field.field_type)
                    if not field_type:
                        raise ValueError(
                            f'CMS field "{field.name}" has an undefined'
                            + f' type "{field.field_type}".'
                        )
                    if field_type.get_type_form_class():
                        type_form = field_type.get_type_form_class()(
                            data=field.type_data
                        )
                        # Validate to ensure cleaned_data is populated
                        if not type_form.is_valid():
                            raise ValueError(
                                f'CMS field "{field.name}" type form'
                                + ' is not valid.'
                            )
                        type_form_data = type_form.cleaned_data
                    else:
                        type_form_data = None
                    self.fields[field.name] = field_type.get_field_instance(
                        type_form_data,
                        label=field.label,
                        required=field.required,
                        help_text=field.help_text
                    )
                    field_orders.append(field.name)
                self.fields[CMS_FORM_ARG] = forms.CharField(
                    initial=form_name,
                    widget=forms.HiddenInput
                )
        return GeneratedForm


class CMSFormField(models.Model):
    """Model representing a configured form field."""

    class Meta:
        """Meta class, ensures form and name are unique together"""
        unique_together = ('form', 'name')

    form = models.ForeignKey(
        CMSForm,
        on_delete=models.CASCADE,
        related_name='fields'
    )
    """The form this field belongs to."""

    label = models.CharField(max_length=255)
    """The human readable field label for this field."""

    name = fields.InternalNameField()
    """An internal name for this field, the 'name' attribute."""

    field_type = fields.InternalNameField()
    """The internal name of the field type of this field."""

    order = models.IntegerField(default=0)
    """The numeric order of this field in the form."""

    help_text = models.CharField(
        max_length=255,
        null=True,
        blank=True
    )
    """Help text for this form field."""

    required = models.BooleanField(default=True)
    """Whether or not this is a required form field."""

    display_in_table = models.BooleanField(default=False)
    """Whether or not to display as a column in the response table."""

    show_in_response = models.BooleanField(default=True)
    """Whether or not to show this fields value in response data."""

    type_data = JSONField(default=dict)
    """Type configuration data for this field."""

    def __str__(self):
        """Get a string representation of this model.

        Returns:
            The field label for this field."""
        return self.label

    def unique_error_message(self, *args, **kwargs):
        """Override for 'unique' error message, to display
        a more human friendly error message for unique_together
        error message.

        Args:
            *args: Inherited arguments
            **kwargs: Inherited keyword arguments.

        Returns:
            A string error message."""
        error = super().unique_error_message(*args, **kwargs)
        if isinstance(error, ValidationError):
            if getattr(error, 'code') == 'unique_together':
                error.message = (
                    'This form already has a form field with'
                    + f' the name "{self.name}"'
                )
        return error

    def clean(self):
        """Clean method, ensures form field type data
        validates.

        Raises:
            ValidationError: Thrown if a validation error occurs

        Returns:
            A dict of cleaned data"""
        type_class = get_field_type(self.field_type)
        if not type_class:
            raise ValidationError(
                'An invalid field type was specified,'
                + f' "{self.form_handler}" does not appear to be registered.'
            )
        type_form_class = type_class.get_type_form_class()
        if type_form_class and self.type_data:
            # This prevents situations were existing model data is invalid
            # but the data being inserted is valid.
            if (
                CMSFormField.objects.get(
                    id=self.id
                ).type_data == self.type_data
            ):
                return
            type_form = type_form_class(
                data=self.type_data
            )
            if not type_form.is_valid():
                raise ValidationError(
                    'CMS form field type data is invalid.'
                )
        return self.cleaned_data


class CMSFormResponse(models.Model):
    """A model to store form responses from CMS forms."""

    form = models.ForeignKey(
        CMSForm,
        on_delete=models.CASCADE,
        related_name='responses'
    )
    """The form this response belongs to."""

    response_data = JSONField()
    """The form data submitted to the form."""

    created = models.DateTimeField(auto_now_add=True)
    """Created timestamp for this response."""

    @property
    def file_dict(self):
        """Property for returning a dict of files uploaded
        with this response.

        Returns:
            A dict of file data keyed by field name."""
        file_dict = {}
        for file_model in self.files.all():
            file_dict[file_model.field.name] = file_model
        return file_dict


def cms_file_upload_to(x, y):
    """A function for getting the upload path of
    a file. Django cannot serialize lambdas in migrations
    so it must have it's own function.

    Args:
        x: The response file instance.
        y: The filename of the file

    Returns:
        A path to the upload file"""
    return os.path.join(
        CMS_FORM_MEDIA_ROOT,
        x.response.form.name,
        f"response-{x.response.id}",
        y
    )


class CMSFormResponseFile(models.Model):
    """A model representing an uploaded file from a CMS form."""

    response = models.ForeignKey(
        CMSFormResponse,
        on_delete=models.CASCADE,
        related_name='files'
    )
    """The response this file belongs to."""

    field = models.ForeignKey(
        CMSFormField,
        on_delete=models.CASCADE,
        related_name='files'
    )
    """The field this file was uploaded to."""

    uploaded_file = models.FileField(
        upload_to=cms_file_upload_to
    )
    """The file field for the file itself."""
