"""Middleware for CMS forms app"""

from django import forms
from django.db import transaction
from django.shortcuts import redirect
from django.utils.deprecation import MiddlewareMixin

from onyx.utils import to_json_safe_object
from onyx.apps.cms.cms_forms.app_settings import CMS_FORM_ARG
from onyx.apps.cms.cms_forms.models import (
    CMSForm,
    CMSFormField,
    CMSFormResponse,
    CMSFormResponseFile
)
from onyx.apps.cms.cms_forms.register import get_form_handler


class CMSFormsMiddleware(MiddlewareMixin):
    """Form middleware for handing submission of CMS forms."""

    def process_request(self, request):
        """Process request, handle CMS form.

        This middleware:
        - fetches the form if one was submitted
        - attempt to validate the form
        -- if validates
        --- fetch handler
        --- save a response model if it's specified that it should
        --- pass the form to the handler to handle
        --- return the django response the handler returns OR sends back to same
            page or redirect url.
        -- if fails validation
        --- display page as normal but with errors

        Args:
            request: The incoming django request

        Returns:
            A django response."""
        if request.method != 'POST':
            return
        form_name = None
        form_prefix = None
        for var_name, var_value in request.POST.items():
            if var_name.endswith(CMS_FORM_ARG):
                form_name = var_value
                form_prefix = var_name.replace(CMS_FORM_ARG, '')
                if form_prefix.endswith('-'):
                    form_prefix = form_prefix[:-1]
                if not form_prefix:
                    form_prefix = None
        if not form_name:
            return
        try:
            cms_form = CMSForm.objects.get(
                name=form_name
            )
        except CMSForm.DoesNotExit:
            return
        form = cms_form.to_form_class()(
            data=request.POST,
            files=request.FILES,
            prefix=form_prefix
        )
        if form.is_valid():
            form_handler = get_form_handler(cms_form.form_handler)
            if not form_handler:
                raise ValueError(
                    f'CMS form handler "{cms_form.form_handler}"'
                    + ' is not registered.'
                )
            handler_form = form_handler.get_handler_form_class()(
                data=cms_form.handler_data
            )
            if not handler_form.is_valid():
                raise ValueError(
                    'Form handler data does not validate'
                    + f' for form "{cms_form.name}".'
                )
            with transaction.atomic():
                response = None
                if cms_form.save_responses:
                    form_data = form.cleaned_data
                    response = CMSFormResponse()
                    response.form = cms_form
                    response.response_data = to_json_safe_object(form_data)
                    response.save()
                    for field_name, field in form.fields.items():
                        prefix = f'{form.prefix}-' if form.prefix else ''
                        prefixed_field_name = f'{prefix}{field_name}'
                        if (
                            isinstance(field, forms.FileField)
                            and prefixed_field_name in request.FILES
                        ):
                            file_model = CMSFormResponseFile(
                                response=response,
                                field=CMSFormField.objects.get(
                                    form=cms_form,
                                    name=field_name
                                ),
                                uploaded_file=request.FILES[
                                    prefixed_field_name
                                ]
                            )
                            file_model.save()
                http_response = form_handler.handle(
                    request,
                    cms_form,
                    form,
                    handler_form,
                    response_model=response
                )
            if http_response:
                return http_response
            else:
                return redirect(request.build_absolute_uri())
