"""Views related to CMS forms app"""
import os

from django.views.generic import View
from django.http import FileResponse, HttpResponseForbidden
from django.shortcuts import get_object_or_404

from onyx.apps.cms.cms_forms.models import CMSFormResponseFile


class ResponseFileView(View):
    """A view for displaying an uploaded file from a form response."""

    def dispatch(self, request, file_id):
        """Main dispatch method, fetches and serves the
        specified file, checks user permissions.

        Args:
            request: The django request object
            file_id: The id of the file to display

        Returns:
            A django response object"""
        user = request.user
        has_permission = not user.is_anonymous and (
            (
                user.is_staff and (
                    user.has_perm(
                        'onyx_cms_forms.view_cmsformresponsefile'
                    )
                    or user.has_perm(
                        'onyx_cms_forms.view_cmsformresponse'
                    )
                )
            )
            or user.is_superuser
        )
        if not has_permission:
            return HttpResponseForbidden()
        file_model = get_object_or_404(CMSFormResponseFile, id=file_id)
        return FileResponse(
            open(file_model.uploaded_file.name, 'rb'),
            as_attachment=True,
            filename=os.path.basename(file_model.uploaded_file.name)
        )
