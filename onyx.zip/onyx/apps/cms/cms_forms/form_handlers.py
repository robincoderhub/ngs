from django import forms
from django.shortcuts import redirect
from django.template import Template, Context
from django.core.mail import send_mail, EmailMultiAlternatives
from django.conf import settings
from django.contrib import messages
from django.template.loader import render_to_string

from onyx.apps.cms.cms_forms.register import register_form_handler
from onyx.apps.cms.cms_forms import forms as app_forms


class CMSFormHandler(object):
    """Base class for CMS form handler classes, these handlers
    receive and process certain types of form."""

    label = 'Untitled Handler'
    """The human readable name of this form handler."""

    handler_form_class = None
    """A class that defines configuration for this handler instance."""

    @classmethod
    def get_label(cls):
        """Get the human readable name of this form handler.

        Returns:
            The string label."""
        return cls.label

    @classmethod
    def get_handler_form_class(cls):
        """The handler form class

        Returns:
            A django form class or None."""
        return cls.handler_form_class

    @classmethod
    def handle(
        cls, request, form_model, form,
        handler_form, response_model=None
    ):
        """Handle a form submission.

        Args:
            request: The incoming django form request
            form_model: The database form model that this handler is handling
            form: The form being submitted.
            handler_form: The configuration form for this handler.
            response_model: Either the response model or None if no response
                model exists for this form.

        Raises:
            NotImplementedError: Raised if this method is not overidden.

        Returns:
            A django response or None if not changing the default response."""
        raise NotImplementedError('handle method must be overridden')


class ContactHandler(CMSFormHandler):
    label = 'Contact Form'
    handler_form_class = app_forms.ContactHandlerForm

    @classmethod
    def handle(
        cls, request, form_model,
        form, handler_form, response_model=None
    ):
        """Handle the form, sends contact emails to the administrator
        and a receipt to the sender if configured.

        Args:
            request: The incoming django form request
            form_model: The database form model that this handler is handling
            form: The form being submitted.
            handler_form: The configuration form for this handler.
            response_model: Either the response model or None if no response
                model exists for this form.

        Returns:
            A django response object or None if none is required."""
        handler_data = handler_form.cleaned_data
        cls.send_contact_email(
            request,
            form_model,
            form,
            handler_form,
            response_model
        )
        if handler_data['send_receipt'] and handler_data['receipt_field_name']:
            cls.send_receipt_email(
                request,
                form_model,
                form,
                handler_form,
                response_model
            )
        messages.success(request, 'Message sent!')
        if handler_data['redirect_url']:
            return redirect(handler_data['redirect_url'])

    @classmethod
    def send_contact_email(
        cls, request, form_model,
        form, handler_form, response_model=None
    ):
        """Send a contact email to the configured administrator containing
        the contact details submitted in the form.

        Args:
            request: The incoming django form request
            form_model: The database form model that this handler is handling
            form: The form being submitted.
            handler_form: The configuration form for this handler.
            response_model: Either the response model or None if no response
                model exists for this form."""
        handler_data = handler_form.cleaned_data
        form_data = form.cleaned_data
        send_to_email = handler_data['send_to_email']
        subject = handler_data['subject']
        if handler_data['receipt_field_name']:
            subject += f" ({handler_data['receipt_field_name']})"

        # Build message
        email_context = {
            'form_model': form_model,
            'form_data': form_data,
            'form': form,
            'handler_form': handler_form,
            'response_model': response_model
        }
        html_msg = render_to_string(
            'onyx/apps/cms/cms_forms/email/contact_message.html',
            context=email_context,
            request=request
        )
        text_msg = render_to_string(
            'onyx/apps/cms/cms_forms/email/contact_message.txt',
            context=email_context,
            request=request
        )

        # Create email message
        email = EmailMultiAlternatives(
            subject,
            text_msg,
            settings.DEFAULT_FROM_EMAIL,
            [send_to_email]
        )
        email.attach_alternative(html_msg, 'text/html')

        # Attach files if not already stored in a response
        if not response_model:
            for field_name, field in form.fields.items():
                if isinstance(field, forms.FileField):
                    email.attach(
                        form_data[field_name].name,
                        form_data[field_name].file.read(),
                        form_data[field_name].content_type
                    )

        # Sendy send
        email.send()

    @classmethod
    def send_receipt_email(
        cls, request, form_model,
        form, handler_form, response_model=None
    ):
        """Send a receipt email to the person who submitted the contact form, if configured.

        Args:
            request: The incoming django form request
            form_model: The database form model that this handler is handling
            form: The form being submitted.
            handler_form: The configuration form for this handler.
            response_model: Either the response model or None if no response
                model exists for this form."""
        handler_data = handler_form.cleaned_data
        form_data = form.cleaned_data
        receipt_email = form_data[handler_data['receipt_field_name']]

        # Parse subject/message for django vars
        subject = handler_data.get(
            'receipt_subject',
            'Thank you for your message'
        )
        parsed_subject = Template(subject).render(Context(form_data))
        message = handler_data.get(
            'receipt_message',
            'Your message has been successfully received.'
        )
        parsed_message = Template(message).render(Context(form_data))

        # Build email body
        email_context = {
            'content': parsed_message,
            'form_model': form_model,
            'form': form,
            'handler_form': handler_form,
            'response_model': response_model
        }
        html_msg = render_to_string(
            'onyx/apps/cms/cms_forms/email/receipt.html',
            context=email_context,
            request=request
        )
        text_msg = render_to_string(
            'onyx/apps/cms/cms_forms/email/receipt.txt',
            context=email_context,
            request=request
        )

        # Send email
        send_mail(
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=[receipt_email],
            subject=parsed_subject,
            message=text_msg,
            html_message=html_msg
        )


DEFAULT_FORM_HANDLERS = {
    'contact_form': ContactHandler
}
"""A dict of the default form handlers to register on ready."""


def register_default_form_handlers(excluding=None):
    """Register default form handlers with global register."""
    excluding = excluding or []
    for handler_name, handler_class in DEFAULT_FORM_HANDLERS.items():
        if handler_name in excluding:
            continue
        register_form_handler(handler_name, handler_class)
