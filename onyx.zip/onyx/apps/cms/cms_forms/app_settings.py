"""Setting for the CMS forms app and their defaults."""

import os
from django.conf import settings

from onyx.app_settings import PRIVATE_MEDIA_ROOT


CMS_FORM_ARG = getattr(settings, 'CMS_FORM_ARG', 'vform')
"""The GET argument used for global form submissions"""


CMS_FORM_MEDIA_ROOT = getattr(
    settings,
    'CMS_FORM_MEDIA_ROOT',
    os.path.join(
        PRIVATE_MEDIA_ROOT,
        'cms_forms'
    )
)
"""The media root path for uploading private files."""
