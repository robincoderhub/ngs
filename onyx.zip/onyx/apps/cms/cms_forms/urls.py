"""Url patterns for CMS forms app"""

from django.urls import path

from onyx.apps.cms.cms_forms import views


app_name = 'cms_forms'
urlpatterns = [
    path(
        'file/<int:file_id>/',
        views.ResponseFileView.as_view(),
        name='response_file'
    ),
]
