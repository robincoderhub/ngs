"""App config classes for CMS forms app"""

from onyx.config import AbstractOnyxConfig


class CMSFormsConfig(AbstractOnyxConfig):
    """Default app config for CMS forms app."""

    name = "onyx.apps.cms.cms_forms"
    """The python path to the app"""

    verbose_name = "Onyx - CMS - Forms"
    """The human readable name of the app"""

    label = "onyx_cms_forms"
    """The internal Django name of the app"""

    def ready(self):
        """On ready register default field types and form
        handlers."""
        from onyx.apps.cms.cms_forms.form_handlers import (
            register_default_form_handlers
        )
        from onyx.apps.cms.cms_forms.field_types import (
            register_default_field_types
        )
        register_default_field_types()
        register_default_form_handlers()
