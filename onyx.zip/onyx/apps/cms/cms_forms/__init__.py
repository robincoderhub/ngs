"""App for defining and displaying forms defined in the CMS and saving
the resultant responses."""

default_app_config = 'onyx.apps.cms.cms_forms.config.CMSFormsConfig'
