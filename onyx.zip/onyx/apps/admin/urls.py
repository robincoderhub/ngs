"""Url patterns for admin app, adds the generated url patterns of installed
admin apps."""

from django.urls import path

from onyx.apps.admin import views
from onyx.apps.admin.core import get_admin_app_urls


app_name = 'admin'
urlpatterns = [
    path('', views.AdminDashboard.as_view(), name='dashboard'),
    path('constants.js', views.AdminJSConstants.as_view(), name='js_constants'),
    path('search/', views.AdminAjaxSearch.as_view(), name='search'),
] + get_admin_app_urls()
