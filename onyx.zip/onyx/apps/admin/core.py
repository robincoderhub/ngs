"""Code for fetching various admin app configuration data such as the installed
admin apps, the url patterns and menu."""

import importlib
from copy import deepcopy

from django.urls import path, include, reverse_lazy
from django.apps import apps as app_configs

from onyx.apps.cms.menus.items import MenuItemTree, MenuItem
from onyx.apps.admin.config import AdminAppConfigMixin


def get_admin_app_configs():
    """Get all apps that extend the AdminAppConfigMixin class,
    these are considered installed admin apps.

    Returns:
        A list of app config instances."""
    admin_apps = []
    for app_config in app_configs.get_app_configs():
        if isinstance(app_config, AdminAppConfigMixin):
            admin_apps.append(app_config)
    return admin_apps


def get_admin_app_urls():
    """Get the admin app url patterns, auto generates from the
    installed admin apps and their urls.py files.

    Returns:
        A list of url patterns."""
    app_configs = get_admin_app_configs()

    patterns = []
    for app_config in app_configs:
        try:
            url_module = importlib.import_module(
                f"{app_config.name}.urls"
            )
        except (ModuleNotFoundError, LookupError):
            continue
        else:
            app_slug = getattr(url_module, 'app_name', app_config.label)
            patterns.append(
                path(
                    f'{app_slug}/',
                    include(
                        (
                            f"{app_config.name}.urls",
                            app_slug
                        ),
                        namespace=app_slug
                    )
                )
            )
    return patterns


def get_admin_menu_tree(user=None):
    """Get the admin main menu tree, this is generated
    from the detected 'menu.py' file in each installed admin
    app.

    Args:
        user: Optional, if passed prunes the menu of any item
            that the user doesn't have permission to view.
    
    Returns:
        A MenuItemTree object."""
    menu_tree = MenuItemTree([
        MenuItem(
            'Dashboard',
            data={'url': reverse_lazy('admin:dashboard')},
            node_weight=100
        ),
        MenuItem(
            'Logout',
            data={'url': reverse_lazy('logout')},
            node_weight=1000
        )
    ])
    app_configs = get_admin_app_configs()
    for app_config in app_configs:
        try:
            menu_module = importlib.import_module(
                f"{app_config.name}.menu"
            )
        except (ModuleNotFoundError, LookupError):
            continue
        else:
            if hasattr(menu_module, 'menu_nodes'):
                menu_tree.merge_tree(getattr(menu_module, 'menu_nodes'))
            if hasattr(menu_module, 'override_weights'):
                for menu_selector, weight in menu_module.override_weights.items():
                    node = menu_tree.get_node(menu_selector)
                    if node:
                        node.set_node_weight(weight)

    # Deep copying menu is required otherwise menu node instances are stored in memory and modifications
    # to them will persist. Was a rather interesting bug to track down! - R
    menu_tree_copy = deepcopy(menu_tree)

    if user:
        menu_tree_copy.prune_by_permissions(user)
    menu_tree_copy.sort_by_node_weight()
    return menu_tree_copy


def get_admin_css():
    """Get global admin css files, this is detected from the 'admin_css'
    attribute of any installed admin app configs.

    Returns:
        A list of static urls for CSS files."""
    admin_css = []
    app_configs = get_admin_app_configs()
    for app_config in app_configs:
        if hasattr(app_config, 'admin_css'):
            admin_css = admin_css + app_config.admin_css
    return admin_css


def get_admin_js():
    """Get global admin js files, this is detected from the 'admin_js'
    attribute of any installed admin app configs.

    Returns:
        A list of static urls for JS files."""
    admin_js = []
    app_configs = get_admin_app_configs()
    for app_config in app_configs:
        if hasattr(app_config, 'admin_js'):
            admin_js = admin_js + app_config.admin_js
    return admin_js


def get_admin_meta():
    """Get admin meta data, this is detected from the 'admin_meta'
    attribute of any installed admin app configs.

    Returns:
        A list of dicts containing the attributes of meta tags
        to display globally."""
    admin_meta = []
    app_configs = get_admin_app_configs()
    for app_config in app_configs:
        if hasattr(app_config, 'admin_meta'):
            admin_meta = admin_meta + app_config.admin_meta
    return admin_meta
