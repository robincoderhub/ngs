"""
# Users admin app

This app provides an admin section that allows you to manage users, groups and their permissions.

## Requirements
- onyx
- onyx.apps.admin

## Installation

To install this app just add it to your INSTALLED_APPS config
```
INSTALLED_APPS = [
    ...
    'onyx.apps.admin.users',
]
```
"""

default_app_config = 'onyx.apps.admin.users.config.AdminUsersConfig'
