"""Forms related to admin users app"""

from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group, Permission
from django.contrib.auth.password_validation import validate_password

from onyx.forms.generic import ReadOnlyFormMixin


User = get_user_model()


EDIT_USER_FIELD_ORDER = [
    User.USERNAME_FIELD,
    'first_name',
    'last_name',
    'email',
    'password',
    'password_confirm',
    'is_active',
    'is_staff',
]
"""The form field order to use for user model columns."""


class PasswordFormMixin(forms.Form):
    """A form mixin to add password changing functionality to a form."""

    password = forms.CharField(
        widget=forms.PasswordInput(),
        required=False,
        strip=False
    )
    """The field to input the new password."""

    password_confirm = forms.CharField(
        widget=forms.PasswordInput(),
        required=False,
        strip=False
    )
    """A confirmation field for the password."""

    def clean(self):
        """Extends method to validate password but only
        if one or the other has been specified.

        Raises:
            ValidationError: Thrown if passwords do not match.

        Returns:
            A dict of cleaned data"""
        password = self.cleaned_data.get('password')
        password_confirm = self.cleaned_data.get('password_confirm')

        if password or password_confirm:
            try:
                if password != password_confirm:
                    raise forms.ValidationError('Passwords must match')
                validate_password(password)
            except forms.ValidationError as e:
                self.add_error('password', e.messages)
        return super().clean()

    def save(self, *args, **kwargs):
        """Extends save method to call set password method
        on the user model if a password was specified.

        Args:
            *args: Inherited arguments
            **kwargs: Inherited keyword arguments.

        Returns:
            The created/updated model"""
        password = self.cleaned_data.get('password')
        if password:
            self.instance.set_password(password)
        return super().save(*args, **kwargs)


class BaseEditUserForm(forms.ModelForm):
    """A base edit user form to be used for other forms."""

    class Meta:
        model = User
        fields = [
            User.USERNAME_FIELD,
            'first_name',
            'last_name',
            'email',
            'is_active',
            'is_staff'
        ]
        exclude = ['password']

    field_order = EDIT_USER_FIELD_ORDER


class ReadOnlyEditUserForm(BaseEditUserForm, ReadOnlyFormMixin):
    """A read only version of the edit form, this is used to display
    but not edit a user model."""
    pass


class EditUserForm(PasswordFormMixin, BaseEditUserForm):
    """Edit user form

    Args:
        *args: Inherited form arguments
        **kwargs: Inherited form keyword arguments"""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['is_staff'].disabled = True


class CreateUserForm(EditUserForm):
    """Create user form

    Args:
        *args: Inherited form arguments
        **kwargs: Inherited form keyword arguments"""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['password'].required = True


class AdminEditUserForm(EditUserForm):
    """Edit user form for a superuser

    Args:
        *args: Inherited form arguments
        **kwargs: Inherited form keyword arguments"""
    class Meta:
        model = User
        fields = [
            User.USERNAME_FIELD,
            'first_name',
            'last_name',
            'email',
            'is_staff',
            'is_active',
        ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['is_staff'].disabled = False


class AdminCreateUserForm(AdminEditUserForm):
    """Create user form for a superuser

    Args:
        *args: Inherited form arguments
        **kwargs: Inherited form keyword arguments"""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['password'].required = True


class UserPermissionsForm(forms.ModelForm):
    """A form for editing user permissions

    Args:
        *args: Inherited form arguments
        **kwargs: Inherited form keyword arguments"""

    class Meta:
        model = User
        fields = [
            'groups',
            'user_permissions',
        ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['user_permissions'].widget = forms.CheckboxSelectMultiple()
        self.fields['user_permissions'].queryset = Permission.objects.all()
        self.fields['groups'].widget = forms.CheckboxSelectMultiple()
        self.fields['groups'].queryset = Group.objects.all()


class ReadOnlyUserPermissionsForm(UserPermissionsForm, ReadOnlyFormMixin):
    """A read only user permissions form, used for displaying but not editing
    a user's permissions."""
    pass


class EditGroupForm(forms.ModelForm):
    """Edit group form"""

    class Meta:
        model = Group
        fields = [
            'name'
        ]


class ReadOnlyEditGroupForm(EditGroupForm, ReadOnlyFormMixin):
    """A read only edit group form, used for displaying but not
    editing a group."""
    pass


class GroupPermissionsForm(forms.ModelForm):
    """A form for editing a group's permissions.

    Args:
        *args: Inherited form arguments
        **kwargs: Inherited form keyword arguments"""
    class Meta:
        model = Group
        fields = [
            'permissions'
        ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['permissions'].widget = forms.CheckboxSelectMultiple()
        self.fields['permissions'].queryset = Permission.objects.all()


class ReadOnlyGroupPermissionsForm(GroupPermissionsForm, ReadOnlyFormMixin):
    """A read only edit group permissions form, used for displaying but not
    editing a groups permissions."""
    pass
