"""Url patterns for the admin users app"""
from django.urls import path

from onyx.apps.admin.users import views


app_name = 'users'
urlpatterns = [
    path('', views.UserTableView.as_view(), name='list_users'),
    path('create/', views.CreateUserView.as_view(), name='create_user'),
    path('<int:id>/', views.EditUserView.as_view(), name='edit_user'),
    path(
         '<int:id>/delete/',
         views.DeleteUserView.as_view(),
         name='delete_user'
     ),
    path('groups/', views.GroupTableView.as_view(), name='list_groups'),
    path('groups/create/', views.CreateGroupView.as_view(), name='create_group'),
    path('groups/<int:id>/', views.EditGroupView.as_view(), name='edit_group'),
    path(
         'groups/<int:id>/delete/',
         views.DeleteGroupView.as_view(),
         name='delete_group'
     )
]
