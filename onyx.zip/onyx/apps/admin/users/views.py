"""Views related to the admin users app

TODO:
    - These create/edit views can likely be combined"""

from django.urls import reverse_lazy, reverse
from django.contrib.auth.models import Group
from django.contrib.auth import get_user_model
from django.http import Http404
from django.shortcuts import get_object_or_404

from django_tables2 import LinkColumn
from django_tables2.utils import A

from django_filters.filterset import FilterSet

from onyx.apps.admin.views.generic import (
    AdminTableView,
    AdminFormView,
    AdminDeleteView
)
from onyx.apps.admin.users import forms


User = get_user_model()


class UserTableFilterSet(FilterSet):
    """A django_filter filter set class for filtering user
    results."""

    class Meta:
        model = User
        fields = {
            'is_staff': ['exact'],
            'is_active': ['exact'],
            'last_login': ['gt', 'lt']
        }


class UserTableView(AdminTableView):
    """A table view for displaying user models"""

    model = User
    create_button_url = reverse_lazy('admin:users:create_user')
    create_button_permissions = 'users.add_user'
    view_permissions = (
        'users.view_user',
    )
    filter_set_class = UserTableFilterSet
    table_columns = [
        'id',
        User.USERNAME_FIELD,
        'first_name',
        'last_name',
        'is_staff',
    ]
    extra_columns = [
        (' ', LinkColumn('admin:users:edit_user', text='Edit', args=[A('pk')]))
    ]

    def get_queryset(self):
        """Extends method, hides any super users from
        results.

        Returns:
            A django user queryset."""
        return super().get_queryset().filter(is_superuser=False)


class CreateUserView(AdminFormView):
    """Create a user form view view"""

    view_title = 'Create User'
    view_permissions = (
        'users.add_user',
    )

    def get_form_classes(self):
        """Get form classes to display, changes forms
        depending on the permissions level of the user.

        Returns:
            A dict of form classes keyed by alias -> form class"""
        user = self.request.user
        user_form = None
        permissions_form = None

        if user.is_superuser:
            user_form = forms.AdminCreateUserForm
            permissions_form = forms.UserPermissionsForm
        else:
            user_form = forms.CreateUserForm

        definitions = {
            'basic_details': user_form,
        }

        if permissions_form:
            definitions['permissions'] = permissions_form
        return definitions

    def save_forms(self, forms):
        """Override save forms method to save basic user details
        before saving permissions form."""
        forms['basic_details'].save()

        if forms.get('permissions'):
            forms['permissions'].instance = forms['basic_details'].instance
            forms['permissions'].save()

    def get_success_redirect(self, request, form_dict, form_results):
        """Get success redirect, redirect to edit user page

        Args:
            request: The incoming django request
            form_dict: A dict of form instances keyed by alias
            form_results: The results of each form keyed by alias

        Returns:
            A redirect url string."""
        return reverse(
            'admin:users:edit_user', kwargs={
                'id': form_dict['basic_details'].instance.id
            }
        )


class EditUserView(CreateUserView):
    """Edit user view"""

    view_menu_selector = 'users.list_users'
    user_instance = None
    view_permissions = (
        'users.view_user',
    )

    def get_view_breadcrumbs(self):
        """Get view breadcrumbs

        Returns:
            A tuple of tuples in format (label, url)"""
        return (
            ('Users & Groups', None),
            (
                'Edit User',
                reverse(
                    'admin:users:edit_user',
                    args=[
                        self.request_kwargs['id']
                    ]
                )
            ),
        )

    def get_extra_buttons(self):
        """Get extra buttons, adds a delete button

        Returns:
            A list of tuples in format (label, url)"""
        buttons = super().get_extra_buttons() or []
        if self.request.user.has_perm('users.delete_user'):
            button = (
                'Delete',
                reverse(
                    'admin:users:delete_user',
                    kwargs={
                        'id': self.request_kwargs['id']
                    }
                )
            )
            buttons.append(button)
        return buttons

    def get_form_classes(self):
        """Get form classes, returns different edit user
        classes depending on the viewing users permissions.

        Returns:
            A dict of form classes keyed by alias -> form class"""
        user = self.request.user
        target_user = self.get_user_instance()
        user_form = None
        permissions_form = None

        if user.is_superuser:
            user_form = forms.AdminEditUserForm
            permissions_form = forms.UserPermissionsForm
        else:
            can_edit_user = (
                user.has_perm('users.change_user')
                and not target_user.is_staff
                and not target_user.is_superuser
            )
            is_editing_self = (
                user.has_perm('users.change_user')
                and target_user.id == user.id
            )
            if is_editing_self or can_edit_user:
                user_form = forms.EditUserForm
                permissions_form = forms.ReadOnlyUserPermissionsForm
            else:
                user_form = forms.ReadOnlyEditUserForm
                permissions_form = forms.ReadOnlyUserPermissionsForm

        return {
            'basic_details': user_form,
            'permissions': permissions_form
        }

    def get_view_title(self):
        """Get view title, adds user's username to title
        if model has been saved.

        Returns:
            The title string"""
        user = self.get_user_instance()
        name = user.get_full_name()
        if not name:
            name = getattr(user, user.USERNAME_FIELD)
        if not name:
            name = user.id
        return f'Edit user: {name}'

    def get_user_instance(self):
        """Get instance of user model

        Raises:
            Http404: Thrown if user cannot be found or
                user is a super user.

        Returns:
            The model instance being edited."""
        if not self.user_instance:
            self.user_instance = get_object_or_404(
                User,
                id=self.request_kwargs['id']
            )
        if self.user_instance.is_superuser:
            raise Http404()
        return self.user_instance

    def get_form_kwargs(self, form_name):
        """Extends method, adds model instance to form
        keyword arguments.

        Args:
            form_name: The name of the form to get kwargs for

        Returns:
            A dict of keyword arguments"""
        kwargs = super().get_form_kwargs(form_name)
        if form_name == 'basic_details' or form_name == 'permissions':
            kwargs['instance'] = self.get_user_instance()
        return kwargs


class DeleteUserView(AdminDeleteView):
    """View for deleting a user model."""

    view_menu_selector = 'users.list_users'
    model = User
    view_permissions = [
        'users.delete_user'
    ]

    def get_model(self):
        """Get model, prevents deletion of superusers

        Raises:
            Http404: Thrown if user is a superuser

        Returns:
            The user model for deletion"""
        user = super().get_model()
        if user.is_superuser:
            raise Http404()
        return user

    def get_view_breadcrumbs(self):
        """Get view breadcrumbs

        Returns:
            A tuple of tuples in format (label, url)"""
        return (
            (
                'Users & Groups',
                None
            ),
            (
                'Edit User',
                reverse(
                    'admin:users:edit_user',
                    kwargs={'id': self.request_kwargs['id']}
                )
            ),
            (
                'Delete User',
                reverse(
                    'admin:users:delete_user',
                    kwargs={'id': self.request_kwargs['id']}
                )
            ),
        )


class GroupTableView(AdminTableView):
    """A table view to list group models"""

    model = Group
    view_menu_selector = 'users.list_groups'
    view_breadcrumbs = [
        ('Home', reverse_lazy('admin:dashboard')),
        ('Groups', None)
    ]
    view_permissions = (
        'auth.view_group',
    )
    create_button_url = reverse_lazy('admin:users:create_group')
    create_button_permissions = 'auth.add_group'
    extra_columns = [
        (
            ' ',
            LinkColumn(
                'admin:users:edit_group',
                text='Edit',
                args=[A('pk')]
            )
        )
    ]


class CreateGroupView(AdminFormView):
    """View for creating a group"""

    view_title = 'Create Group'
    view_permissions = (
        'auth.add_group',
    )

    def get_form_classes(self):
        """Get form classes, returns different edit group
        classes depending on the viewing users permissions.

        Returns:
            A dict of form classes keyed by alias -> form class"""
        user = self.request.user
        basic_form = forms.ReadOnlyEditGroupForm
        permissions_form = forms.ReadOnlyGroupPermissionsForm

        if user.has_perm('auth.add_group'):
            basic_form = forms.EditGroupForm

        if user.is_superuser:
            permissions_form = forms.GroupPermissionsForm

        return {
            'basic_details': basic_form,
            'permissions': permissions_form
        }

    def save_forms(self, forms):
        """Save forms method  override, ensures basic
        details are saved before saving user permissions

        Args:
            forms: A dict of form instances keyed by alias -> form instance."""
        forms['basic_details'].save()
        if forms.get('permissions'):
            forms['permissions'].instance = forms['basic_details'].instance
            forms['permissions'].save()

    def get_success_redirect(self, request, form_dict, form_results):
        """Override, returns redirect to edit user page

        Returns:
            The redirect url"""
        return reverse(
            'admin:users:edit_group',
            kwargs={
                'id': form_dict['basic_details'].instance.id
            }
        )


class EditGroupView(CreateGroupView):
    """A view for editing a group model"""

    view_menu_selector = 'users.list_groups'

    view_permissions = (
        'auth.view_group',
    )

    group_instance = None
    """A local variable to store the group instance being edited"""

    def get_view_breadcrumbs(self):
        """Get view breadcrumbs

        Returns:
            A tuple of tuples in format (label, url)"""
        return (
            (
                'Users & Groups',
                None
            ),
            (
                'Edit Group',
                reverse(
                    'admin:users:edit_group',
                    kwargs={
                        'id': self.request_kwargs['id']
                    }
                )
            )
        )

    def get_extra_buttons(self):
        """Get extra buttons, adds a delete button

        Returns:
            A list of tuples in format (label, url)"""
        buttons = super().get_extra_buttons() or []
        if self.request.user.has_perm('auth.delete_group'):
            buttons.append(
                (
                    'Delete',
                    reverse(
                        'admin:users:delete_group',
                        kwargs={
                           'id': self.request_kwargs['id']
                        }
                    )
                )
            )
        return buttons

    def get_form_classes(self):
        """Get form classes, returns different edit group
        classes depending on the viewing users permissions.

        Returns:
            A dict of form classes keyed by alias -> form class"""
        user = self.request.user
        definitions = super().get_form_classes()

        if not user.has_perm('auth.change_group'):
            definitions['basic_details'] = forms.ReadOnlyEditGroupForm

        return definitions

    def get_view_title(self):
        """Get view title

        Returns:
            The string title."""
        return f'Edit Group: {self.get_group_instance().name}'

    def get_group_instance(self):
        """Get instance of group being edited

        Raises:
            Httpt404: Thrown if group could not be found.

        Returns:
            The group instance being edited."""
        if not self.group_instance:
            self.group_instance = Group.objects.get(
                pk=self.request_kwargs['id']
            )
        return self.group_instance

    def get_form_kwargs(self, form_name):
        """Extends method, adds model instance to form
        keyword arguments.

        Args:
            form_name: The name of the form to get kwargs for

        Returns:
            A dict of keyword arguments"""
        kwargs = super().get_form_kwargs(form_name)
        kwargs['instance'] = self.get_group_instance()
        return kwargs


class DeleteGroupView(AdminDeleteView):
    """A view for deleting a group model"""

    view_permissions = (
        'auth.delete_group',
    )
    view_menu_selector = 'users.list_groups'

    model = Group
    delete_redirect_url = reverse_lazy('admin:users:manage_groups')

    def get_view_breadcrumbs(self):
        """Get view breadcrumbs

        Returns:
            A tuple of tuples in format (label, url)"""
        return (
            (
                'Users & Groups',
                None
            ),
            (
                'Edit group',
                reverse(
                    'admin:users:edit_group',
                    kwargs={
                        'id': self.request_kwargs['id']
                    }
                )
            ),
            (
                'Delete group',
                reverse(
                    'admin:users:delete_group',
                    kwargs={
                        'id': self.request_kwargs['id']
                    }
                )
            ),
        )
