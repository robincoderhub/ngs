"""Admin users app config classes"""

from onyx.apps.admin.config import AbstractAdminAppConfig


class AdminUsersConfig(AbstractAdminAppConfig):
    """Default users admin app config."""

    name = "onyx.apps.admin.users"
    """The python path to the app"""

    verbose_name = "Onyx - Admin - Users"
    """The human readable name of the app"""

    label = "onyx_admin_users"
    """The internal Django name of the app"""
