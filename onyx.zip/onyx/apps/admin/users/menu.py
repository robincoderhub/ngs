"""Admin users admin menu items definitions"""

from django.urls import reverse_lazy

from onyx.utils.conditionals import OR
from onyx.apps.cms.menus.items import MenuItem


menu_nodes = [
    MenuItem(
        'Users & Groups',
        'users',
        node_weight=250,
        required_permissions=OR('users.view_user') | OR('auth.view_group'),
        node_children=[
            MenuItem(
                'Create User',
                data={
                    'url': reverse_lazy('admin:users:create_user')
                },
                required_permissions=OR('users.add_user')
            ),
            MenuItem(
                'User List',
                'list_users',
                data={
                    'url': reverse_lazy('admin:users:list_users')
                },
                required_permissions=OR('users.view_user')
            ),
            MenuItem(
                'Create Group',
                data={
                    'label': 'Create group',
                    'url': reverse_lazy('admin:users:create_group')
                },
                required_permissions=OR('auth.add_group')
            ),
            MenuItem(
                'Group List',
                'list_groups',
                data={
                    'url': reverse_lazy('admin:users:list_groups')
                },
                required_permissions=OR('auth.view_group')
            )
        ]
    )
]
