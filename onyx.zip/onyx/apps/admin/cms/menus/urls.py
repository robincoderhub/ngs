"""Url patterns for menus admin app"""

from django.urls import path

from onyx.apps.admin.cms.menus import views


app_name = 'menus'
urlpatterns = [
    path('', views.MenuTableView.as_view(), name='list_menus'),
    path('create/', views.EditMenuView.as_view(), name='create_menu'),
    path('<int:id>/', views.EditMenuView.as_view(), name='edit_menu'),
    path('<int:id>/delete/', views.DeleteMenuView.as_view(), name='delete_menu')
]
