"""App config classes for menus admin app"""

from onyx.apps.admin.config import AbstractAdminAppConfig


class AdminMenusConfig(AbstractAdminAppConfig):
    """Default app config for menus admin app"""

    name = "onyx.apps.admin.cms.menus"
    """The python path to the app"""

    verbose_name = "Onyx - Admin - CMS - Menus"
    """The human readable name of the app"""

    label = "onyx_admin_cms_menus"
    """The internal Django name of the app"""
