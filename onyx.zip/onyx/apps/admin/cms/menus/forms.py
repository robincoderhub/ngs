"""Forms related to menus admin app"""

import json

from django import forms
from django.core.exceptions import ValidationError
from django.db import transaction

from onyx.apps.cms.menus.core import get_menu_item_class
from onyx.apps.cms.menus.models import Menu, MenuItem
from onyx.apps.cms.menus.widgets import MenuEditorWidget


class EditMenuForm(forms.ModelForm):
    """Model form for editing menu models

    Args:
        *args: Inherited form arguments
        **kwargs: Inherited keyword arguments"""

    class Meta:
        model = Menu
        exclude = []

    menu = forms.CharField(widget=MenuEditorWidget(), label='')
    """Additional field for capturing menu configuration which will
    then be converted into models."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['menu'].widget.menu = self.instance
        self.fields['name'].label = 'Internal name'

        if self.instance.id:
            # If editing an existing menu, populate menu editing
            # field with the details of the current menu
            top_items = self.instance.items.filter(parent=None)

            def create_raw_item(item):
                """Create a 'raw' item, a dict of menu item details
                and populate the item's children if applicable.

                Args:
                    item: The MenuItem instance to convert

                Returns:
                    A dict of item information."""
                raw_item = {
                    'label': item.label,
                    'name': item.name,
                    'item_type': item.type_key,
                    'weight': item.weight,
                    'form_data': item.data,
                    'children': []
                }
                for sub_item in item.children.all():
                    raw_item['children'].append(
                        create_raw_item(sub_item)
                    )
                return raw_item
            raw_items = []
            for item in top_items:
                raw_items.append(
                    create_raw_item(item)
                )
            self.fields['menu'].initial = json.dumps(raw_items)
        else:
            self.fields['menu'].initial = '[]'

    def clean_menu(self):
        """Clean menu field, ensures all menu item data is valid before
        attempting to save.

        Raises:
            ValidationError: Thrown if an error was found with an item

        Returns:
            The cleaned menu data"""
        decoded_menu = json.loads(self.cleaned_data['menu'])

        def recursive_check(item):
            """A recursive function for validating menu items and
            their children.

            Args:
                item: The raw menu item dict

            Raises:
                ValidationError: Thrown if an error is found."""
            item_name = item['name']
            item_class = get_menu_item_class(item['item_type'])
            if not item_class:
                raise ValidationError(
                    f'Unknown item type specified for menu item "{item_name}"'
                )
            item_form = item_class.get_item_form_class()(
                data=item['form_data'])
            if not item_form.is_valid():
                raise ValidationError(
                    f'Menu item "{item_name}" does not validate.'
                )
            sub_item_names = []
            for sub_item in item['children']:
                if sub_item['name'] in sub_item_names:
                    raise ValidationError(
                        f"Cannot have two items named \"{sub_item['name']}\""
                        + ' in the same menu or sub menu.'
                    )
                sub_item_names.append(sub_item['name'])
                recursive_check(sub_item)
        item_names = []
        for item in decoded_menu:
            if item['name'] in item_names:
                raise ValidationError(
                    f"Cannot have two items named \"{item['name']}\""
                    + ' in the same menu or sub menu.'
                )
            item_names.append(item['name'])
            recursive_check(item)
        return self.cleaned_data['menu']

    def save(self, *args, **kwargs):
        """Extends method, once the menu has been saved, populate the items
        within using the 'menu' field data.

        Args:
            *args: Inherited arguments
            **kwargs: Inherited keyword arguments

        Returns:
            The saved Menu instance."""
        with transaction.atomic():
            super().save(*args, **kwargs)
            menu = self.instance
            raw_items = json.loads(self.cleaned_data['menu'])

            # TODO would be nice to re-use existing rows - R
            menu.items.all().delete()

            def recursive_add(raw_item, parent=None):
                item = MenuItem()
                item.menu = menu
                if parent:
                    item.parent = parent

                item.label = raw_item['label']
                item.name = raw_item['name']
                item.type_key = raw_item['item_type']
                item.weight = raw_item['weight']
                item.data = raw_item['form_data']
                item.save()

                for sub_item in raw_item['children']:
                    recursive_add(sub_item, item)

            for raw_item in raw_items:
                recursive_add(raw_item)
            return menu
