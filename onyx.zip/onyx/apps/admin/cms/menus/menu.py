"""Admin menu items for menus admin app"""
from django.urls import reverse_lazy

from onyx.apps.cms.menus.items import MenuItem


menu_nodes = [
    MenuItem('Menus', node_weight=200, node_children=[
        MenuItem(
            'Create Menu',
            data={'url': reverse_lazy('admin:menus:create_menu')}
        ),
        MenuItem(
            'List Menus',
            data={'url': reverse_lazy('admin:menus:list_menus')}
        )
    ])
]
