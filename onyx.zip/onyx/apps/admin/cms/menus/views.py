"""Views related to the menus admin app"""

from django.urls import reverse, reverse_lazy
from django.shortcuts import get_object_or_404

from django_tables2 import LinkColumn
from django_tables2.utils import A

from onyx.apps.admin.views.generic import (
    AdminFormView,
    AdminTableView,
    AdminDeleteView
)
from onyx.apps.cms.menus.models import Menu
from onyx.apps.admin.cms.menus.forms import EditMenuForm


class MenuTableView(AdminTableView):
    """View for displaying menu models"""
    model = Menu
    view_menu_selector = 'menus.list_menus'
    view_breadcrumbs = [
        ('Home', reverse_lazy('admin:dashboard')),
        ('Menus', None)
    ]
    view_permissions = (
        'onyx_cms_menus.view_menus',
    )
    create_button_url = reverse_lazy('admin:menus:create_menu')
    create_button_permissions = 'onyx_cms_menus.add_menu'
    extra_columns = [
        (' ', LinkColumn('admin:menus:edit_menu', text='Edit', args=[A('pk')]))
    ]


class EditMenuView(AdminFormView):
    """View for editing/creating menu model instances."""

    form_classes = {
        'basic_details': EditMenuForm
    }
    view_title = 'Create Menu'
    view_permissions = (
        'onyx_cms_menus.add_menu',
    )
    view_menu_selector = 'menus.list_menus'

    instance = None
    """The model instance being edited"""

    def is_editing(self):
        """Whether or not view is editing or creating a
        menu.

        Returns:
            True if editing, False if creating."""
        return ('id' in self.request_kwargs)

    def get_instance(self):
        """Get the model instance being edited/created

        Raises:
            Http404: Thrown if model is not found

        Returns:
            A Menu model instance."""
        if self.instance is None:
            if self.is_editing():
                self.instance = get_object_or_404(
                    Menu,
                    id=self.request_kwargs['id']
                )
            else:
                self.instance = Menu()
        return self.instance

    def get_view_title(self):
        """Get view title, differs depending on editing or
        creating.

        Returns:
            The title string."""
        return 'Edit Menu' if self.is_editing() else 'Create Menu'

    def get_view_permissions(self):
        """Get permission for viewing this view

        Returns:
            A conditional object, edit_menu for editing otherwise
            add_menu."""
        return (
            ['onyx_cms_menus.edit_menu']
            if self.is_editing()
            else ['onyx_cms_menus.add_menu']
        )

    def get_view_menu_selector(self):
        """Get view menu selector, differs on create or editing.

        Returns:
            The menu selector string."""
        return (
            'menus.list_menus'
            if self.is_editing()
            else 'menus.create_menu'
        )

    def get_form_kwargs(self, *args, **kwargs):
        """Get form keyword arguments, adds instance to
        form keywords

        Args:
            *args: Inherited arguments
            **kwargs: Inherited keyword arguments

        Returns:
            The updated keyword arguments."""
        kwargs = super().get_form_kwargs(*args, **kwargs)
        kwargs['instance'] = self.get_instance()
        return kwargs

    def get_success_redirect(self, request, form_dict, form_results):
        """Get success redirect, redirects to edit menu page.

        Args:
            request: The incoming request object
            form_dict: A dict keyed by alias -> form instance
            form_results: The result of the saved forms keyed by
                alias -> result

        Returns:
            The url to redirect to."""
        return reverse(
            'admin:menus:edit_menu',
            kwargs={
                'id': form_dict['basic_details'].instance.id
            }
        )

    def get_extra_buttons(self):
        """Get extra buttons for this view, adds a delete button
        if user is editing an existing model.

        Returns:
            A list of tuples containing (label, url)"""
        buttons = super().get_extra_buttons() or []
        if (
            self.request.user.has_perm('onyx_cms_menus.delete_menu')
            and self.is_editing()
        ):
            buttons.append(
                (
                    'Delete',
                    reverse(
                        'admin:menus:delete_menu',
                        kwargs={'id': self.request_kwargs['id']}
                    )
                )
            )
        return buttons


class DeleteMenuView(AdminDeleteView):
    view_permissions = (
        'onyx_cms_menus.delete_menu',
    )
    view_menu_selector = 'menus.list_menus'

    model = Menu
    delete_redirect_url = reverse_lazy('admin:menus:list_menus')

    def get_view_breadcrumbs(self):
        """Get breadcrumbs for this view

        Returns:
            A tuple of tuples in format (label, url)"""
        return (
            ('Menus', None),
            (
                'Edit menu',
                reverse(
                    'admin:menus:edit_menu',
                    kwargs={'id': self.request_kwargs['id']}
                )
            ),
            (
                'Delete menu',
                reverse(
                    'admin:menus:delete_menu',
                    kwargs={'id': self.request_kwargs['id']}
                )
            ),
        )
