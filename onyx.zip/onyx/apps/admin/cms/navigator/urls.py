"""Url patterns for navigator admin app"""

from django.urls import path

from onyx.apps.admin.cms.navigator import views

app_name = 'navigator'
urlpatterns = [
    path('', views.Homepage.as_view(), name='homepage')
]
