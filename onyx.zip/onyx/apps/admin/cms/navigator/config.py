"""App configs for navigator admin app"""

from onyx.apps.admin.config import AbstractAdminAppConfig


class AdminNavigatorConfig(AbstractAdminAppConfig):
    """Default app config for navigator admin app"""

    name = "onyx.apps.admin.cms.navigator"
    """The python path to the app"""

    verbose_name = "Onyx - Admin - CMS - Navigator"
    """The human readable name of the app"""

    label = "onyx_admin_cms_navigator"
    """The internal Django name of the app"""
