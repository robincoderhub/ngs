"""Admin menu items for navigator admin app"""

from django.urls import reverse_lazy

from onyx.apps.cms.menus.items import MenuItem


menu_nodes = [
    MenuItem(
        'Resource Navigator',
        node_weight=240,
        data={
            'url': reverse_lazy('admin:navigator:homepage')
        }
    )
]
