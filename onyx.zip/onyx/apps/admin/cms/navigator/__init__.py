"""
# Navigator admin app

This app provides an admin section for using the standalone Navigator media manager allowing users to manage their uploaded files.

## Requirements
- onyx
- onyx.apps.admin
- onyx.apps.admin.cms
- onyx.apps.cms
- onyx.apps.cms.navigator

## Installation

To install this app just add it to your INSTALLED_APPS config
```
INSTALLED_APPS = [
    ...
    'onyx.apps.admin.cms.navigator',
]
```
"""

default_app_config = 'onyx.apps.admin.cms.navigator.config.AdminNavigatorConfig'
