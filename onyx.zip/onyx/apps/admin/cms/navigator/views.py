"""Views related to navigator admin app"""

from onyx.apps.admin.views.generic import AdminView


class Homepage(AdminView):
    """Main page, displays the navigator media manager"""

    template_name = 'onyx/apps/admin/cms/navigator/homepage.html'
    """The template name of the page"""

    view_title = 'Resource Navigator'
    """The view title"""

    view_menu_selector = 'resource_navigator'
    """The view menu selector"""
