"""App config classes for CMS admin app"""

from onyx.apps.admin.config import AbstractAdminAppConfig


class AdminCMSConfig(AbstractAdminAppConfig):
    """Default app config for CMS admin app"""

    name = "onyx.apps.admin.cms"
    """The python path to the app"""

    verbose_name = "Onyx - Admin - CMS"
    """The human readable name of the app"""

    label = "onyx_admin_cms"
    """The internal Django name of the app"""
