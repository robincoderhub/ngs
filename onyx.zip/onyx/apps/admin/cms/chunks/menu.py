"""Admin menu item definitions for chunks admin app"""

from django.urls import reverse_lazy

from onyx.apps.cms.menus.items import MenuItem


menu_nodes = [
    MenuItem(
        'Chunks',
        node_weight=220,
        node_children=[
            MenuItem(
                'Create Chunk',
                data={
                    'url': reverse_lazy('admin:chunks:create_chunk')
                }
            ),
            MenuItem(
                'List Chunks',
                data={
                    'url': reverse_lazy('admin:chunks:list_chunks')
                }
            )
        ]
    )
]
