"""Forms related to chunks admin app"""

from django import forms

from onyx.apps.cms.register import get_widget_types
from onyx.apps.cms.models import Chunk


class WidgetOrderForm(forms.Form):
    """A form for defining a widget's order in the page."""

    order = forms.IntegerField(min_value=0, initial=0)
    """Field for specifying widget's order."""


class EditChunkForm(forms.ModelForm):
    """Model form for editing a chunk's data.

    Args:
        *args: Inherited arguments
        **kwargs: Inherited keyword arguments"""

    class Meta:
        model = Chunk
        exclude = ['global_chunk', 'widgets', 'system_chunk']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.instance.id:
            self.fields['chunk_name'].disabled = True


class SelectChunkWidgetForm(forms.Form):
    """Form for selecting a widget for a chunk.

    Args:
        *args: Inherited arguments
        **kwargs: Inherited keyword arguments"""

    widget = forms.ChoiceField()
    """Choice field for widget types."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['widget'].choices = sorted([
            (widget_name, widget_type.get_label())
            for widget_name, widget_type in get_widget_types().items()
        ], key=lambda x: x[1])
