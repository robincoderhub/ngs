"""
# Chunks admin app

This app provides an admin section for creating and managing chunks and their widgets.

## Requirements
- onyx
- onyx.apps.admin
- onyx.apps.admin.cms
- onyx.apps.cms

## Installation

To install this app just add it to your INSTALLED_APPS config
```
INSTALLED_APPS = [
    ...
    'onyx.apps.admin.cms.chunks',
]
```
"""

default_app_config = 'onyx.apps.admin.cms.chunks.config.AdminCMSChunksConfig'
