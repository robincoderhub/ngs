"""django_tables column classes for chunks admin app"""

from django_tables2 import Column

from onyx.apps.cms.register import (
    get_widget_type
)


class WidgetDataColumn(Column):
    """Column for displaying the output of a Widget's type's classes
    method. This is typically used to call the get_label or get_description
    methods.

    Args:
        widget_method: The method to call to get this columns
            content.
        *args: Inherited arguments
        **kwargs: Inherited keyword arguments""" 
    def __init__(self, widget_method, *args, **kwargs):
        super().__init__(*args, accessor='widget_type', **kwargs)
        self.widget_method = widget_method
        self.orderable = False

    def render(self, value):
        """Render this column, calls the method on the given
        widget's 'type' class and displays the output.

        Args:
            value: The value of the column (the widget type)

        Returns:
            The string output of the method."""
        widget_type = get_widget_type(value)
        if not widget_type:
            return 'ERROR: UNKNOWN WIDGET TYPE'
        return getattr(widget_type, self.widget_method)()
