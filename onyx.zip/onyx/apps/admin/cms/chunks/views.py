"""View related to chunks admin app"""

from django.forms import BaseFormSet
from django.forms.utils import pretty_name
from django.shortcuts import redirect, get_object_or_404
from django.db.models import Max
from django.urls import reverse_lazy, reverse
from django.http import Http404

from django_tables2 import LinkColumn, Column
from django_tables2.utils import A

from onyx.apps.admin.views.generic import (
    AdminTableView,
    AdminFormView,
    AdminDeleteView
)
from onyx.utils import to_json_safe_object
from onyx.apps.cms.register import get_widget_type
from onyx.apps.cms.models import Chunk, Widget
from onyx.apps.admin.cms.chunks.forms import (
    WidgetOrderForm,
    SelectChunkWidgetForm,
    EditChunkForm
)
from onyx.apps.admin.cms.chunks.columns import WidgetDataColumn


class BaseEditWidgetView(AdminFormView):
    """A base class for a edit widget view"""

    widget_model = None
    """The widget model being created/edited"""

    widget_type = None
    """The widget type class for the widget we're creating"""

    def is_editing(self):
        """Whether or not view is editing an existing widget

        Returns:
            True if editing, false if creating."""
        return 'widget_id' in self.request_kwargs

    def get_view_title(self):
        prefix = 'Edit' if self.is_editing() else 'Add'
        label = self.get_widget_type().get_label()
        return f'{prefix} "{label}" widget'

    def get_view_permissions(self):
        return (
            'onyx_cms.edit_widget'
            if self.is_editing()
            else 'onyx_cms.add_widget',
        )

    def get_form_classes(self):
        form_classes = {
            'order': WidgetOrderForm
        }
        widget_form_classes = self.get_widget_type().get_widget_form_classes()
        for key, form in widget_form_classes.items():
            form_classes[key] = form
        return form_classes

    def get_tab_definitions(self):
        form_keys = self.get_form_classes().keys()
        tabs = []
        order_added = False
        for key in form_keys:
            if key == 'order':
                continue
            if not order_added:
                tabs.append(
                    (
                        pretty_name(key),
                        [
                            'order',
                            key
                        ]
                    )
                )
                order_added = True
            else:
                tabs.append(
                    (
                        pretty_name(key),
                        [
                            key
                        ]
                    )
                )
        return tabs

    def get_widget_model(self):
        """Get the widget model being edited/created

        Raises:
            Http404: Thrown if widget cannot be found

        Returns:
            The Widget model"""
        if not self.widget_model:
            if self.is_editing():
                self.widget_model = get_object_or_404(
                    Widget,
                    id=self.request_kwargs['widget_id']
                )
            else:
                self.widget_model = Widget()
        return self.widget_model

    def get_widget_type_name(self):
        """Get the widget type name for the widget we're editing

        Raises:
            Http404: Thrown if widget model or widget type could
                not be found.

        Returns:
            The string widget name"""
        if self.is_editing():
            widget_type = self.get_widget_model().widget_type
        else:
            widget_type = self.request_kwargs['widget_type']
        if not widget_type:
            raise Http404('Widget type could not be determined')
        return widget_type

    def get_widget_type(self):
        """Get widget type class

        Raises:
            Http404: Thrown if widget could not be found
            ValueError: Thrown if widget type is not registered

        Returns:
            The widget type class"""
        if not self.widget_type:
            widget_name = self.get_widget_type_name()
            self.widget_type = get_widget_type(widget_name)
            if not self.widget_type:
                raise ValueError(
                    f"Widget type '{widget_name}' could not be found"
                )
        return self.widget_type

    def update_widget(self, request, forms):
        """Process for updating/creating widget

        Args:
            request: The incoming django request object
            forms: A dict of valid forms keyed by alias

        Returns:
            The widget model and whether or not is was created or edited"""
        widget_data = {}
        order = forms['order'].cleaned_data['order']
        for key, form in forms.items():
            if isinstance(form, BaseFormSet):
                form_rows = []
                for sub_form in form:
                    if (
                        sub_form.cleaned_data.get('DELETE', False)
                        or not sub_form.cleaned_data
                    ):
                        continue
                    form_rows.append(
                        to_json_safe_object(sub_form.cleaned_data)
                    )
                widget_data[key] = to_json_safe_object(form_rows)
            else:
                widget_data[key] = to_json_safe_object(form.cleaned_data)
        widget_model = self.get_widget_model()
        created = widget_model.id is None
        widget_model.data = widget_data
        widget_model.widget_type = self.get_widget_type_name()
        widget_model.order = order
        widget_model.save()
        return widget_model, created

    def get_form_kwargs(self, form_name):
        widget_model = self.get_widget_model()
        if not widget_model.id:
            return {}
        if form_name == 'order':
            current_data = {
                'order': widget_model.order
            }
        else:
            current_data = widget_model.data.get(
                form_name,
                {}
            )
        return {
            'initial': current_data
        }


class ChunkTableView(AdminTableView):
    """A view for listing chunks"""

    view_title = 'List Chunks'
    model = Chunk
    create_button_url = reverse_lazy('admin:chunks:create_chunk')
    create_button_permissions = 'onyx_cms.add_chunk'
    view_permissions = (
        'onyx_cms.view_chunk',
    )
    table_columns = []
    extra_columns = [
        (
            'Name',
            Column(accessor='label', verbose_name='Name')
        ),
        (
            'Description',
            Column(accessor='description')
        ),
        (
            'Internal Name',
            Column(accessor='chunk_name', verbose_name='Internal Name')
        ),
        (
            'System Chunk',
            Column(accessor='system_chunk', verbose_name='System Chunk')
        ),
        (
            ' ',
            LinkColumn(
                'admin:chunks:edit_chunk',
                text='Edit',
                args=[A('id')]
            )
        )
    ]
    view_breadcrumbs = (
        ('Chunks', reverse_lazy('admin:chunks:list_chunks')),
    )

    def get_queryset(self):
        return super().get_queryset().filter(global_chunk=True)


class EditChunkView(AdminFormView):
    """View for editing chunk details"""

    model = Chunk
    form_classes = {
        'basic_details': EditChunkForm
    }

    chunk_model = None
    """The Chunk model being created/edited"""

    def get_view_breadcrumbs(self):
        crumbs = [
            (
                'List Chunks',
                reverse_lazy('admin:chunks:list_chunks')
            )
        ]
        if self.is_editing():
            crumbs.append(
                (
                    self.get_view_title(),
                    reverse_lazy(
                        'admin:chunks:edit_chunk',
                        args=[self.request_kwargs['chunk_id']]
                    )
                )
            )
        else:
            crumbs.append(
                (
                    self.get_view_title(),
                    reverse_lazy(
                        'admin:chunks:create_chunk'
                    )
                )
            )
        return crumbs

    def get_view_menu_selector(self):
        if self.is_editing():
            return 'chunks.list_chunks'
        return 'chunks.create_chunk'

    def get_extra_buttons(self):
        buttons = []
        if self.is_editing():
            chunk = self.get_chunk_instance()
            buttons.append(
                (
                    'Contents',
                    reverse_lazy(
                        'admin:chunks:list_chunk_widgets',
                        args=[chunk.id]
                    )
                )
            )
            if not chunk.system_chunk:
                buttons.append(
                    (
                        'Delete',
                        reverse_lazy(
                            'admin:chunks:delete_chunk',
                            args=[chunk.id]
                        )
                    )
                )
        return buttons

    def get_view_title(self):
        if self.is_editing():
            return f'Edit Chunk: {self.get_chunk_instance().label}'
        return 'Create Chunk'

    def is_editing(self):
        """Whether or not we're editing or creating a chunk

        Returns:
            True if editing, False if creating."""
        return 'chunk_id' in self.request_kwargs

    def get_chunk_instance(self):
        """Get the chunk model instance being edited/created

        Raises:
            Http404: Thrown if specified chunk could not be found.

        Returns:
            The Chunk model"""
        if not self.chunk_model:
            if self.is_editing():
                self.chunk_model = get_object_or_404(
                    Chunk,
                    id=self.request_kwargs['chunk_id']
                )
            else:
                self.chunk_model = Chunk(
                    global_chunk=True
                )
        return self.chunk_model

    def get_form_kwargs(self, form_name):
        if form_name == 'basic_details':
            return {
                'instance': self.get_chunk_instance()
            }
        return {}

    def get_success_redirect(self, request, form_dict, form_results):
        return reverse(
            'admin:chunks:edit_chunk',
            args=[form_dict['basic_details'].instance.id]
        )


class DeleteChunkView(AdminDeleteView):
    """View for deleting Chunk models"""
    view_menu_selector = 'chunks.list_chunks'
    model = Chunk
    model_id_param = 'chunk_id'
    view_permissions = [
        'onyx_cms.delete_chunk'
    ]


class ChunkWidgetsTableView(AdminTableView):
    """View for listing the widgets of a particular Chunk"""

    view_menu_selector = 'chunks.list_chunks'
    create_button_permissions = 'onyx_cms.add_widget'
    model = Widget
    view_permissions = (
        'onyx_cms.view_chunk',
    )
    table_columns = [
        'order'
    ]

    chunk_model = None
    """The Chunk model being viewed"""

    def get_view_title(self):
        return f"Edit widgets: {self.get_chunk_model().label}"

    def get_view_breadcrumbs(self):
        chunk = self.get_chunk_model()
        return (
            (
                'Chunks',
                reverse_lazy('admin:chunks:list_chunks')
            ),
            (
                chunk.label,
                reverse_lazy(
                    'admin:chunks:edit_chunk',
                    args=[
                        chunk.id
                    ]
                )
            ),
            (
                'Widgets',
                reverse_lazy(
                    'admin:chunks:list_chunk_widgets',
                    args=[
                        chunk.id
                    ]
                )
            ),
        )

    def get_create_button_url(self):
        return reverse(
            'admin:chunks:select_chunk_widget_type',
            args=[
                self.request_kwargs['chunk_id']
            ]
        )

    def get_extra_columns(self):
        return [
            (
                'Name',
                WidgetDataColumn('get_label', verbose_name='Name')
            ),
            (
                'Description',
                WidgetDataColumn('get_description', verbose_name='Description')
            ),
            (
                ' ',
                LinkColumn(
                    'admin:chunks:edit_chunk_widget',
                    text='Edit',
                    args=[
                        self.request_kwargs['chunk_id'],
                        A('id')
                    ]
                )
            )
        ]

    def get_chunk_model(self):
        """Get the chunk model being viewed

        Raises:
            Http404: Thrown if Chunk model specified could not be found.

        Returns:
            The Chunk model being viewed"""
        if not self.chunk_model:
            self.chunk_model = get_object_or_404(
                Chunk,
                id=self.request_kwargs['chunk_id'],
                global_chunk=True
            )
        return self.chunk_model

    def get_queryset(self):
        return self.get_chunk_model().widgets.all().order_by('order')


class SelectChunkWidgetTypeView(AdminFormView):
    """View for selecting the type of widget to create"""

    view_menu_selector = 'chunks.list_chunks'
    view_title = 'Select widget type'
    view_permissions = (
        'onyx_cms.add_widget',
    )
    form_classes = {
        'basic_details': SelectChunkWidgetForm
    }
    success_message = None
    submit_label = 'Select'
    view_breadcrumbs = (
        ('Chunks', reverse_lazy('admin:chunks:list_chunks')),
        ('Select chunk', reverse_lazy('admin:chunks:select_chunk')),
    )

    def get_view_breadcrumbs(self):
        chunk = get_object_or_404(Chunk, id=self.request_kwargs['chunk_id'])
        return (
            (
                'Chunks',
                reverse_lazy('admin:chunks:list_chunks')
            ),
            (
                chunk.label,
                reverse_lazy(
                    'admin:chunks:edit_chunk',
                    args=[
                        self.request_kwargs['chunk_id']
                    ]
                )
            ),
            (
                "Widgets",
                reverse_lazy(
                    'admin:chunks:list_chunk_widgets',
                    args=[
                        self.request_kwargs['chunk_id']
                    ]
                )
            ),
            (
                'Select widget type',
                reverse_lazy(
                    'admin:chunks:select_chunk_widget_type',
                    args=[
                        self.request_kwargs['chunk_id']
                    ]
                )
            )
        )

    def forms_valid(self, request, forms, *args, **kwargs):
        return redirect(
            reverse(
                'admin:chunks:create_chunk_widget',
                kwargs={
                    'chunk_id': self.request_kwargs['chunk_id'],
                    'widget_type': forms['basic_details'].cleaned_data[
                        'widget'
                    ]
                }
            )
        )


class EditChunkWidgetView(BaseEditWidgetView):
    """View for editing a widget in a chunk"""
    view_menu_selector = 'chunks.list_chunks'

    chunk_model = None
    """The Chunk the widget belongs to"""

    def get_chunk_model(self):
        """Get the chunk model this widget will/does belong to

        Raises:
            Http404: Thrown if chunk is not found

        Returns:
            The Chunk model."""
        if not self.chunk_model:
            self.chunk_model = get_object_or_404(
                Chunk,
                id=self.request_kwargs['chunk_id']
            )
        return self.chunk_model

    def create_forms(self, *args, **kwargs):
        # Remove 'this' chunk from choices if a chunk
        # widget
        forms = super().create_forms(*args, **kwargs)
        chunk = self.get_chunk_model()
        if self.get_widget_type_name() == 'chunk':
            choices = forms['basic_details'].fields['chunk_name'].choices
            new_choices = [
                choice
                for choice in choices
                if choice[0] != chunk.chunk_name
            ]
            forms['basic_details'].fields['chunk_name'].choices = new_choices
        return forms

    def get_extra_buttons(self):
        buttons = []
        if self.is_editing():
            buttons.append(
                (
                    'Delete Widget',
                    reverse(
                        'admin:chunks:delete_chunk_widget',
                        args=[
                            self.request_kwargs['chunk_id'],
                            self.request_kwargs['widget_id'],
                        ]
                    )
                )
            )
        return buttons

    def get_view_breadcrumbs(self):
        chunk = get_object_or_404(
            Chunk,
            id=self.request_kwargs['chunk_id']
        )
        return (
            (
                'Chunks',
                reverse_lazy('admin:chunks:list_chunks')
            ),
            (
                chunk.label,
                reverse_lazy(
                    'admin:chunks:edit_chunk',
                    args=[
                        self.request_kwargs['chunk_id']
                    ]
                )
            ),
            (
                "Widgets",
                reverse_lazy(
                    'admin:chunks:list_chunk_widgets',
                    args=[
                        self.request_kwargs['chunk_id']
                    ]
                )
            ),
            (
                self.get_view_title(),
                reverse_lazy(
                    (
                        'admin:chunks:edit_chunk_widget'
                        if self.is_editing()
                        else 'admin:chunks:create_chunk_widget'
                    ),
                    args=[
                        self.request_kwargs['chunk_id'],
                        self.request_kwargs[
                            'widget_id'
                            if self.is_editing()
                            else 'widget_type'
                        ]
                    ]
                )
            )
        )

    def validate_form(self, form_name, form):
        valid = super().validate_form(form_name, form)
        if (
            valid
            and form_name == 'basic_details'
            and self.get_widget_type_name() == 'chunk'
        ):
            # Ensure there can't be an infinite loop were one chunk
            # contains one that contains it
            parent_chunk = Chunk.objects.get(
                id=self.request_kwargs['chunk_id']
            )
            chunk = Chunk.objects.get(
                chunk_name=form.cleaned_data['chunk_name'],
                global_chunk=True
            )
            if chunk.id == parent_chunk.id:
                form.add_error(
                    'chunk_name',
                    'Cannot insert a chunk into itself.'
                )
                return False

            def detect_chunk_loop(chunk, parent_chunks=None):
                parent_chunks = parent_chunks or []
                for widget in chunk.widgets.all():
                    if widget.widget_type == 'chunk':
                        chunk_name = widget.data['basic_details']['chunk_name']
                        if chunk_name in parent_chunks:
                            return True
                        else:
                            return detect_chunk_loop(
                                Chunk.objects.get(
                                    chunk_name=chunk_name,
                                    global_chunk=True
                                ),
                                [chunk_name] + parent_chunks
                            )
                return False

            if detect_chunk_loop(chunk, [parent_chunk.chunk_name]):
                form.add_error(
                    'chunk_name',
                    'The chunk you have chosen contains this chunk, ' +
                    'inserting this chunk would create an infinite loop.'
                )
                return False
        return valid

    def get_form_kwargs(self, form_name):
        kwargs = super().get_form_kwargs(form_name)
        if form_name == 'order' and not self.is_editing():
            max_order = self.get_chunk_model().widgets.aggregate(
                Max('order')
            )['order__max']
            kwargs['initial'] = {
                'order': int(max_order) + 1 if max_order is not None else 0
            }
        return kwargs

    def forms_valid(self, request, forms, *args, **kwargs):
        chunk = get_object_or_404(
            Chunk,
            id=self.request_kwargs['chunk_id']
        )
        widget, created = self.update_widget(request, forms)
        if created:
            chunk.widgets.add(widget)
        return redirect(
            reverse(
                'admin:chunks:list_chunk_widgets',
                args=[
                    chunk.id
                ]
            )
        )


class DeleteChunkWidgetView(AdminDeleteView):
    """Delete view for deleting Widget models"""
    view_menu_selector = 'chunks.list_chunks'
    model = Widget
    model_id_param = 'widget_id'
    view_permissions = [
        'onyx_cms.delete_widget'
    ]
