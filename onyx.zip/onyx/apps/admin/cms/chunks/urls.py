"""URL patterns for chunks admin app"""

from django.urls import path

from onyx.apps.admin.cms.chunks import views


app_name = 'chunks'
urlpatterns = [
    path(
        'chunks/',
        views.ChunkTableView.as_view(),
        name='list_chunks'
    ),
    path(
        'chunks/create/',
        views.EditChunkView.as_view(),
        name='create_chunk'
    ),
    path(
        'chunks/<int:chunk_id>/',
        views.EditChunkView.as_view(),
        name='edit_chunk'
    ),
    path(
        'chunks/<int:chunk_id>/delete/',
        views.DeleteChunkView.as_view(),
        name='delete_chunk'
    ),
    path(
        'chunks/<int:chunk_id>/widgets/',
        views.ChunkWidgetsTableView.as_view(),
        name='list_chunk_widgets'
    ),
    path(
        'chunks/<int:chunk_id>/widgets/create/',
        views.SelectChunkWidgetTypeView.as_view(),
        name='select_chunk_widget_type'
    ),
    path(
        'chunks/<int:chunk_id>/widgets/create/<str:widget_type>/',
        views.EditChunkWidgetView.as_view(),
        name='create_chunk_widget'
    ),
    path(
        'chunks/<int:chunk_id>/widgets/<int:widget_id>/',
        views.EditChunkWidgetView.as_view(),
        name='edit_chunk_widget'
    ),
    path(
        'chunks/<int:chunk_id>/widgets/<int:widget_id>/delete/',
        views.DeleteChunkWidgetView.as_view(),
        name='delete_chunk_widget'
    )
]
