"""App config classes for chunks admin app"""

from onyx.apps.admin.config import AbstractAdminAppConfig


class AdminCMSChunksConfig(AbstractAdminAppConfig):
    """Default app config for chunks admin app"""

    name = "onyx.apps.admin.cms.chunks"
    """The python path to the app"""

    verbose_name = "Onyx - Admin - CMS - Chunks"
    """The human readable name of the app"""

    label = "onyx_admin_cms_chunks"
    """The internal Django name of the app"""
