"""URL patterns for cms forms admin app"""

from django.urls import path

from onyx.apps.admin.cms.cms_forms import views


app_name = 'cms_forms'
urlpatterns = [
    path('', views.FormTableView.as_view(), name='list_forms'),
    path('select-type/', views.SelectFormTypeView.as_view(),
         name='select_form_type'),
    path('select-type/<str:form_handler>/',
         views.EditFormView.as_view(), name='create_form'),
    path('<int:id>/', views.EditFormView.as_view(), name='edit_form'),
    path('<int:id>/delete/', views.DeleteFormView.as_view(), name='delete_form'),
    path('<int:id>/fields/', views.FieldTableView.as_view(), name='list_fields'),
    path('<int:id>/fields/select-type/',
         views.SelectFieldTypeView.as_view(), name='select_field_type'),
    path('<int:id>/fields/select-type/<str:field_type>/',
         views.EditFieldView.as_view(), name='create_field'),
    path('<int:id>/fields/<int:field_id>/',
         views.EditFieldView.as_view(), name='edit_field'),
    path('<int:id>/fields/<int:field_id>/delete/',
         views.DeleteFieldView.as_view(), name='delete_field'),
    path('<int:id>/responses/', views.ResponseTableView.as_view(),
         name='list_responses'),
    path('<int:id>/responses/<int:response_id>/',
         views.FormResponseView.as_view(), name='view_response')
]
