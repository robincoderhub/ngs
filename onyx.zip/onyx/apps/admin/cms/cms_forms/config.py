"""App config classes for cms forms admin app"""

from onyx.apps.admin.config import AbstractAdminAppConfig


class AdminCMSFormsConfig(AbstractAdminAppConfig):
    """Default app config for forms admin app"""

    name = "onyx.apps.admin.cms.cms_forms"
    """The python path to the app"""

    verbose_name = "Onyx - Admin - CMS - Forms"
    """The human readable name of the app"""

    label = "onyx_admin_cms_forms"
    """The internal Django name of the app"""
