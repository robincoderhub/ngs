"""Admin menu items for cms forms admin app"""

from django.urls import reverse_lazy

from onyx.apps.cms.menus.items import MenuItem


menu_nodes = [
    MenuItem('Forms', node_weight=230, node_children=[
        MenuItem(
            'Create Form',
            data={
                'url': reverse_lazy('admin:cms_forms:select_form_type')
            }
        ),
        MenuItem(
            'List Forms',
            data={
                'url': reverse_lazy('admin:cms_forms:list_forms')
            }
        )
    ])
]
