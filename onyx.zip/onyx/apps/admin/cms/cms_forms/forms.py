"""Forms related to cms forms app"""

from django import forms

from onyx.apps.cms.cms_forms.models import CMSForm, CMSFormField
from onyx.apps.cms.cms_forms.register import get_field_types, get_form_handlers


FORM_HANDLER_CHOICES = sorted([
    (key, handler.get_label())
    for key, handler in get_form_handlers().items()
], key=lambda x: x[1])
"""A choice list of the form handlers registered in the global register"""


FIELD_TYPE_CHOICES = sorted([
    (key, field_type.get_label())
    for key, field_type in get_field_types().items()
], key=lambda x: x[1])
"""A choice list of the field type registered in the global register."""


class SelectFormTypeForm(forms.Form):
    """A form for selecting what type of form to create"""

    form_handler = forms.ChoiceField(
        label='Form type',
        choices=FORM_HANDLER_CHOICES
    )
    """Choice field for what form handler to use"""


class CMSFormForm(forms.ModelForm):
    """A model form for editing a CMSForm model

    Args:
        *args: Inherited arguments
        **kwargs: Inherited keyword arguments."""

    class Meta:
        model = CMSForm
        exclude = [
            'handler_data'
        ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['form_handler'].disabled = True


class SelectFieldTypeForm(forms.Form):
    """A form for selecting what field type to create"""

    field_type = forms.ChoiceField(
        label='Field type',
        choices=FIELD_TYPE_CHOICES
    )
    """A choice field for selecting a field type."""


class CMSFormFieldForm(forms.ModelForm):
    """Model form for creating/editing a CMSFormField

    Args:
        *args: Inherited arguments
        **kwargs: Inherited keyword arguments"""

    class Meta:
        model = CMSFormField
        exclude = [
            'type_data'
        ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['form'].widget = forms.HiddenInput()
        self.fields['form'].disabled = True
        self.fields['field_type'].disabled = True
        self.fields['display_in_table'].label = 'Response table column'
