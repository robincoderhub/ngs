"""Views related to CMS forms admin app"""

from django.urls import reverse_lazy, reverse
from django.http import Http404
from django.shortcuts import get_object_or_404, redirect
from django.contrib import messages
from django.db.models import Max

from django_tables2 import LinkColumn
from django_tables2.utils import A

from onyx.utils import to_json_safe_object
from onyx.utils.django_tables.columns import JSONAttributeColumn
from onyx.apps.admin.views.generic import (
    AdminView,
    AdminTableView,
    AdminFormView,
    AdminDeleteView
)
from onyx.apps.cms.cms_forms.models import (
    CMSForm,
    CMSFormField,
    CMSFormResponse
)
from onyx.apps.admin.cms.cms_forms.forms import (
    SelectFormTypeForm,
    CMSFormForm,
    SelectFieldTypeForm,
    CMSFormFieldForm
)
from onyx.apps.cms.cms_forms.register import get_form_handler
from onyx.apps.cms.cms_forms.register import get_field_type


class FormTableView(AdminTableView):
    """Table view for listing current form models."""
    view_title = 'List Forms'
    model = CMSForm
    create_button_url = reverse_lazy('admin:cms_forms:select_form_type')
    create_button_permissions = 'onyx_cms_forms.add_cmsform'
    view_permissions = (
        'onyx_cms_forms.view_cmsform',
    )
    table_columns = [
        'id',
        'label',
        'name',
        'form_handler'
    ]
    extra_columns = [
        (
            ' ',
            LinkColumn(
                'admin:cms_forms:edit_form',
                text='Edit',
                args=[A('pk')]
            )
        )
    ]
    view_breadcrumbs = (
        ('Forms', reverse_lazy('admin:cms_forms:list_forms')),
    )


class SelectFormTypeView(AdminFormView):
    """Form view for selecting what type of form to create (based on
    form handlers)"""

    view_menu_selector = 'forms.create_form'
    view_title = 'Select form type'
    view_permissions = (
        'onyx_cms_forms.add_cmsform'
    )
    form_classes = {
        'basic_details': SelectFormTypeForm
    }
    success_message = None
    view_breadcrumbs = (
        (
            'Forms',
            reverse_lazy('admin:cms_forms:list_forms')
        ),
        (
            'Select form type',
            reverse_lazy('admin:cms_forms:select_form_type')
        ),
    )
    submit_label = 'Select'

    def get_success_redirect(self, request, form_dict, form_results):
        return reverse(
            'admin:cms_forms:create_form',
            kwargs={
                'form_handler': form_dict['basic_details'].cleaned_data[
                    'form_handler'
                ]
            }
        )


class EditFormView(AdminFormView):
    """View for editing and create CMSForm models"""

    tab_definitions = [
        ('Basic details', [
            'basic_details',
            'options'
        ])
    ]

    def get_view_menu_selector(self):
        if 'id' in self.request_kwargs:
            return 'forms.list_forms'
        return 'forms.create_form'

    def get_view_breadcrumbs(self):
        if 'id' in self.request_kwargs:
            form = CMSForm.objects.get(id=self.request_kwargs['id'])
            return (
                (
                    'Forms',
                    reverse_lazy('admin:cms_forms:list_forms')
                ),
                (
                    str(form),
                    reverse_lazy(
                        'admin:cms_forms:edit_form',
                        args=[
                            self.request_kwargs['id']
                        ]
                    )
                ),
            )
        return (
            (
                'Forms',
                reverse_lazy('admin:cms_forms:list_forms')
            ),
            (
                'Select Form Type',
                reverse_lazy('admin:cms_forms:select_form_type')
            ),
            (
                'Create Form',
                reverse_lazy(
                    'admin:cms_forms:create_form',
                    args=[
                        self.request_kwargs['form_handler']
                    ]
                )
            ),
        )

    def get_extra_buttons(self):
        if 'id' in self.request_kwargs:
            form = CMSForm.objects.get(id=self.request_kwargs['id'])
            buttons = [
                (
                    'Delete Form',
                    reverse(
                        'admin:cms_forms:delete_form',
                        args=[form.id]
                    )
                ),
                (
                    'Edit fields',
                    reverse(
                        'admin:cms_forms:list_fields',
                        args=[form.id]
                    )
                )
            ]
            if form.save_responses or form.responses.count() > 0:
                buttons.append(
                    (
                        'View Responses',
                        reverse(
                            'admin:cms_forms:list_responses',
                            args=[form.id]
                        )
                    ),
                )
            return buttons
        return None

    def get_view_title(self):
        if 'id' in self.request_kwargs:
            return 'Edit Form'
        return 'Create Form'

    def get_view_permissions(self):
        if 'id' in self.request_kwargs:
            return ('onyx_cms_forms.edit_cmsform',)
        else:
            return ('onyx_cms_forms.add_cmsform',)

    def get_model_instance(self):
        if 'id' in self.request_kwargs:
            return get_object_or_404(
                CMSForm,
                id=self.request_kwargs['id']
            )
        return CMSForm()

    def get_form_classes(self):
        model = self.get_model_instance()
        if model.id:
            form_handler = get_form_handler(model.form_handler)
        elif 'form_handler' in self.request_kwargs:
            form_handler = get_form_handler(
                self.request_kwargs['form_handler']
            )
        else:
            raise Http404()
        return {
            'basic_details': CMSFormForm,
            'options': form_handler.get_handler_form_class()
        }

    def get_form_kwargs(self, form_name):
        model = self.get_model_instance()
        if form_name == 'basic_details':
            return {
                'initial': {
                    'form_handler': (
                        model.form_handler
                        if model.id
                        else self.request_kwargs.get('form_handler')
                    )
                },
                'instance': model
            }
        elif model.id:
            return {
                'initial': model.handler_data
            }
        return super().get_form_kwargs(form_name)

    def forms_valid(self, request, forms, *args, **kwargs):
        forms['basic_details'].instance.handler_data = to_json_safe_object(
            forms['options'].cleaned_data
        )
        vform = forms['basic_details'].save()
        messages.success(request, "Form saved!")
        if 'id' in self.request_kwargs:
            return redirect(
                reverse('admin:cms_forms:edit_form', args=[vform.id])
            )
        else:
            return redirect(
                reverse('admin:cms_forms:list_fields', args=[vform.id])
            )


class DeleteFormView(AdminDeleteView):
    """View for the deletion of CMSForm objects"""
    model = CMSForm


class FieldTableView(AdminTableView):
    """View for listing the CMSFormField models attached to a form"""
    view_title = 'Form Fields'
    view_menu_selector = 'forms.list_forms'
    model = CMSFormField
    create_button_permissions = 'onyx_cms_forms.add_cmsform'
    view_permissions = (
        'onyx_cms_forms.view_cmsform',
    )
    table_columns = [
        'order',
        'label',
        'name',
        'field_type'
    ]
    extra_columns = [
        (
            ' ',
            LinkColumn(
                'admin:cms_forms:edit_field',
                text='Edit',
                args=[A('form_id'), A('pk')]
            )
        )
    ]

    def get_view_breadcrumbs(self):
        form = get_object_or_404(CMSForm, id=self.request_kwargs['id'])
        return (
            (
                'Forms',
                reverse_lazy('admin:cms_forms:list_forms')
            ),
            (
                str(form),
                reverse_lazy('admin:cms_forms:edit_form', args=[form.id])
            ),
            (
                'Fields',
                reverse_lazy('admin:cms_forms:list_fields', args=[form.id])
            ),
        )

    def get_create_button_url(self):
        return reverse(
            'admin:cms_forms:select_field_type',
            args=[self.request_kwargs['id']]
        )

    def get_queryset(self):
        qs = super().get_queryset()
        qs = qs.filter(form_id=self.request_kwargs['id']).order_by('order')
        return qs


class SelectFieldTypeView(AdminFormView):
    """Form view for selecting what type of form field to create, based on
    form field types registered with the global register."""
    view_menu_selector = 'forms.list_forms'
    view_title = 'Select field type'
    view_permissions = (
        'onyx_cms_forms.add_cmsformfield'
    )
    form_classes = {
        'basic_details': SelectFieldTypeForm
    }
    success_message = None
    submit_label = 'Select'

    def get_view_breadcrumbs(self):
        form = get_object_or_404(CMSForm, id=self.request_kwargs['id'])
        return (
            (
                'Forms',
                reverse_lazy('admin:cms_forms:list_forms')
            ),
            (
                str(form),
                reverse_lazy(
                    'admin:cms_forms:edit_form',
                    args=[form.id]
                )
            ),
            (
                'Fields',
                reverse_lazy(
                    'admin:cms_forms:list_fields',
                    args=[form.id]
                )
            ),
            (
                'Select Field Type',
                reverse_lazy(
                    'admin:cms_forms:select_field_type',
                    args=[form.id]
                )
            ),
        )

    def get_success_redirect(self, request, form_dict, form_results):
        return reverse(
            'admin:cms_forms:create_field',
            kwargs={
                'id': self.request_kwargs['id'],
                'field_type': form_dict['basic_details'].cleaned_data[
                    'field_type'
                ]
            }
        )


class EditFieldView(AdminFormView):
    """Form view for editing/creating CMSFormField models"""
    view_menu_selector = 'forms.list_forms'
    field_model = None

    def get_extra_buttons(self):
        if 'field_id' in self.request_kwargs:
            form_id = self.request_kwargs['id']
            field_id = self.request_kwargs['field_id']
            return (
                (
                    'Delete Field',
                    reverse_lazy(
                        'admin:cms_forms:delete_field',
                        args=[form_id, field_id]
                    )
                ),
            )

    def get_view_breadcrumbs(self):
        form = CMSForm.objects.get(
            id=self.request_kwargs['id']
        )
        if 'field_id' in self.request_kwargs:
            field = CMSFormField.objects.get(
                id=self.request_kwargs['field_id']
            )
            return (
                (
                    'Forms',
                    reverse_lazy('admin:cms_forms:list_forms')
                ),
                (
                    str(form),
                    reverse_lazy(
                        'admin:cms_forms:edit_form',
                        args=[form.id]
                    )
                ),
                (
                    'Fields',
                    reverse_lazy(
                        'admin:cms_forms:list_fields',
                        args=[form.id]
                    )
                ),
                (
                    str(field),
                    reverse_lazy(
                        'admin:cms_forms:edit_field',
                        args=[
                            form.id,
                            self.request_kwargs['field_id']
                        ]
                    )
                ),
            )
        return (
            (
                'Forms',
                reverse_lazy('admin:cms_forms:list_forms')
            ),
            (
                str(form),
                reverse_lazy(
                    'admin:cms_forms:edit_form',
                    args=[form.id]
                )
            ),
            (
                'Fields',
                reverse_lazy(
                    'admin:cms_forms:list_fields',
                    args=[form.id]
                )
            ),
            (
                'Select Field Type',
                reverse_lazy(
                    'admin:cms_forms:select_field_type',
                    args=[form.id]
                )
            ),
            (
                'Create Field',
                reverse_lazy(
                    'admin:cms_forms:create_field',
                    args=[
                        form.id,
                        self.request_kwargs['field_type']
                    ]
                )
            ),
        )

    def get_view_title(self):
        if 'id' in self.request_kwargs:
            return 'Edit Field'
        return 'Create Field'

    def get_view_permissions(self):
        if 'id' in self.request_kwargs:
            return ('onyx_cms_forms.edit_cmsformfield',)
        else:
            return ('onyx_cms_forms.add_cmsformfield',)

    def get_model_instance(self):
        if not self.field_model:
            if 'field_id' in self.request_kwargs:
                self.field_model = get_object_or_404(
                    CMSFormField,
                    id=self.request_kwargs['field_id']
                )
            else:
                self.field_model = CMSFormField()
        return self.field_model

    def get_form_classes(self):
        model = self.get_model_instance()
        if model.id:
            field_type = get_field_type(model.field_type)
        elif 'field_type' in self.request_kwargs:
            field_type = get_field_type(self.request_kwargs['field_type'])
        else:
            raise Http404()
        forms = {
            'basic_details': CMSFormFieldForm
        }
        if field_type.get_type_form_class():
            forms['options'] = field_type.get_type_form_class()
        return forms

    def get_form_kwargs(self, form_name):
        model = self.get_model_instance()
        if form_name == 'basic_details':
            if model.id:
                order = model.order
            else:
                form = get_object_or_404(CMSForm, id=self.request_kwargs['id'])
                order = form.fields.aggregate(
                    Max('order')
                )['order__max']
                # Auto increment order based on highest order
                order = order + 1 if order is not None else 0
            return {
                'initial': {
                    'form': self.request_kwargs['id'],
                    'field_type': (
                        model.field_type
                        if model.id
                        else self.request_kwargs.get('field_type')
                    ),
                    'order': order
                },
                'instance': model
            }
        elif model.id:
            return {
                'initial': model.type_data
            }
        return super().get_form_kwargs(form_name)

    def forms_valid(self, request, forms, *args, **kwargs):
        if 'options' in forms:
            forms['basic_details'].instance.type_data = to_json_safe_object(
                forms['options'].cleaned_data
            )
        else:
            forms['basic_details'].instance.type_data = {}
        vfield = forms['basic_details'].save()
        messages.success(request, "Field saved!")
        return redirect(
            reverse('admin:cms_forms:list_fields', args=[vfield.form.id])
        )


class DeleteFieldView(AdminDeleteView):
    """View for deleting CMSFormField models"""
    model = CMSFormField

    def get_model_id(self):
        return self.request_kwargs.get('field_id')


class ResponseTableView(AdminTableView):
    """View for displaying the CMSFormResponse objects for a particular
    form."""
    view_title = 'View responses'
    view_menu_selector = 'forms.list_forms'
    model = CMSFormResponse
    table_columns = [
        'id',
        'created',
    ]

    form_instance = None
    """Instance of form who owns the responses"""

    def get_form_instance(self):
        """Get the CMSForm model instance of the form who
        owns these responses.

        Raises:
            Http404: Thrown if form cannot be determined.

        Returns:
            A CMSForm instance."""
        if self.form_instance:
            return self.form_instance
        self.form_instance = get_object_or_404(
            CMSForm,
            id=self.request_kwargs['id']
        )
        return self.form_instance

    def get_search_fields(self):
        form = self.get_form_instance()
        fields = []
        for field in form.fields.filter(display_in_table=True).order_by(
            'order'
        ):
            fields.append(
                f"response_data__{field.name}__icontains"
            )
        if not fields:
            return super().get_search_fields()
        return fields

    def get_extra_columns(self):
        form = self.get_form_instance()
        columns = []
        for field in form.fields.filter(display_in_table=True).order_by(
            'order'
        ):
            columns.append(
                (
                    field.label,
                    JSONAttributeColumn(
                        field.name,
                        accessor='response_data',
                        verbose_name=field.label
                    )
                )
            )
        columns.append(
            (
                ' ',
                LinkColumn(
                    'admin:cms_forms:view_response',
                    text='View',
                    args=[A('form_id'), A('pk')]
                )
            )
        )
        return columns

    def get_view_breadcrumbs(self):
        form = self.get_form_instance()
        return (
            (
                'Forms',
                reverse_lazy('admin:cms_forms:list_forms')
            ),
            (
                str(form),
                reverse_lazy(
                    'admin:cms_forms:edit_form', args=[form.id]
                )
            ),
            (
                'View Responses',
                reverse_lazy(
                    'admin:cms_forms:list_responses',
                    args=[form.id]
                )
            ),
        )

    def get_queryset(self):
        qs = super().get_queryset()
        return qs.filter(form=self.request_kwargs['id'])


class FormResponseView(AdminView):
    """View for 'viewing' a response object and its details"""
    view_title = 'View Response'
    view_menu_selector = 'forms.list_forms'
    template_name = 'onyx/apps/admin/cms/cms_forms/view_response.html'

    def get_view_breadcrumbs(self):
        form = get_object_or_404(
            CMSForm,
            id=self.request_kwargs['id']
        )
        response_id = self.request_kwargs['response_id']
        return (
            (
                'Forms',
                reverse_lazy('admin:cms_forms:list_forms')
            ),
            (
                str(form),
                reverse_lazy(
                    'admin:cms_forms:edit_form',
                    args=[form.id]
                )
            ),
            (
                'View Responses',
                reverse_lazy(
                    'admin:cms_forms:list_responses',
                    args=[form.id]
                )
            ),
            (
                f'Response {response_id}',
                reverse_lazy(
                    'admin:cms_forms:view_response',
                    args=[form.id, response_id]
                )
            ),
        )

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        form_model = get_object_or_404(
            CMSForm,
            id=self.request_kwargs['id']
        )
        response = get_object_or_404(
            CMSFormResponse,
            id=self.request_kwargs['response_id']
        )
        context.update({
            'form_model': form_model,
            'form_data': response.response_data,
            'response': response
        })
        return context
