"""
# CMS forms admin app

This app provides an admin section for creating and managing CMS forms.

## Requirements
- onyx
- onyx.apps.admin
- onyx.apps.admin.cms
- onyx.apps.cms
- onyx.apps.cms.cms_forms

## Installation

To install this app just add it to your INSTALLED_APPS config
```
INSTALLED_APPS = [
    ...
    'onyx.apps.admin.cms.cms_forms',
]
```
"""

default_app_config = 'onyx.apps.admin.cms.cms_forms.config.AdminCMSFormsConfig'
