"""
# CMS admin app

This app provides shared config between all CMS admin apps but does not provide an admin section itself.

## Requirements
- onyx
- onyx.apps.admin

## Installation

To install this app just add it to your INSTALLED_APPS config
```
INSTALLED_APPS = [
    ...
    'onyx.apps.admin.cms',
]
```
"""

default_app_config = 'onyx.apps.admin.cms.config.AdminCMSConfig'
