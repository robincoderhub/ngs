"""Admin menu items for the redirect admin app"""
from django.urls import reverse_lazy

from onyx.apps.cms.menus.items import MenuItem


menu_nodes = [
    MenuItem(
        'Redirects',
        node_weight=230,
        node_children=[
            MenuItem(
                'Create Redirect',
                data={
                    'url': reverse_lazy('admin:redirects:create_redirect')
                }
            ),
            MenuItem(
                'List Redirects',
                data={
                    'url': reverse_lazy('admin:redirects:list_redirects')
                }
            )
        ]
    )
]
