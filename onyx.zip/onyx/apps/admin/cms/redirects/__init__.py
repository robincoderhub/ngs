"""
# CMS redirects admin app

This app provides an admin section for creating and managing CMS redirects

## Requirements
- onyx
- onyx.apps.admin
- onyx.apps.admin.cms
- onyx.apps.cms
- onyx.apps.cms.redirects

## Installation

To install this app just add it to your INSTALLED_APPS config
```
INSTALLED_APPS = [
    ...
    'onyx.apps.admin.cms.redirects',
]
```
"""

default_app_config = 'onyx.apps.admin.cms.redirects.config.AdminCMSRedirectsConfig'
