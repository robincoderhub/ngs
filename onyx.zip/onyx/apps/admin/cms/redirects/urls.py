"""Admin url patterns for the redirect admin app"""
from django.urls import path

from onyx.apps.admin.cms.redirects import views


app_name = 'redirects'
urlpatterns = [
    path(
        'redirects/',
        views.RedirectTableView.as_view(),
        name='list_redirects'
    ),
    path(
        'redirects/create/',
        views.EditRedirectView.as_view(),
        name='create_redirect'
    ),
    path(
        'redirects/<int:redirect_id>/',
        views.EditRedirectView.as_view(),
        name='edit_redirect'
    )
]
