"""Forms related to the redirects admin app"""

from django import forms

from onyx.apps.cms.redirects.models import Redirect


class EditRedirectForm(forms.ModelForm):
    """Model form for editing redirects"""

    class Meta:
        model = Redirect
        fields = ['from_path', 'to_path', 'permanent']
