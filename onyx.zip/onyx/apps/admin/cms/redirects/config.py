"""App config classes for CMS admin redirects app"""

from onyx.apps.admin.config import AbstractAdminAppConfig


class AdminCMSRedirectsConfig(AbstractAdminAppConfig):
    """Default admin app config for redirects admin app"""

    name = "onyx.apps.admin.cms.redirects"
    """The python path to the app"""

    verbose_name = "Onyx - Admin - CMS - Redirects"
    """The human readable name of the app"""

    label = "onyx_admin_cms_redirects"
    """The internal Django name of the app"""
