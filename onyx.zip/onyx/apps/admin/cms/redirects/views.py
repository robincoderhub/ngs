"""View related to the redirect admin app"""

from django.shortcuts import get_object_or_404

from django.urls import reverse_lazy

from django_tables2 import LinkColumn
from django_tables2.utils import A

from onyx.apps.cms.redirects.models import Redirect
from onyx.apps.admin.views.generic import AdminTableView, AdminFormView
from onyx.apps.admin.cms.redirects.forms import EditRedirectForm


class RedirectTableView(AdminTableView):
    """View for displaying redirect models"""

    view_menu_selector = 'redirects.list_redirects'
    view_title = 'List Redirects'
    create_button_url = reverse_lazy('admin:redirects:create_redirect')
    create_button_permissions = 'onyx_cms.add_sitenode'
    view_permissions = (
        'onyx_cms.view_sitenode',
    )
    view_breadcrumbs = (
        ('Redirects', reverse_lazy('admin:redirects:list_redirects')),
    )
    model = Redirect
    table_columns = [
        'from_path',
        'to_path',
        'permanent'
    ]
    extra_columns = [
        (
            ' ',
            LinkColumn(
                'admin:redirects:edit_redirect',
                text='Edit',
                args=[A('pk')]
            )
        )
    ]


class EditRedirectView(AdminFormView):
    """A view for editing redirect models"""

    view_permissions = (
        'onyx_cms.edit_sitenode',
    )
    form_classes = {
        'basic_details': EditRedirectForm
    }
    redirect_model = None
    success_redirect = 'admin:redirects:list_redirects'

    def get_view_menu_selector(self):
        return (
            'redirects.list_redirects'
            if self.is_editing()
            else 'redirects.create_redirect'
        )

    def get_view_title(self):
        """Get view title, changes depending on editing
        or creating a redirect.

        Returns:
            The view title string"""
        return (
            'Edit Redirect'
            if self.is_editing()
            else 'Create Redirect'
        )

    def get_view_breadcrumbs(self):
        """Get breadcrumbs for view, changes depending on whether
        editing or creating

        Returns:
            A list of tuples in format (label, url)"""
        crumbs = [
            (
                'Redirects',
                reverse_lazy('admin:redirects:list_redirects')
            )
        ]
        if self.is_editing():
            crumbs.append(
                (
                    'Edit Redirect',
                    reverse_lazy(
                        'admin:redirects:edit_redirect',
                        args=[
                            self.request_kwargs['redirect_id']
                        ]
                    )
                )
            )
        else:
            crumbs.append(
                (
                    'Create Redirect',
                    reverse_lazy('admin:redirects:create_redirect')
                )
            )
        return crumbs

    def is_editing(self):
        """Whether or not this is editing or creating
        a redirect.

        Returns:
            True if editing, False if creating."""
        return 'redirect_id' in self.request_kwargs

    def get_redirect_instance(self):
        """Get instance of redirect model being
        edited/created.

        Returns:
            The Redirect model instance."""
        if not self.redirect_model:
            if self.is_editing():
                self.redirect_model = get_object_or_404(
                    Redirect,
                    id=self.request_kwargs['redirect_id']
                )
            else:
                self.redirect_model = Redirect()
        return self.redirect_model

    def get_form_kwargs(self, form_name):
        """Get form keyword arguments, passes redirect
        instance to form.

        Args:
            form_name: The form alias of the form being
                passed kwargs.

        Returns:
            A dict of keyword arguments."""
        if form_name == 'basic_details':
            return {
                'instance': self.get_redirect_instance()
            }
        return {}
