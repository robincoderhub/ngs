"""
# CMS pages admin app

This app provides an admin section for creating and managing CMS pages.

## Requirements
- onyx
- onyx.apps.admin
- onyx.apps.admin.cms
- onyx.apps.cms

## Installation

To install this app just add it to your INSTALLED_APPS config
```
INSTALLED_APPS = [
    ...
    'onyx.apps.admin.cms.pages',
]
```
"""

default_app_config = 'onyx.apps.admin.cms.pages.config.AdminCMSPagesConfig'
