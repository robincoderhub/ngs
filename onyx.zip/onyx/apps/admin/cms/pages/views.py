"""Views related to pages admin app"""

from copy import deepcopy

from django.shortcuts import redirect, get_object_or_404
from django.urls import reverse_lazy, reverse
from django.http import Http404, HttpResponse
from django.db.models import Max
from django.views.generic import View

from django_tables2 import LinkColumn, Column
from django_tables2.utils import A

from onyx.utils import to_json_safe_object
from onyx.apps.admin.views.generic import (
    AdminTableView,
    AdminFormView,
    AdminDeleteView
)
from onyx.apps.cms.models import Page, Chunk, Widget, SiteNode
from onyx.apps.cms.register import get_template_type
from onyx.apps.admin.cms.chunks.forms import (
    SelectChunkWidgetForm
)
from onyx.apps.admin.cms.chunks.columns import WidgetDataColumn
from onyx.apps.admin.cms.chunks.views import BaseEditWidgetView
from onyx.apps.admin.cms.pages.forms import (
    SelectTemplateForm,
    PageNodeForm
)


class PageTableView(AdminTableView):
    """View for listing CMS pages"""

    view_title = 'List Pages'
    model = Page
    create_button_url = reverse_lazy('admin:pages:select_template')
    create_button_permissions = 'onyx_cms.add_page'
    view_permissions = (
        'onyx_cms.view_page',
    )
    view_breadcrumbs = (
        ('Pages', reverse_lazy('admin:pages:list_pages')),
    )
    table_columns = []
    extra_columns = [
        (
            'URL',
            Column(accessor='node.path')
        ),
        (
            'Title',
            Column(accessor='data.view_title', verbose_name='Title')
        ),
        (
            'Description',
            Column(
                accessor='data.view_description',
                verbose_name='Description'
            )
        ),
        (
            'Published',
            Column(accessor='node.published')
        ),
        (
            ' ',
            LinkColumn(
                'admin:pages:edit_page',
                text='Edit',
                args=[A('node.id')]
            )
        ),
    ]
    ordering = '-URL'

    def get_queryset(self):
        qs = super().get_queryset()
        return qs.order_by('-node.path')


class SelectTemplateTypeView(AdminFormView):
    """View for selecting a template type for a CMS page"""

    view_menu_selector = 'pages.create_page'
    view_title = 'Select template'
    view_permissions = (
        'onyx_cms.add_page',
    )
    form_classes = {
        'basic_details': SelectTemplateForm
    }
    success_message = None
    view_breadcrumbs = (
        ('Pages', reverse_lazy('admin:pages:list_pages')),
        ('Select template', reverse_lazy('admin:pages:select_template')),
    )
    submit_label = 'Select'

    def forms_valid(self, request, forms, *args, **kwargs):
        return redirect(
            reverse(
                'admin:pages:create_page',
                kwargs={
                    'template_type': forms['basic_details'].cleaned_data[
                        'template'
                    ]
                }
            )
        )


class EditPageView(AdminFormView):
    """View for creating and editing CMS pages"""

    view_permissions = (
        'onyx_cms.edit_page',
    )
    tab_definitions = [
        ('Basic Details', [
            'basic_details',
            'navigation'
        ]),
    ]

    page_model = None
    """The page model being edited"""

    node_model = None
    """The page's SiteNode being edited."""

    def get_view_menu_selector(self):
        if self.is_editing():
            return 'pages.list_pages'
        return 'pages.create_page'

    def get_view_breadcrumbs(self):
        breadcrumbs = [
            (
                'Pages',
                reverse_lazy('admin:pages:list_pages')
            )
        ]
        if self.is_editing():
            breadcrumbs.append(
                (
                    self.get_view_title(),
                    reverse_lazy(
                        'admin:pages:edit_page',
                        args=[self.request_kwargs['page_id']]
                    )
                )
            )
        else:
            breadcrumbs.append(
                (
                    'Select template',
                    reverse_lazy('admin:pages:select_template')
                ),
            )
            breadcrumbs.append(
                (
                    self.get_view_title(),
                    reverse_lazy(
                        'admin:pages:create_page',
                        args=[self.request_kwargs['template_type']]
                    )
                )
            )
        return breadcrumbs

    def get_view_title(self):
        if self.is_editing():
            page_name = self.get_page_instance().data.get(
                'view_title',
                'Untitled'
            )
            return f"Edit Page: {page_name}"
        return 'Create Page'

    def get_extra_buttons(self):
        if not self.is_editing():
            return []
        return [
            (
                'Edit Contents',
                reverse_lazy('admin:pages:list_page_chunks', args=[
                    self.get_page_instance().node.id
                ])
            ),
            (
                'Preview',
                reverse_lazy('admin:pages:preview_page', args=[
                    self.get_page_instance().node.id
                ])
            ),
            (
                'Delete',
                reverse_lazy('admin:pages:delete_page', args=[
                    self.get_page_instance().node.id
                ])
            )
        ]

    def is_editing(self):
        return 'page_id' in self.request_kwargs

    def get_template_type_name(self):
        return (
            self.get_page_instance().template_type
            if self.is_editing()
            else self.request_kwargs['template_type']
        )

    def get_template_type(self):
        return get_template_type(self.get_template_type_name())

    def get_node_instance(self):
        """Get the SiteNode instance being edited/created.

        Raises:
            Http404: Thrown if page model cannot be found.

        Returns:
            The SiteNode model being edited."""
        if not self.node_model:
            if self.is_editing():
                self.node_model = self.get_page_instance().node
            else:
                self.node_model = SiteNode()
        return self.node_model

    def get_page_instance(self):
        """Get the Page model instance being edited/created.

        Raises:
            Http404: Thrown if page model cannot be found.

        Returns:
            The Page model being edited."""
        if not self.page_model:
            if self.is_editing():
                self.page_model = get_object_or_404(
                    Page,
                    node=self.request_kwargs['page_id']
                )
            else:
                self.page_model = Page()
        return self.page_model

    def get_form_classes(self):
        return {
            'basic_details': self.get_template_type().get_type_form_class(),
            'navigation': PageNodeForm
        }

    def get_form_kwargs(self, form_name, **kwargs):
        if form_name == 'navigation':
            kwargs['instance'] = self.get_node_instance()
        elif form_name == 'basic_details':
            kwargs['initial'] = self.get_page_instance().data
        return kwargs

    def forms_valid(self, request, forms, *args, **kwargs):
        node = forms['navigation'].instance
        node_data = forms['navigation'].cleaned_data
        for field_name, value in node_data.items():
            setattr(node, field_name, value)
        node.node_type = 'page'
        node.data = {}  # FIXME custom node form?
        node.save()

        page = self.get_page_instance()
        page.node = node
        page.template_type = self.get_template_type_name()
        page.data = to_json_safe_object(forms['basic_details'].cleaned_data)
        page.save()

        template_type = self.get_template_type()
        for chunk in template_type.get_chunks():
            chunk = deepcopy(chunk)
            if page.chunks.filter(
                chunk_name=chunk.chunk_name,
                global_chunk=False
            ).count() > 0:
                continue
            chunk.global_chunk = False
            chunk.save()
            page.chunks.add(chunk)
        return redirect(
            reverse('admin:pages:edit_page', args=[node.id])
        )


class DeletePageView(AdminDeleteView):
    """View for deleting CMS page models."""

    view_menu_selector = 'pages.list_pages'
    model = SiteNode
    model_id_param = 'page_id'

    def get_view_breadcrumbs(self):
        page_name = self.get_model().page.data.get(
            'view_title',
            'Untitled'
        )
        breadcrumbs = [
            (
                'Pages',
                reverse_lazy('admin:pages:list_pages')
            ),
            (
                f"Edit Page: {page_name}",
                reverse_lazy(
                    'admin:pages:edit_page',
                    args=[self.request_kwargs['page_id']]
                )
            ),
            (
                "Delete",
                reverse_lazy(
                    'admin:pages:delete_page',
                    args=[self.request_kwargs['page_id']]
                )
            )
        ]
        return breadcrumbs


class PreviewPageView(View):
    """A view for privately previewing a page regardless of published state"""

    def dispatch(self, request, page_id):
        """Fetch and display cms Page

        Args:
            request: The incoming django request
            page_id: Url parameter, the id of the Page model

        Raises:
            ValueError: Thrown if template type could not be found.
            Http404: Thrown if given Page model cannot be found.

        Returns:
            A django response object."""
        page = get_object_or_404(Page, node=page_id)
        template_type = get_template_type(page.template_type)
        if not template_type:
            raise ValueError(
                f'Template type "{page.template_type}" could not be found.'
            )
        return HttpResponse(
            template_type.render(request, page)
        )


class PageChunkTableView(AdminTableView):
    """A view for listing a Page's chunks."""

    view_title = 'Page Chunks'
    view_menu_selector = 'pages.list_pages'
    model = Chunk
    view_permissions = (
        'onyx_cms.view_chunk',
    )
    table_columns = []
    view_breadcrumbs = (
        ('Chunks', reverse_lazy('admin:pages:list_chunks')),
    )

    page_model = None
    """The Page model to get the chunks for"""

    def get_extra_columns(self):
        return [
            (
                'Name',
                Column(accessor='label', verbose_name='Name')
            ),
            (
                'Description',
                Column(accessor='description')
            ),
            (
                'Internal Name',
                Column(accessor='chunk_name', verbose_name='Internal Name')
            ),
            (
                ' ',
                LinkColumn(
                    'admin:pages:list_page_chunk_widgets',
                    text='Edit',
                    args=[self.request_kwargs['page_id'], A('chunk_name')]
                )
            ),
        ]

    def get_page_instance(self):
        """Get related Page model

        Raises:
            Http404: Thrown if given page cannot be found

        Returns:
            A Page model instance."""
        if not self.page_model:
            self.page_model = get_object_or_404(
                Page,
                node=self.request_kwargs['page_id']
            )
        return self.page_model

    def get_template_type(self):
        return get_template_type(self.get_page_instance().template_type)

    def get_queryset(self):
        return self.get_page_instance().chunks.all()

    def get_view_breadcrumbs(self):
        page_name = self.get_page_instance().data.get(
            'view_title',
            'Untitled'
        )
        return [
            (
                'Pages',
                reverse_lazy('admin:pages:list_pages')
            ),
            (
                f"Edit Page: {page_name}",
                reverse_lazy(
                    'admin:pages:edit_page',
                    args=[self.request_kwargs['page_id']]
                )
            ),
            (
                self.get_view_title(),
                reverse_lazy(
                    'admin:pages:list_page_chunks',
                    args=[self.request_kwargs['page_id']]
                )
            )
        ]


class PageWidgetsView(AdminTableView):
    """A list page for a page's chunk's widgets."""

    view_menu_selector = 'pages.list_pages'
    model = Widget
    table_columns = [
        'order'
    ]

    page_model = None
    """The page model the chunk belongs to"""

    chunk_model = None
    """The chunk model the widgets belong to"""

    def get_extra_columns(self):
        return [
            (
                'Name',
                WidgetDataColumn('get_label', verbose_name='Name')
            ),
            (
                'Description',
                WidgetDataColumn(
                    'get_description',
                    verbose_name='Description'
                )
            ),
            (
                ' ',
                LinkColumn(
                    'admin:pages:edit_page_widget',
                    text='Edit',
                    args=[
                        self.request_kwargs['page_id'],
                        self.request_kwargs['chunk_name'],
                        A('pk')
                    ]
                )
            )
        ]

    def get_view_title(self):
        chunk = self.get_page_instance().chunks.get(
            chunk_name=self.request_kwargs['chunk_name']
        )
        return f'List "{chunk.label}" widgets'

    def get_create_button_url(self):
        return reverse(
            'admin:pages:select_page_widget_type',
            args=[
                self.request_kwargs['page_id'],
                self.request_kwargs['chunk_name'],
            ]
        )

    def get_page_instance(self):
        """Get the page instance the chunk belongs to

        Raises:
            Http404: Thrown if page could not be found

        Returns:
            The page model."""
        if not self.page_model:
            self.page_model = get_object_or_404(
                Page,
                node=self.request_kwargs['page_id']
            )
        return self.page_model

    def get_chunk_model(self):
        """Get the Chunk instance the widgets belongs to

        Raises:
            Http404: Thrown if page could not be found

        Returns:
            The Chunk model."""
        if not self.chunk_model:
            try:
                self.chunk_model = self.get_page_instance().chunks.get(
                    chunk_name=self.request_kwargs['chunk_name']
                )
            except Chunk.DoesNotExist:
                raise Http404()
        return self.chunk_model

    def get_queryset(self):
        return self.get_chunk_model().widgets.all().order_by('order')

    def get_view_breadcrumbs(self):
        page_name = self.get_page_instance().data.get(
            'view_title',
            'Untitled'
        )
        return [
            (
                'Pages',
                reverse_lazy('admin:pages:list_pages')
            ),
            (
                f"Edit Page: {page_name}",
                reverse_lazy(
                    'admin:pages:edit_page',
                    args=[self.request_kwargs['page_id']]
                )
            ),
            (
                "Page Chunks",
                reverse_lazy(
                    'admin:pages:list_page_chunks',
                    args=[self.request_kwargs['page_id']]
                )
            ),
            (
                self.get_view_title(),
                reverse_lazy('admin:pages:list_page_chunk_widgets', args=[
                    self.request_kwargs['page_id'],
                    self.request_kwargs['chunk_name']
                ])
            )
        ]


class SelectPageChunkWidgetTypeView(AdminFormView):
    """View for selecting the widget type to create"""

    view_menu_selector = 'pages.list_pages'
    view_title = 'Select widget type'
    view_permissions = (
        'onyx_cms.add_widget',
    )
    form_classes = {
        'basic_details': SelectChunkWidgetForm
    }
    success_message = None
    submit_label = 'Select'

    def forms_valid(self, request, forms, *args, **kwargs):
        return redirect(
            reverse(
                'admin:pages:create_page_widget',
                kwargs={
                    'page_id': self.request_kwargs['page_id'],
                    'chunk_name': self.request_kwargs['chunk_name'],
                    'widget_type': forms['basic_details'].cleaned_data[
                        'widget'
                    ]
                }
            )
        )

    def get_view_breadcrumbs(self):
        page = get_object_or_404(Page, node=self.request_kwargs['page_id'])
        chunk = page.chunks.get(chunk_name=self.request_kwargs['chunk_name'])
        return [
            (
                'Pages',
                reverse_lazy('admin:pages:list_pages')
            ),
            (
                f"Edit Page: {page.data.get('view_title', 'Untitled')}",
                reverse_lazy(
                    'admin:pages:edit_page',
                    args=[self.request_kwargs['page_id']]
                )
            ),
            (
                "Page Chunks",
                reverse_lazy(
                    'admin:pages:list_page_chunks',
                    args=[self.request_kwargs['page_id']]
                )
            ),
            (
                f'List "{chunk.label}" widgets',
                reverse_lazy(
                    'admin:pages:list_page_chunk_widgets',
                    args=[
                        self.request_kwargs['page_id'],
                        self.request_kwargs['chunk_name']
                    ]
                )
            ),
            (
                self.get_view_title(),
                reverse_lazy(
                    'admin:pages:select_page_widget_type',
                    args=[
                        self.request_kwargs['page_id'],
                        self.request_kwargs['chunk_name']
                    ]
                )
            )
        ]


class EditPageChunkWidget(BaseEditWidgetView):
    """Edit page chunk widget view"""

    view_menu_selector = 'pages.list_pages'

    page_model = None
    """The page model the chunk belongs to"""

    chunk_model = None
    """The chunk model the widget is being added to"""

    def get_page_model(self):
        """Get the page model of the chunk widget being edited

        Raises:
            Http404: Thrown if page cannot be found.

        Returns:
            The Page model."""
        if not self.page_model:
            self.page_model = get_object_or_404(
                Page,
                node=self.request_kwargs['page_id']
            )
        return self.page_model

    def get_chunk_model(self):
        """Get chunk model for this widget

        Raises:
            Http404: Thrown if parent page model cannot be found.

        Returns:
            The Chunk model."""
        if not self.chunk_model:
            self.chunk_model = self.get_page_model().chunks.get(
                chunk_name=self.request_kwargs['chunk_name']
            )
        return self.chunk_model

    def get_extra_buttons(self):
        buttons = []
        if self.is_editing():
            buttons.append(
                (
                    'Delete Widget',
                    reverse(
                        'admin:pages:delete_page_widget',
                        args=[
                            self.request_kwargs['page_id'],
                            self.request_kwargs['chunk_name'],
                            self.request_kwargs['widget_id'],
                        ]
                    )
                )
            )
        return buttons

    def get_view_breadcrumbs(self):
        page = self.get_page_model()
        chunk = self.get_chunk_model()
        crumbs = [
            (
                'Pages',
                reverse_lazy('admin:pages:list_pages')
            ),
            (
                f"Edit Page: {page.data.get('view_title', 'Untitled')}",
                reverse_lazy(
                    'admin:pages:edit_page',
                    args=[self.request_kwargs['page_id']]
                )
            ),
            (
                "Page Chunks",
                reverse_lazy(
                    'admin:pages:list_page_chunks',
                    args=[self.request_kwargs['page_id']]
                )
            ),
            (
                f'List "{chunk.label}" widgets',
                reverse_lazy('admin:pages:list_page_chunk_widgets', args=[
                    self.request_kwargs['page_id'],
                    self.request_kwargs['chunk_name']
                ])
            )
        ]
        if not self.is_editing():
            crumbs.append(
                (
                    "Select widget type",
                    reverse_lazy(
                        'admin:pages:select_page_widget_type',
                        args=[
                            self.request_kwargs['page_id'],
                            self.request_kwargs['chunk_name']
                        ]
                    )
                )
            )
        crumbs.append(
            (
                self.get_view_title(),
                reverse_lazy(
                    'admin:pages:edit_page_widget'
                    if self.is_editing()
                    else 'admin:pages:create_page_widget',
                    args=[
                        self.request_kwargs['page_id'],
                        self.request_kwargs['chunk_name'],
                        self.request_kwargs[
                            'widget_id'
                            if self.is_editing()
                            else 'widget_type'
                        ],
                    ]
                )
            )
        )
        return crumbs

    def get_form_kwargs(self, form_name):
        kwargs = super().get_form_kwargs(form_name)
        if form_name == 'order' and not self.is_editing():
            max_order = self.get_chunk_model().widgets.aggregate(
                Max('order')
            )['order__max']
            kwargs['initial'] = {
                'order': int(max_order) + 1 if max_order is not None else 0
            }
        return kwargs

    def forms_valid(self, request, forms, *args, **kwargs):
        page = get_object_or_404(Page, node=self.request_kwargs['page_id'])
        chunk = page.chunks.get(chunk_name=self.request_kwargs['chunk_name'])
        widget, created = self.update_widget(request, forms)
        if created:
            chunk.widgets.add(widget)
        return redirect(
            reverse(
                'admin:pages:list_page_chunk_widgets',
                args=[
                    self.request_kwargs['page_id'],
                    chunk.chunk_name
                ]
            )
        )


class DeletePageWidgetView(AdminDeleteView):
    """View for deleting a page chunk widget"""

    view_menu_selector = 'pages.list_pages'
    model = Widget
    model_id_param = 'widget_id'
    view_permissions = [
        'onyx_cms.delete_widget'
    ]
