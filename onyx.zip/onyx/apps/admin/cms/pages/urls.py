"""Url patterns for pages admin apps"""

from django.urls import path

from onyx.apps.admin.cms.pages import views


app_name = 'pages'
urlpatterns = [
    path(
        'pages/',
        views.PageTableView.as_view(),
        name='list_pages'
    ),
    path(
        'pages/select-template/',
        views.SelectTemplateTypeView.as_view(),
        name='select_template'
    ),
    path(
        'pages/select-template/<str:template_type>/',
        views.EditPageView.as_view(),
        name='create_page'
    ),
    path(
        'pages/<int:page_id>/',
        views.EditPageView.as_view(),
        name='edit_page'
    ),
    path(
        'pages/<int:page_id>/delete/',
        views.DeletePageView.as_view(),
        name='delete_page'
    ),
    path(
        'pages/<int:page_id>/preview/',
        views.PreviewPageView.as_view(),
        name='preview_page'
    ),
    path(
        'pages/<int:page_id>/chunks/',
        views.PageChunkTableView.as_view(),
        name='list_page_chunks'
    ),
    path(
        'pages/<int:page_id>/chunks/<str:chunk_name>/',
        views.PageWidgetsView.as_view(),
        name='list_page_chunk_widgets'
    ),
    path(
        'pages/<int:page_id>/chunks/<str:chunk_name>/select-widget-type/',
        views.SelectPageChunkWidgetTypeView.as_view(),
        name='select_page_widget_type'
    ),
    path(
        'pages/<int:page_id>/chunks/<str:chunk_name>/select-widget-type'
        + '/<str:widget_type>/',
        views.EditPageChunkWidget.as_view(),
        name='create_page_widget'
    ),
    path(
        'pages/<int:page_id>/chunks/<str:chunk_name>/<int:widget_id>/',
        views.EditPageChunkWidget.as_view(),
        name='edit_page_widget'
    ),
    path(
        'pages/<int:page_id>/chunks/<str:chunk_name>/<int:widget_id>/delete/',
        views.DeletePageWidgetView.as_view(),
        name='delete_page_widget'
    )
]
