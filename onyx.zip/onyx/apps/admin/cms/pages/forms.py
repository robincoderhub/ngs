"""Forms related to pages admin app"""

from django import forms

from onyx.apps.cms.models import SiteNode
from onyx.apps.cms.register import get_template_types


class SelectTemplateForm(forms.Form):
    """Form for selecting a page template, populates
    choice field with registered template types.

    Args:
        *args: Inherited args
        **kwargs: Inherited keyword arguments"""

    template = forms.ChoiceField()
    """A choice field to select the template type"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['template'].choices = sorted([
            (template_name, template_type.get_label())
            for template_name, template_type in get_template_types().items()
        ], key=lambda x: x[1])


class PageNodeForm(forms.ModelForm):
    """Model form for editing a page SiteNode"""

    class Meta:
        model = SiteNode
        exclude = [
            'node_type',
            'last_updated',
            'data'
        ]
