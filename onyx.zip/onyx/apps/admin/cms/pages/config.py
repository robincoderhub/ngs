"""App configs for the pages admin app"""

from onyx.apps.admin.config import AbstractAdminAppConfig


class AdminCMSPagesConfig(AbstractAdminAppConfig):
    """Default app config for the pages admin app"""

    name = "onyx.apps.admin.cms.pages"
    """The python path to the app"""

    verbose_name = "Onyx - Admin - CMS - Pages"
    """The human readable name of the app"""

    label = "onyx_admin_cms_pages"
    """The internal Django name of the app"""
