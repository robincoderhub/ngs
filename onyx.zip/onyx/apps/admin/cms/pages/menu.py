"""Admin menu items for pages admin app"""

from django.urls import reverse_lazy

from onyx.apps.cms.menus.items import MenuItem


menu_nodes = [
    MenuItem(
        'Pages',
        node_weight=210,
        node_children=[
            MenuItem(
                'Create Page',
                data={
                    'url': reverse_lazy('admin:pages:select_template')
                }
            ),
            MenuItem(
                'List Pages',
                data={
                    'url': reverse_lazy('admin:pages:list_pages')
                }
            )
        ]
    )
]
