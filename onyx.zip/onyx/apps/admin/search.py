"""Classes for the built in admin search.

Notes:
    At the moment this search just searches the admin menu to allow
    users to jump to different sections easily. However it could be
    changed to allow searching of different apps models."""
import re

from onyx.apps.admin.core import get_admin_menu_tree


class AdminSearchResult(object):
    """A structure for the results of the admin search

    Args:
        url: The url of the result
        label: The human readable label of the result"""
    def __init__(self, url, label):
        self.url = url
        self.label = label

    def get_url(self):
        """Get the url for this result

        Returns:
            The url string."""
        return self.url

    def get_label(self):
        """Get the human readable label for this result

        Returns:
            The label string."""
        return self.label

    def to_dict(self):
        """Convert object into a dict

        Returns:
            A dict containing a url and label member."""
        return {
            'url': self.get_url(),
            'label': self.get_label()
        }


class AdminSearch(object):
    """Main admin search class"""

    def search(self, search_term, user=None, as_dict=False):
        """Main search method, returns results for given
        search term.

        Args:
            search_term: The string search term to search for
            user: Optional, if passed hides options user does not
                have access to.
            as_dict: Defaults to False, if True returns results as dict
                objects, if False returns them as AdminSearchResult objects.

        Returns:
            Either a list of dicts or AdminSearchResult objects"""
        admin_menu = get_admin_menu_tree(user)
        search_words = [word.lower() for word in search_term.split()]

        def search_admin_menu(term, menu_items):
            """A recursive search method for searching the items of
            a menu tree.

            Args:
                term: The search term to search for
                menu_items: A list of MenuItemTree of MenuItem objects

            Returns:
                A list of dicts or AdminSearchResult objects that matched
                the query."""
            results = []
            for node in menu_items:
                if (
                    hasattr(node, 'get_url')
                    and node.get_url()
                    and hasattr(node, 'get_label')
                    and node.get_label()
                ):
                    if all([
                        re.match(
                            f".*{re.escape(word)}.*",
                            node.get_label().lower()
                        )
                        for word in search_words
                    ]):
                        results.append(
                            AdminSearchResult(
                                node.get_url(),
                                node.get_label()
                            )
                        )

                if node.has_node_children():
                    results = results + search_admin_menu(
                        term,
                        node.get_node_children()
                    )
            return results

        results = search_admin_menu(search_term, admin_menu)

        if as_dict:
            return [result.to_dict() for result in results]
        return results
