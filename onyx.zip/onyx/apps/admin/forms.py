"""Forms related to the admin app"""

from django import forms


class GenericDeleteForm(forms.Form):
    """A form for the generic model delete view."""

    confirm = forms.BooleanField(
        label='I confirm I want to delete this model.'
    )
    """A confirmation field user must accept to complete
    deletion."""
