"""Middleware for the admin app."""

from django.urls import reverse
from django.shortcuts import redirect
from django.utils.http import urlencode

from onyx.apps.admin import app_settings
from onyx.utils.middleware import RestrictedPathMiddleware


class AdminPathMiddleware(RestrictedPathMiddleware):
    """A restricted path middleware that ensures users must be logged
    in as staff to view any admin sections under the defined 'ADMIN_URL'
    settings variable."""

    url_paths = [str(app_settings.ADMIN_URL)]
    """Paths to restrict, this is typically /admin/"""

    url_path_exceptions = app_settings.ADMIN_MIDDLEWARE_EXCEPTIONS
    """Exception paths to restriction middleware."""

    staff_only = True
    """Set the middleware to be staff only."""

    def get_exception_paths(self):
        """Extends method to add the detected js constants view of the
        admin app to exception paths.

        Returns:
            A list of paths that can be accessed."""
        exceptions = super().get_exception_paths()
        exceptions.append(reverse('admin:js_constants'))
        return exceptions

    def get_restricted_response(self, request):
        """Override of method to redirect user to login page with 'next'
        url parameter to redirect them back to the original page if
        unauthenticated.

        Args:
            request: The incoming django request

        Returns:
            A django response object, a redirect."""
        path = str(app_settings.ADMIN_LOGIN_PATH)
        params = urlencode({'next': request.get_full_path()})
        return redirect(
            f"{path}?{params}"
        )
