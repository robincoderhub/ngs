"""Admin app settings and their defaults."""

from django.conf import settings
from django.urls import reverse_lazy


ADMIN_LOGIN_PATH = getattr(settings, 'ADMIN_LOGIN_PATH', reverse_lazy('login'))
"""The path admin will redirect to if use is not authenticated/not staff"""


ADMIN_URL = getattr(settings, 'ADMIN_URL', reverse_lazy('admin:dashboard'))
"""The primary url for admin, used by middleware for authentication"""


ADMIN_MIDDLEWARE_EXCEPTIONS = getattr(
    settings,
    'ADMIN_MIDDLEWARE_EXCEPTION',
    []
)
"""Exception url paths for midddleware, allows viewing of urls if
not authenticated"""
