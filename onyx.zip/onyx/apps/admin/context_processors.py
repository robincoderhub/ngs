"""Context processors for the admin app"""

from django.contrib.sites.shortcuts import get_current_site

from onyx.apps.admin import core
from onyx import app_settings


def admin(request):
    """A context processor for adding a number of application variables
    to the context, site urls and admin specific variables such as the
    main menu.

    Args:
        request: The incoming django request

    Returns:
        A dict of context data to add"""
    context = {}

    # Add site url data
    site = get_current_site(request)
    context['SITE_DOMAIN'] = site.domain
    context['SITE_NAME'] = site.name
    context['SITE_PROTOCOL'] = 'https' if request.is_secure() else 'http'
    context['SITE_URL'] = f"{context['SITE_PROTOCOL']}://{context['SITE_DOMAIN']}"

    # Add app data
    context['APP_NAME'] = app_settings.APP_NAME
    context['APP_ENV'] = app_settings.APP_ENV
    context['APP_RELEASE'] = app_settings.APP_RELEASE

    # Add admin data
    context['ADMIN_MENU'] = core.get_admin_menu_tree()
    context['ADMIN_CSS'] = core.get_admin_css()
    context['ADMIN_JS'] = core.get_admin_js()
    context['ADMIN_META'] = core.get_admin_meta()

    return context
