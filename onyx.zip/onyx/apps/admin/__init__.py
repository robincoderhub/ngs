"""
# Admin app

The root admin CMS app, common code to CMS admin apps go here

## Installation

To install the admin app add it to your installed apps
```
INSTALLED_APPS = [
    ...
    'onyx.apps.admin',
    ...
]
```

Then add the middleware used to restrict access to the admin area:
```
MIDDLEWARE = [
    ...
    'onyx.apps.admin.middleware.AdminPathMiddleware',
    ...
]
```

Then finally add the admin context processor:
```
TEMPLATES = [
    {
        ...
        'OPTIONS': {
            ...
            'context_processors': [
                ...
                'onyx.apps.admin.context_processors.admin',
            ],
        },
    },
]
```

## Creating an admin app

To create a basic admin app follow the following steps

### Create an app config

Create an app config that extends from the `onyx.apps.admin.config.AbstractAdminAppConfig` class, this tells the admin app that this app should be detected for urls and menu items.
```
from onyx.apps.admin.config import AbstractAdminAppConfig

class BeansApp(AbstractAdminAppConfig):
    name = "project.apps.admin.beans"
    verbose_name = "Project - Admin - Beans"
    label = "project_admin_beans"
```

### Defining urls

Define urls just as you would with any other Django app but with the exception that you don't need to manually include it in your root `urls.py` file. An example file:
```
from django.urls import path

from project.admin.beans import views


app_name = 'beans'
urlpatterns = [
    path(
        '',
        views.BeansHomepage.as_view(),
        name='homepage'
    ),
    path(
        'my-page/',
        views.BeansHomepage.as_view(),
        name='my_page'
    ),
]
```

When the site loads, these url patterns will be added on to whatever the `app_name` variable is defined as i.e.
```
/admin/beans/
/admin/beans/my-page/
```

To refer to these urls in code by name just prefix `admin` to the django reference for example:
```
reverse('admin:beans:homepage')
```

### Defining menu items

To add menu items to be added to the main admin menu, create a `menu.py` file in the root of your app.
```
from django.urls import reverse_lazy

from onyx.apps.cms.menus.items import MenuItem


menu_nodes = [
    MenuItem(
        'Beans',
        node_children=[
            MenuItem(
                'Homepage',
                data={
                    'url': reverse_lazy('admin:beans:homepage')
                }
            ),
            MenuItem(
                'My page',
                data={
                    'url': reverse_lazy('admin:beans:my_page')
                }
            )
        ]
    )
]
```

"""

default_app_config = 'onyx.apps.admin.config.AdminConfig'
