"""Generic admin views, these views should be extended by other admin apps
to build their views."""

from django.http import Http404
from django.shortcuts import get_object_or_404, redirect
from django.db import transaction
from django.contrib import messages
from django.forms.utils import pretty_name
from django.views.generic import TemplateView

from onyx.views import SearchTableView, SmartContextMixin, TabbedMultiFormView
from onyx.utils.conditionals import validate_conditions
from onyx.apps.admin.core import get_admin_menu_tree
from onyx.apps.admin.forms import GenericDeleteForm


class AdminContextMixin(SmartContextMixin):
    """A mixin to add admin context data and attributes to class based
    views."""

    extra_buttons = None
    """A list of tuples containing (label, url) of extra buttons to display
    on the admin page."""

    def get_extra_buttons(self):
        """Getter for extra view buttons.

        Returns:
            A list of tuples containing (label, url) of extra buttons to
            display on the admin page."""
        return self.extra_buttons

    def get_view_menu(self):
        """Getter for the view's menu, returns the admin
        menu.

        Returns:
            A MenuItemTree"""
        return get_admin_menu_tree()

    def get_context_data(self, **kwargs):
        """Extends method to add extra buttons to context.

        Args:
            **kwargs: The current context data

        Returns:
            The update context dict."""
        context = super().get_context_data(**kwargs)
        context.update({'extra_buttons': self.get_extra_buttons()})
        return context


class AdminView(AdminContextMixin, TemplateView):
    """A template view with the admin context mixin added."""
    pass


class AdminTableView(AdminContextMixin, SearchTableView):
    """An admin results table view for displaying models."""

    template_name = 'onyx/apps/admin/generic/table_view/base.html'
    """The main view template name."""

    table_template_name = 'onyx/apps/admin/generic/table_view/table.html'
    """The template name for the django_table table"""

    create_button_url = None
    """Optional, a 'create' button url for creating the type of object you
    are viewing. This is used for a call to action button on the page."""

    create_button_permissions = None
    """A conditional object determining the user permissions the user needs
    to view the create button."""

    def get_view_title(self):
        """Extends method, gets the view title or generates one based on
        the model being displayed.

        Returns:
            The title string."""
        title = super().get_view_title()
        if not title and self.model:
            return f"{pretty_name(self.model.__name__)} List"
        return title

    def get_create_button_url(self):
        """Getter for create button url

        Returns:
            The create button url string."""
        return self.create_button_url

    def get_create_button_permissions(self):
        """Getter for create button permissions

        Returns:
            A set of conditional object for user permissions or None."""
        return self.create_button_permissions

    def prepare_create_button_url(self):
        """'Prepares' the create button url, checks the permissions
        for the create button and if the permissions are not met,
        return None for the url.

        Returns:
            The create button url if defined otherwise None."""
        create_url = self.get_create_button_url()
        permissions = self.get_create_button_permissions()
        has_permissions = True

        if hasattr(self, 'request') and self.request and permissions:
            has_permissions = validate_conditions(
                lambda x, y: x.has_perm(y),
                self.request.user,
                permissions
            )
        return create_url if has_permissions else None

    def get_context_data(self, **kwargs):
        """Extends method to add create button url to context.

        Args:
            **kwargs: The current context data

        Returns:
            The updated context dict."""
        context = super().get_context_data(**kwargs)
        context['create_button_url'] = self.prepare_create_button_url()
        return context


class AdminFormView(AdminContextMixin, TabbedMultiFormView):
    """An admin view for displaying and processing multiple forms in tabs."""

    template_name = 'onyx/apps/admin/generic/form_view/base.html'
    """The admin template to use."""

    submit_label = 'Save'
    """The label for the submit button of your form view."""

    def get_submit_label(self):
        """Get the label for the submit button

        Returns:
            The submit button label string."""
        return self.submit_label

    def get_context_data(self, **kwargs):
        """Extends method to add submit label to template context.

        Args:
            **kwargs: The current context data

        Returns:
            The updated context dict."""
        context = super().get_context_data(**kwargs)
        context['submit_label'] = self.get_submit_label()
        return context


class AdminDeleteView(AdminContextMixin, TemplateView):
    """A generic deletion view for a model"""

    template_name = 'onyx/apps/admin/generic/delete_view/base.html'
    """The template name for the view"""

    model = None
    """The class of the model to be deleted."""

    model_id_param = 'id'
    """The url parameter name to get the models' unique id"""

    delete_form_class = GenericDeleteForm
    """The deletion form to display for confirmation."""

    success_redirect = '../../'
    """The redirect url when the deletion has completed."""

    def get_success_redirect(self):
        """Get the redirect url for when the model has been
        deleted.

        Returns:
            The string success url"""
        return self.success_redirect

    def get_delete_form_class(self):
        """Getter for the deletion confirmation form class

        Returns:
            The django form class."""
        return self.delete_form_class

    def get_model_class(self):
        """Get the model class of the object being deleted.

        Returns:
            A Model class"""
        return self.model

    def get_model_id(self):
        """Get the id of the model to delete

        Raises:
            Http404: Thrown if no id parameter could be found

        Returns:
            The id of the model."""
        if self.model_id_param not in self.request_kwargs:
            raise Http404('No model id specified.')
        return self.request_kwargs[self.model_id_param]

    def get_model(self):
        """Get model instance of the model to delete

        Raises:
            Http404: Thrown if model could not be found.

        Returns:
            The model class."""
        return get_object_or_404(
            self.get_model_class(),
            id=self.get_model_id()
        )

    def get_view_title(self):
        """Extends method, gets the view title, if no title attribute
        has been specified, generates a title based on the model type
        being deleted.

        Returns:
            The string title."""
        title = super().get_view_title()
        if title is None and self.get_model_class():
            title = pretty_name(self.get_model_class().__name__)
            return f'Delete {self.get_model()}?'
        return title

    def post(self, request, *args, **kwargs):
        """POST method handler, processes deletion request.

        Args:
            request: The incoming django request
            *args: The request arguments
            **kwargs: The request keyword arguments

        Returns:
            A django response object, a redirect if success or
            the form page."""
        form = self.get_delete_form_class()(data=request.POST)
        if form.is_valid():
            model = self.get_model()
            with transaction.atomic():
                self.delete_model(model, form)
            messages.success(request, f"{model} was deleted successfully")
            return redirect(self.get_success_redirect())
        return self.render_to_response(
            self.get_context_data(
                form=form
            )
        )

    def delete_model(self, model, delete_form):
        """Method for deleting the model, can be overidden to
        add any special logic

        Args:
            model: The model instance to be deleted
            delete_form: The confirmation form"""
        model.delete()

    def get(self, request, *args, **kwargs):
        """GET method handler, displays confirmation page.

        Args:
            request: The django request object
            *args: The request arguments
            **kwargs: The request keyword arguments

        Returns:
            A django response object."""
        return self.render_to_response(
            self.get_context_data(
                form=self.get_delete_form_class()()
            )
        )
