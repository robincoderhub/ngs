"""Views related to the admin app"""

from django.urls import reverse
from django.http import JsonResponse
from django.views.generic import View, TemplateView

from onyx import app_settings
from onyx.views import JSConstantsView
from onyx.apps.admin.search import AdminSearch
from onyx.apps.admin.views.generic import AdminContextMixin


class AdminDashboard(AdminContextMixin, TemplateView):
    """Default admin dashboard view, displays a basic welcome message.
    This view would typically be overidden."""

    view_title = 'Dashboard'
    """The title of the view"""

    view_menu_selector = 'dashboard'
    """The menu selector for this view."""

    template_name = 'onyx/apps/admin/dashboard.html'
    """The template name for this view."""


class AdminJSConstants(JSConstantsView):
    """System generated JS variable view"""

    def get_constants(self, *args, **kwargs):
        """Extends method, adds admin JS variables to constants

        Args:
            *args: Inherited arguments
            **kwargs: Inherited keyword arguments

        Returns:
            The updated constants dict."""
        constants = super().get_constants(*args, **kwargs)
        constants.update({
            'SENTRY_DSN': app_settings.SENTRY_DSN,
            'APP_NAME': app_settings.APP_NAME,
            'APP_ENV': app_settings.APP_ENV,
            'APP_RELEASE': app_settings.APP_RELEASE,
            'SEARCH_URL': reverse('admin:search')
        })
        return constants


class AdminAjaxSearch(View):
    """An ajax endpoint view for the main admin search."""

    def get_data(self, request):
        """Get the data to return for the search.

        Args:
            request: The incoming request

        Returns:
            A dict of results intended to be JSON-a-fied."""
        search_term = request.GET.get('search_term').strip()
        if not search_term:
            return {}
        results = AdminSearch().search(
            search_term,
            user=request.user,
            as_dict=True
        )
        return {
            'results': results
        }

    def get(self, request):
        """Get method, returns results as JSON

        Args:
            request: The incoming django request

        Returns:
            A JSONResponse django response object."""
        return JsonResponse(self.get_data(request))
