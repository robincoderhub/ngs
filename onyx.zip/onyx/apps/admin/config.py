"""Admin app config classes"""

from onyx.config import AbstractOnyxConfig


class AdminAppConfigMixin(object):
    """A mixin for adding any common attributes to admin apps"""
    pass


class AbstractAdminAppConfig(AdminAppConfigMixin, AbstractOnyxConfig):
    """A base class for admin app configs"""
    pass


class AdminConfig(AbstractOnyxConfig):
    """Default admin app config"""

    name = "onyx.apps.admin"
    """The python path to the app"""

    verbose_name = "Onyx - Admin"
    """The human readable name of the app"""

    label = "onyx_admin"
    """The internal Django name of the app"""
