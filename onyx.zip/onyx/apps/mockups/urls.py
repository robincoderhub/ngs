"""URL patterns for the mockups app"""

from django.urls import path

from onyx.apps.mockups import views

app_name = 'mockups'

urlpatterns = [
    path('<path:path>/', views.MockupResolver.as_view(), name='resolver'),
]
