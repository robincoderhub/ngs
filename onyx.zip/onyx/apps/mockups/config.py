"""Mockups App configuration classes"""

from onyx.config import AbstractOnyxConfig


class MockupsConfig(AbstractOnyxConfig):
    """Mockups app configuration"""

    name = "onyx.apps.mockups"
    """The python path to the app"""

    verbose_name = "Onyx - Mockups"
    """The human readable name of the app"""

    label = "onyx_mockups"
    """The internal Django name of the app"""
