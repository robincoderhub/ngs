"""Mockup related views"""

from django.http import Http404
from django.shortcuts import render
from django.views.generic import View
from django.template.loader import get_template, TemplateDoesNotExist


class MockupResolver(View):
    """A resolver view for serving templates in the mockups directory"""

    def get(self, request, path):
        """Handles GET requests, uses the path variable in the
        mockups directory to determine template. If none found 404s.

        Args:
            request: The Django request object
            path: The path url keyword to detect the path with
        Raises:
            Http404: If no template found.
        Returns:
            A Django response object"""
        template_path = f"mockups/{path}.html"
        try:
            get_template(template_path)
        except TemplateDoesNotExist:
            raise Http404()
        return render(request, template_path)
