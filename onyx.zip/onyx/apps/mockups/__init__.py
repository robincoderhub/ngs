"""
# Mockups app

A very simple app for serving 'flat' pages from a directory
without the need to set up separate views.

This mostly intended to be used during front end development.

## Requirements
- onyx

## Installation

To install this app just add it to your INSTALLED_APPS config
```
INSTALLED_APPS = [
    ...
    'onyx.apps.mockups',
]
```

## Creating/viewing mockup templates

To add a template to mockups just add a `mockups/` directory in the root of
your template directory and create your standalone html files in there. You
can then use the same names and directory structure in the url. For example:
```
/templates/mockups/hello.html
# url = /mockups/hello/

/templates/mockups/my/folder/test.html
# url = /mockups/my/folder/test/
```
"""

default_app_config = 'onyx.apps.mockups.config.MockupsConfig'
