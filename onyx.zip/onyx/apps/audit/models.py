"""Models related to audit app"""

from django.db import models


class AuditLog(models.Model):
    """Main audit log model, this model represents
    a log message"""

    user_id = models.IntegerField(null=True)
    """The user id who performed the action"""

    username = models.CharField(null=True, max_length=255)
    """The username of the user who performed the action"""

    first_name = models.CharField(null=True, max_length=255)
    """The first name of the user"""

    last_name = models.CharField(null=True, max_length=255)
    """The last name of the user"""

    model_id = models.IntegerField(null=True)
    """The id of the model this action was performed on (if applicable)"""

    model_label = models.CharField(null=True, max_length=255)
    """The name of the model class (if applicable)"""

    remote_addr = models.CharField(null=True, max_length=255)
    """The remote address (ip) of the user"""

    datetime = models.DateTimeField(auto_now_add=True)
    """A stamp of when this log was created"""

    message = models.TextField()
    """The human redable message of this log"""
