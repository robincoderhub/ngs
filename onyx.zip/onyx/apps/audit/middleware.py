import uuid
import threading

from django.db.models.signals import pre_save
from django.utils.functional import curry
from django.utils.deprecation import MiddlewareMixin

from onyx.utils import get_real_ip
from onyx.apps.audit.models import AuditLog


local_thread = threading.local()
"""Fetch and assign the current thread to a variable"""


class AuditLogMiddleware(MiddlewareMixin):
    """Middleware for adding and removing request details
    to be used in logging model changes automatically."""

    def process_request(self, request):
        # If user is not authenticated, don't bother with
        # logging.
        if not request.user.is_authenticated:
            return

        # Add audit log information to local thread
        local_thread.audit_log = {
            'signal_duid': (self.__class__, uuid.uuid4()),
            'remote_addr': get_real_ip(request)
        }

        # Set default params for log details as those
        # given in this request, assign resultant
        # callable to var
        set_log_details = curry(
            self.set_log_details,
            user=request.user,
            signal_duid=local_thread.audit_log['signal_duid']
        )

        # Connect set_log_details to model pre save
        # signal
        pre_save.connect(
            set_log_details,
            sender=AuditLog,
            dispatch_uid=local_thread.audit_log['signal_duid'],
            weak=False
        )

    def process_response(self, request, response):
        """Removes signal listener when request is complete. This
        prevents old information being passed to other requests.

        Args:
            request: The original request
            response: The outgoing request

        Returns:
            A django response object."""
        if hasattr(local_thread, 'audit_log'):
            pre_save.disconnect(
                sender=AuditLog,
                dispatch_uid=local_thread.audit_log['signal_duid']
            )
        return response

    def process_exception(self, request, exception):
        """Removes signal listener if an exception occurred. This
        prevents old information being passed to other requests.

        Args:
            request: The original request
            exception: The exception that was caught"""
        if hasattr(local_thread, 'audit_log'):
            pre_save.disconnect(
                sender=AuditLog,
                dispatch_uid=local_thread.audit_log['signal_duid']
            )

    @staticmethod
    def set_log_details(user, sender, instance, signal_duid, **kwargs):
        """Signal handler to pre populate logging details on AuditLog models
        for this request in this thread.

        Args:
            user: The user accessing the site
            sender: The model that has sent this signal
            instance: The specific model instance that has sent this signal
            signal_duid: A unique identifier of this request, checks against
                the one set on the thread to ensure it's the same request.
            **kwargs: Inehrited signal handler keyword arguments"""
        if not hasattr(local_thread, 'audit_log')\
             or signal_duid != local_thread.audit_log['signal_duid']:
            return
        if sender == AuditLog:
            instance.user_id = instance.user_id or user.id
            instance.username = instance.username or getattr(
                user, user.USERNAME_FIELD)
            instance.first_name = instance.first_name or user.first_name
            instance.last_name = instance.last_name or user.last_name
            instance.remote_addr = instance.remote_addr\
                or local_thread.audit_log['remote_addr']
