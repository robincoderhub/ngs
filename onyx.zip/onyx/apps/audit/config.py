"""Audit App configuration classes"""

from onyx.config import AbstractOnyxConfig


class AuditConfig(AbstractOnyxConfig):
    """Default config for audit app"""

    name = "onyx.apps.audit"
    """The python path to the app"""

    verbose_name = "Onyx - Audit"
    """The human readable name of the app"""

    label = "onyx_audit"
    """The internal Django name of the app"""

    def ready(self):
        """Includes app signal listeners when the app
        has loaded"""
        from onyx.apps.audit import signals  # noqa  # pylint: disable=unused-import
