"""
# Model auditing app

A model audit log app that allows you to automatically track changes in models.

## Installation
TODO

## Registering a model
TODO

"""

default_app_config = 'onyx.apps.audit.config.AuditConfig'
