"""Logging business logic classes"""

from django.forms.utils import pretty_name

from onyx.apps.audit.models import AuditLog
from onyx.apps.audit.utils import get_changed_field_names


MODEL_REGISTER = {}
"""A register for storing what models should be tracked"""


def get_model_register():
    """Getter for model register

    Returns:
        A dict keyed by model -> auditing options"""
    global MODEL_REGISTER
    return MODEL_REGISTER


def register_model(model, exclude_fields=None, only_fields=None):
    """Add a model to the register

    Args:
        model: A django model class
        exclude_fields: Optional, a list of fields to skip
            auditing if they change. For example last_login
            on the User model.
        only_fields: Optional, a whitelist of fields that
            should be tracked."""
    global MODEL_REGISTER
    MODEL_REGISTER[model] = {
        'exclude_fields': exclude_fields,
        'only_fields': only_fields
    }


class AuditLogger(object):
    """Audit logging class"""

    def log(self, message, user=None, model=None, model_id=None):
        """Create an audit log with the given information.

        Args:
            message: A human readable message of what has happened.
            user: Optional, the user model who did this action
            model: Optional, the model this action is related to.
            model_id: Optional, the specific model id this action
                was executed on.

        Returns:
            The saved AuditLog model"""
        log = AuditLog()
        log.message = message
        if user:
            log.user_id = user.id
            log.username = getattr(user, user.USERNAME_FIELD)
            log.first_name = user.first_name or None
            log.last_name = user.last_name or None
        if model:
            log.model_label = model._meta.label
            if model.id or model_id:
                log.model_id = model.id or model_id
        log.save()
        return log

    def log_model_create(self, model, user=None):
        """A shortcut for logging a model creation action

        Args:
            model: The model that has been created.

        Returns:
            The saved AuditLog model"""
        return self.log(
            f'Created {pretty_name(self.get_model_name(model))} "{str(model)}"',
            user=user,
            model=model
        )

    def log_model_update(self, model, user=None, model_before=None):
        """A shortcut for logging changes to a model

        Args:
            model: The current (updated) model that has changed.
            user: Optional, the user that changed it.
            model_before: A copy of the model in it's pre-changed
                state. Used to detect what fields have changed.

        Returns:
            The saved AuditLog model"""
        model_name = pretty_name(self.get_model_name(model))
        message = f'Updated {model_name} "{str(model)}"'
        if model_before:
            changed_fields = ", ".join(
                get_changed_field_names(
                    model,
                    model_before
                )
            )
            message = f"{message}: {changed_fields}"
        return self.log(message, user=user, model=model)

    def log_model_delete(self, model, model_id, user=None):
        """Shortcut for logging a model deletion.

        Args:
            model: The model that has been deleted
            model_id: The id of the model before it was deleted.
            user: Optional, the user that deleted it.

        Returns:
            The saved AuditLog model."""
        model_name = pretty_name(self.get_model_name(model))
        self.log(
            f'Deleted {model_name} "{str(model)}"',
            user=user,
            model=model,
            model_id=model_id
        )

    def get_model_name(self, model):
        """Utility for fetching a model's name
        from a class or instance.

        Args:
            model: The model to get the name of

        Returns:
            The name as a string."""
        if hasattr(model, '__name__'):
            return model.__name__
        return model.__class__.__name__


logger = AuditLogger()
"""The global instance of the AuditLogger class"""
