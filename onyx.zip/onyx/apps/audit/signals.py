"""Signal handlers for audit app"""

from django.db.models.signals import (
    pre_save,
    post_save,
    pre_delete,
    post_delete
)

from onyx.apps.audit.logger import logger, get_model_register
from onyx.apps.audit.utils import get_changed_field_names


def is_registered(sender):
    """Check if a given model is registered to be
    audited.

    TODO this should probably be in the registry module.

    Args:
        sender: The model class to check

    Returns:
        True if registered or False if not"""
    return sender in get_model_register().keys()


def pre_save_callback(sender, instance, **kwargs):
    """Model 'pre save' callback, attaches a copy
    of the model before it was changed to the instance
    to be used later for logging.

    Args:
        sender: The sending model class
        instance: The instance of the model being saved
        **kwargs: Other passed keyword arguments"""
    if not is_registered(sender):
        return
    if hasattr(instance, 'id') and instance.id:
        instance._pre_save_instance = sender.objects.get(id=instance.id)


def post_save_callback(sender, instance, **kwargs):
    """Model 'post save' callback, checks and logs the model
    change if it matches the give rules for the model.

    Args:
        sender: The class of the saved model
        instance: The instance of the model class that has been
            saved.
        **kwargs: Additional passed keyword arguments."""
    if not is_registered(sender):
        return
    register_item = get_model_register()[sender]
    if hasattr(instance, '_pre_save_instance'):
        do_log = True
        pre_save_instance = instance._pre_save_instance
        changed_fields = get_changed_field_names(
            pre_save_instance,
            instance
        )

        # No point logging no changes
        if len(changed_fields) == 0:
            return

        # Check if any exclude/include fields present
        if register_item['only_fields']:
            do_log = any(
                field_name in register_item['only_fields']
                for field_name in changed_fields
            )
        elif register_item['exclude_fields']:
            do_log = not all(
                field_name in register_item['exclude_fields']
                for field_name in changed_fields
            )

        # Create log
        if do_log:
            logger.log_model_update(
                model=instance,
                model_before=instance._pre_save_instance
            )
    else:
        logger.log_model_create(
            model=instance
        )


def pre_delete_callback(sender, instance, **kwargs):
    """Model 'pre delete' signal handler, attaches a copy of
    the current model to this instance to identify the model
    by id after deletion.

    Args:
        sender: The model class sending the signal
        instance: The instance of the model being deleted.
        **kwargs: Additional passed keyword arguments."""
    if not is_registered(sender):
        return
    instance._pre_delete_instance = sender.objects.get(id=instance.id)


def post_delete_callback(sender, instance, **kwargs):
    """Model 'post delete' callback, logs model deletion using
    the information from pre_delete.

    Args:
        sender: The model class sending the signal
        instance: The instance of the model that was deleted.
        **kwargs: Additional passed keyword arguments"""
    if not is_registered(sender):
        return
    logger.log_model_delete(
        model=instance,
        model_id=instance._pre_delete_instance.id
    )


# Set up signals
pre_save.connect(pre_save_callback, weak=False)
post_save.connect(post_save_callback, weak=False)
pre_delete.connect(pre_delete_callback, weak=False)
post_delete.connect(post_delete_callback, weak=False)
