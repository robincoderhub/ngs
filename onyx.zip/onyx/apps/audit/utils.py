"""Audit app utilities"""


def get_changed_fields(model, model_two):
    """Compare two models and return what fields have
    been changed.

    Args:
        model: The first model instance to compare
        model_two: The second model instance to compare

    Returns:
        A list of model fields that have changed."""
    return list(
        filter(
            lambda field: getattr(model, field.name, None) != getattr(
                model_two,
                field.name,
                None
            ),
            model._meta.get_fields()
        )
    )


def get_changed_field_names(model, model_two):
    """Compare two models and return the field names of
    fields that have changed.

    Args:
        model: The first model instance to compare
        model_two: The second model instance to compare

    Returns:
        A list of model field names that have changed."""
    return [field.name for field in get_changed_fields(model, model_two)]
