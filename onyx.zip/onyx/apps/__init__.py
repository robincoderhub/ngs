"""Onyx's various wonderful sub apps"""
