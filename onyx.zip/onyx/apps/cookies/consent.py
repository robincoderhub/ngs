"""Cookie consent cookie reader/writer classes

TODO:
    Possibly rename this module or combine with core.py"""

import json
from dateutil import parser
from datetime import timedelta

from django.utils import timezone

from onyx.apps.cookies import app_settings
from onyx.apps.cookies.library import register


class CookieConsentReader(object):
    """A class for parsing the cookie consent cookie and
    checking relevant settings.

    Args:
        request: The incoming Django request object"""

    def __init__(self, request):
        self.request = request
        self.data = self._load_cookie_object()

    def is_cookie_set(self):
        """Check whether or not the cookie preferences
        cookie has been set.

        Returns:
            True if set, otherwise False"""
        return self.request.COOKIES.get(
            app_settings.COOKIE_CONSENT_NAME
        ) is not None

    def is_cookie_expired(self):
        """Check whether or not the cookie preferences
        cookie has expired.

        Returns:
            True if expired, false if not."""
        data = self.data
        return (
            not data
            or 'expires' not in data
            or parser.parse(data['expires']) < timezone.now()
        )

    def has_consented(self, group_selector):
        """Checks if user has consented to a particular
        cookie group.

        Args:
            group_selector: This will be a node selector string such
                as 'required.session'.

        Returns:
            True if has consented or False if not/cookie expired"""
        if not self.is_cookie_set() or self.is_cookie_expired():
            return False
        return group_selector in self.data['group_selectors']

    def get_consented_cookie_selectors(self):
        """Get a list of cookie group selectors that
        the user has consented to.

        Returns:
            A list of cookie group node selectors."""
        return self.data['group_selectors']

    def get_consented_cookie_nodes(self):
        """Get the CookieGroup nodes the user has consented
        to.

        Returns:
            A dict of CookieGroup nodes keyed by node selector."""
        selector_dict = register.get_tree().get_selector_dict()
        consented_to = {}
        for key, node in selector_dict.items():
            if self.has_consented(key):
                consented_to[key] = node
        return consented_to

    def _load_cookie_object(self):
        """Load cookie data from request.

        Returns:
            A dict containing the cookie data or None if not found."""
        raw_data = self.request.COOKIES.get(app_settings.COOKIE_CONSENT_NAME)
        if not raw_data:
            return None
        return json.loads(raw_data)


class CookieConsentWriter(object):
    """A class for writing cookie preferences to a cookie

    Args:
        response: The django response instance to modify."""

    def __init__(self, response):
        self.response = response

    def generate_consent_object(self, group_selectors):
        """Generate a dict containing cookie consent data.

        Args:
            group_selectors: The node selectors of the cookie groups
                the user has consented to.

        Returns:
            A dict containing the consent data and expiry
            information."""
        from django.utils import timezone
        return {
            'expires': str(
                timezone.now() + timedelta(
                    days=app_settings.COOKIE_CONSENT_EXPIRES
                )
            ),
            'group_selectors': group_selectors
        }

    def update_consent(self, group_selectors):
        """Update consent cookie to use passed selectors

        Args:
            group_selectors: The node selectors of the cookie groups
                the user has consented to."""
        self.response.set_cookie(
            app_settings.COOKIE_CONSENT_NAME,
            json.dumps(
                self.generate_consent_object(list(group_selectors))
            ),
            expires=timezone.now() + timezone.timedelta(
                days=app_settings.COOKIE_CONSENT_EXPIRES
            )
        )

    def clear_consent(self):
        """Delete cookie preferences cookie"""
        self.response.delete_cookie(app_settings.COOKIE_CONSENT_NAME)
