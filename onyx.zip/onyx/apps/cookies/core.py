"""Cookie consent group node classes

TODO:
    Consider renaming module to nodes.py or similar, or moving
    consent.py into here."""

from onyx.utils.nodes import NodeMixin, NodeTree


class CookieGroupTree(NodeTree):
    """CookieGroup node tree class"""

    def get_node_by_cookie_name(self, cookie_name):
        """Get a CookieGroupNode by a cookie name it contains

        Args:
            cookie_name: The cookie name to search for.

        Returns:
            The node or None if not found."""
        persist = {
            'found_node': None
        }

        def callback(callback_node, *args, persist, cookie_name):
            if callback_node.contains_cookie(cookie_name):
                persist['found_node'] = callback_node
                return True
            return callback_node
        self.walk_node_tree(callback, persist=persist, cookie_name=cookie_name)
        return persist['found_node']


class CookieGroupNode(NodeMixin):
    """A node representing a 'group' of cookies or cookie groups
    and the settings associated with them.

    Args:
        *args: Inherited args
        label: The human readable name of the group
        description: A human redable description of the group
        cookie_names: Optional, a list of cookie names this node contains
            this is not required as a group can contain other groups.
        required: Defaults to False, if True will set the cookie regardless of
            consent. Cookies essential to using the website such as session
            cookies should be required.
        node_tree_class: Optional, the class to use for child trees.
        **kwargs: Inherited keyword arguments."""

    def __init__(
        self, *args, label, description,
        cookie_names=None, required=False,
        node_tree_class=CookieGroupTree, **kwargs
    ):
        super().__init__(*args, node_tree_class=node_tree_class, **kwargs)
        self.label = label
        self.description = description
        self.required = required
        self.cookie_names = cookie_names or []

    def get_label(self):
        """Get human readable label of this node.

        Returns:
            A label string"""
        return self.label

    def get_description(self):
        """Get human readable description of this node.

        Returns:
            A description string."""
        return self.description

    def is_required(self):
        """Whether or not cookie group is required.

        Returns:
            True if required, False otherwise."""
        return self.required

    def get_cookie_names(self):
        """Get the cookie names this node contains.

        Returns:
            A list of cookie names."""
        return self.cookie_names

    def contains_cookie(self, cookie_name):
        """Checks whether this node contains a cookie with
        the given name.

        Args:
            cookie_name: The cookie name to check
        
        Returns:
            True if in group, False otherwise."""
        return cookie_name in self.get_cookie_names()
