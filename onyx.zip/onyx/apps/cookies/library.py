"""A register for the site's cookie node tree

TODO:
    - This file should be renamed register.py
    - The CookieGroupRegister class seems overkill, a global
        variable would also work."""

from onyx.apps.cookies import app_settings
from onyx.apps.cookies.core import CookieGroupTree, CookieGroupNode


class CookieGroupRegister(object):
    """Register to contain the cookie group tree

    Args:
        cookie_group_tree: The tree containing the site's cookie
            definitions."""
    def __init__(self, cookie_group_tree=None):
        self.cookie_tree = CookieGroupTree([])
        if cookie_group_tree:
            self.cookie_tree.merge_tree(cookie_group_tree)

    def get_tree(self):
        """Get the site's cookie group tree

        Returns:
            A CookieGroupTree object"""
        return self.cookie_tree


def convert_to_node_tree(definition_list):
    """Convert a list of dicts containing cookie group definitions
    into an actual node tree. This is used to convert the definitions
    in the settings.py file.

    Args:
        definition_list: A nested list of dicts containing cookie group
            definitions.
    Returns:
        A CookieGroupTree object"""
    node_tree = CookieGroupTree()
    for kwargs in definition_list:
        if 'node_children' in kwargs:
            kwargs['node_children'] = convert_to_node_tree(
                kwargs['node_children']
            )
        node_tree.append(
            CookieGroupNode(**kwargs)
        )
    return node_tree


register = CookieGroupRegister(
    convert_to_node_tree(
        app_settings.COOKIE_CONSENT_GROUPS
    )
)
"""Variable containing the global instance of the CookieGroupRegister"""
