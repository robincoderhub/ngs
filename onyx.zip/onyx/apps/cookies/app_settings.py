"""Settings for the cookies app and their defaults"""

from django.conf import settings


COOKIE_CONSENT_NAME = getattr(
    settings,
    'COOKIE_CONSENT_NAME',
    'onyx_cookie_consent'
)
"""Name of cookie consent preferences cookie"""


COOKIE_CONSENT_EXPIRES = getattr(settings, 'COOKIE_CONSENT_EXPIRES', 30)
"""Days after which consent will expires"""


COOKIE_CONSENT_GROUPS = getattr(settings, 'COOKIE_CONSENT_GROUPS', [])
"""A nested list of CookieGroupNode keyword arguments to register"""
