"""Cookie consent related views"""

from django.views.generic import View, TemplateView
from django.shortcuts import render
from django.contrib.sites.shortcuts import get_current_site
from django.middleware.csrf import get_token
from django.http import HttpResponseRedirect, JsonResponse
from django.conf import settings

from onyx.apps.cookies.library import register
from onyx.apps.cookies.consent import CookieConsentWriter


class CookieConsentView(View):
    """View that serves a double purpose, both as an ajax api for the
    js enabled cookie bar, and as a plain HTML page where non-js enabled
    users can set their cookie preferences."""

    def get(self, request):
        """Handle GET request, displays the non-js enabled
        backup view

        Args:
            request: The incoming request

        Returns:
            A Django response"""
        return render(
            request,
            'onyx/apps/cookies/consent-view.html',
            {
                'nodes': register.get_tree(),
            }
        )

    def post(self, request):
        """Handle POST data either from an AJAX request or from the non-js
        backup page, sets cookie preferences and redirects or returns a json
        response as required.

        Args:
            request: The incoming django request

        Returns:
            A django response object, either JSON or a redirect."""
        data = request.POST
        valid_selectors = register.get_tree().get_selector_dict()
        accepted_selectors = []
        if 'accept_all' in data and data['accept_all'] == '1':
            accepted_selectors = valid_selectors.keys()
        else:
            for selector, node in valid_selectors.items():
                if (
                    node.is_required()
                    or (
                        selector in data
                        and data[selector]
                        and data[selector] != '0'
                    )
                ):
                    accepted_selectors.append(selector)
        if 'ajax' in data:
            csrf_token = str(get_token(request))
            response = JsonResponse({
                'csrf_token': csrf_token
            })
            response.set_cookie(
                settings.CSRF_COOKIE_NAME,
                csrf_token
            )
        else:
            response = HttpResponseRedirect('/')
        writer = CookieConsentWriter(response)
        writer.update_consent(accepted_selectors)
        return response


class CookiePolicyView(TemplateView):
    """A view for displaying a boilerplate cookie policy."""

    template_name = 'onyx/apps/cookies/cookie-policy.html'
    """The path of the template to display"""

    def get_context_data(self, **kwargs):
        """Extends context data to include the site name
        and url.

        Args:
            **kwargs: The context data for the template

        Returns:
            The updated context data dict."""
        app_name = getattr(settings, 'APP_NAME', None)
        site = get_current_site(self.request)
        protocol = 'https' if self.request.is_secure() else 'http'
        site_url = f"{protocol}://{site.domain}"
        return {
            'APP_NAME': app_name,
            'SITE_URL': site_url
        }
