"""
# Cookie consent module

This module provides cookie consent controls to prevent
cookie that have not been explicitly approved from being set.


## Installation

Add the app to your INSTALLED_APPS setting

```
INSTALLED_APPS = [
    ...
    'onyx.apps.cookies',
    ...
]
```

Add the cookie consent middleware to your settings
```
MIDDLEWARE = [
    ...
    'onyx.apps.cookies.middleware.CookieConsentMiddleware',
    ...
]
```

Then somewhere in your main base.html template add the cookie
consent bar template tag
```
{% load onyx_cookies %}

{% cookie_consent_bar %}
```

This will display a bar along the bottom of the site where
users can accept cookies and/or manage what cookies they consent
to.

To complete installation configure your cookies in your settings.py file.
A basic installation with required cookies should look a bit like this:
```
COOKIE_CONSENT_GROUPS = [
    {
        'node_name': 'required',
        'label': 'Required Cookies',
        'description': 'Cookies that are required in order to use this site.',
        'required': True,
        'node_children': [
            {
                'node_name': 'session',
                'label': 'Session Cookies',
                'description': (
                    'Session cookies are required to keep you logged in'
                    + ' and store settings.'
                ),
                'required': True,
                'cookie_names': [
                    SESSION_COOKIE_NAME,
                    LANGUAGE_COOKIE_NAME
                ]
            },
            {
                'node_name': 'csrf',
                'label': 'CSRF Cookies',
                'description': (
                    'CSRF cookies are required to stop cross-site'
                    + ' scripting attacks (XSS).'
                ),
                'required': True,
                'cookie_names': [
                    CSRF_COOKIE_NAME
                ]
            }
        ]
    }
]
```

The options for each of these are the same kwargs as the
`onyx.apps.cookies.CookieGroupNode` class and will be initialised
when first fetched.

Cookies set as 'required' will be set regardless of consent as they
are considered essential for running the site."""

default_app_config = 'onyx.apps.cookies.config.CookiesConfig'
