"""Cookie consent middleware for filtering out non consented cookies"""

from django.http.cookie import SimpleCookie
from django.utils.deprecation import MiddlewareMixin
from django.conf import settings

from onyx.apps.cookies import app_settings
from onyx.apps.cookies.consent import CookieConsentReader
from onyx.apps.cookies.library import register


class CookieConsentCookie(SimpleCookie):
    """A Cookie class that filters out cookies that have
    not been consented to.

    Args:
        *args: Inherited arguments
        request: The Django request
        initial_values: Optional, the value pulled out of the default
            Cookie set.
        **kwargs: Inherited keyword arguments."""

    def __init__(self, *args, request, initial_values=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.request = request
        if initial_values:
            for morsel in initial_values:
                self[morsel.value] = morsel

    def values(self):
        """Get a list of cookie values, filtering out
        cookies that are not consented to.

        Returns:
            The filtered list of cookie values"""
        values = super().values()
        if len(values) == 0:
            return values
        reader = getattr(
            self.request,
            'cookie_consent',
            CookieConsentReader(self.request)
        )
        consented_cookies = reader.get_consented_cookie_nodes()
        cookie_valid = (
            reader.is_cookie_set()
            and not reader.is_cookie_expired()
        )
        # The middleware can set the CSRF required cookie after updating a
        # users consent
        allow_csrf = any(
            morsel.key == app_settings.COOKIE_CONSENT_NAME
            for morsel in values
        )
        tree = register.get_tree()

        def filter_out_cookies(morsel):
            if morsel.key == app_settings.COOKIE_CONSENT_NAME:
                return True
            if allow_csrf and morsel.key == settings.CSRF_COOKIE_NAME:
                return True
            if cookie_valid:
                for node in consented_cookies.values():
                    if node.contains_cookie(morsel.key):
                        return True
            group = tree.get_node_by_cookie_name(morsel.key)
            if group and group.is_required():
                return True
            return False
        return list(filter(filter_out_cookies, values))


class CookieConsentMiddleware(MiddlewareMixin):
    def modify_request(self, request):
        """Method to modify request to have cookie_consent
        member with cookie request details.

        Args:
            request: The incoming django request"""
        if not hasattr(request, 'cookie_consent'):
            request.cookie_consent = CookieConsentReader(request)

    def modify_response(self, request, response):
        """Method to modify response to filter out non consented
        cookies by replacing cookies with our custom CookieConsentCookie
        class.

        Args:
            request: The original request
            response: The response to modify"""
        if not isinstance(response.cookies, CookieConsentCookie):
            response.cookies = CookieConsentCookie(
                initial_values=response.cookies.values(),
                request=request
            )

    def process_request(self, request):
        """Processes incoming request

        Args:
            request: The incoming request"""
        self.modify_request(request)

    def process_response(self, request, response):
        """Processes outgoing response and returns
        it.

        Args:
            request: The original request
            response: The outgoing response

        Returns:
            A Django response object"""
        self.modify_request(request)
        self.modify_response(request, response)
        return response
