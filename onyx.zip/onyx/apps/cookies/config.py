"""Cookies App config classes"""

from onyx.config import AbstractOnyxConfig


class CookiesConfig(AbstractOnyxConfig):
    """Default cookies app config"""

    name = "onyx.apps.cookies"
    """The python path to the app"""

    verbose_name = "Onyx - Cookies"
    """The human readable name of the app"""

    label = "onyx_cookies"
    """The internal Django name of the app"""
