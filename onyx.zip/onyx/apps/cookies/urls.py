"""Cookie consent url patterns."""

from django.urls import path
from django.views.decorators.csrf import csrf_exempt

from onyx.apps.cookies import views

app_name = 'cookies'
urlpatterns = [
    path('', views.CookiePolicyView.as_view(), name='policy'),
    path(
        'cookie-consent/',
        csrf_exempt(
            views.CookieConsentView.as_view()
        ),
        name='consent'
    ),
]
