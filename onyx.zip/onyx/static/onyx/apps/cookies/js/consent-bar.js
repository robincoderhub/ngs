(function($) {
    var CookieConsentBar = function(element) {
        var self = this;
        
        this.constructor = function(element) {
            this.element = $(element);
            this.ajaxRequest = null;
            this.bindListeners();
        };
        
        this.bindListeners = function() {
            var el = this.getElement();
            el.on('submit', function(e) {
                e.preventDefault();
                return self.submitFormAjax();
            });
            el.find('button[type=submit][value=1]').on('click', function(e) {
                e.preventDefault();
                self.submitFormAjax(true);
            });
            el.find('.js-cookie-show-settings').on('click', function(e) {
                e.preventDefault();
                self.onShowSettingsClick();
            });
            el.find('.js-cookie-group').each(function(e) {
                var group = $(this);
                group.find('.cookie-consent-popup-group-label').on('click', function(e) {
                    if(e.target.tagName === 'INPUT') {
                        return;
                    }
                    group.toggleClass('-open');
                });
                group.find('.cookie-consent-popup-group-label input').on('change', function() {
                    group.find('input').prop('checked', this.checked);
                });
            });
        };
        
        this.submitFormAjax = function(acceptAll) {
            var data;
            if(this.ajaxRequest) {
                return;
            }
            if(acceptAll) {
                data = {
                    'accept_all' : 1,
                    'ajax' : 1
                }
            } else {
                data = this.getElement().serialize();
                data = data + (data ? '&' : '') + "ajax=1";
            }
            this.ajaxRequest = $.ajax(
                this.getElement().attr('action'),
                {
                    type : 'POST',
                    data : data,
                    success : function(response) {
                        self.ajaxRequest = null;
                        self.setSettingsVisible(false);
                        self.setVisible(false);
                        if (response.csrf_token) {
                            $('[name=csrfmiddlewaretoken]').val(response.csrf_token)
                        }
                    },
                    error : function(e) {
                        self.ajaxRequest = null;
                        error_message = "Could not set cookie consent preferences: " + e.status.toString() + " " + e.statusText;
                        alert(error_message);
                        throw Error(error_message);
                    }
                }
            )
        };
        
        this.onShowSettingsClick = function() {
            this.setSettingsVisible(!this.isSettingsVisible());
        };
        
        this.setVisible = function(visible) {
            this.getElement().toggleClass('-open', visible);
        };
        
        this.isVisible = function() {
            return this.getElement().hasClass('-open');
        };
        
        this.setSettingsVisible = function(visible) {
            this.getElement().toggleClass('-popup', visible);
        };
        
        this.isSettingsVisible = function() {
            return this.getElement().hasClass('-popup');
        };
        
        this.getElement = function() {
            return this.element;
        };
        
        this.constructor(element);
    };

    window.addEventListener('load', function() {
        var cookieBar = new CookieConsentBar($('.js-cookie-bar'));
        cookieBar.setVisible(true);
    });
})(jQueryCookieBar);
