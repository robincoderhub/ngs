const MENU_OPEN_CLASS = '-selected-parent';
const MENU_SUB_LEVEL_CLASS = 'sub-level';


class DashboardSearch {
    constructor(searchURL, element) {
        this.searchURL = searchURL;
        this.element = $(element);
        this.results = [];
        this.request = null;
        this.loading = false;
        this.inputTimeout = null;
        this.selectedItemIndex = -1;
        this.bindListeners();
    }
    
    bindListeners() {
        this.getElement().on('submit', this.onFormSubmit.bind(this));
        this.getInputElement().on('keyup', this.onInputKeyUp.bind(this));
        this.getInputElement().on('keydown', this.onInputKeyDown.bind(this));
        this.getInputElement().on('focus', this.onInputFocus.bind(this));
        $('body').on('click', this.onBodyClick.bind(this));
        $(this.onDocumentLoad.bind(this));
    }
    
    search(searchTerm) {
        this.cancelSearch();
        this.setLoading(true);
        $.ajax(this.getSearchURL(), {
            'type' : 'GET',
            'data' : {
                'search_term' : searchTerm
            },
            'success' : this.onRequestSuccess.bind(this),
            'error' : this.onRequestError.bind(this),
            'complete' : this.onRequestComplete.bind(this)
        })
    }
    
    cancelSearch() {
        if(this.request) {
            this.request.abort();
            this.request = null;
        }
    }
    
    updateSelectedItemIndex(index) {
        let itemList = this.getResultsElement().find('ul');
        let selectedItem = null;
        this.selectedItemIndex = index;
        
        itemList.find('li a').removeClass('-selected');
        
        if(index >= 0) {
            selectedItem = itemList.find('li a').eq(index);
            selectedItem.addClass('-selected');
        }
        
        // Keep selected item in view
        if(selectedItem && selectedItem.length > 0) {
            let boxTop = itemList.scrollTop();
            let boxBottom = boxTop + itemList.innerHeight();
            let itemTop = selectedItem[0].offsetTop;
            let itemBottom = itemTop + selectedItem.outerHeight();
            
            if(itemTop < boxTop) {
                itemList.scrollTop(boxTop - (boxTop - itemTop));
            } else if(itemBottom > boxBottom) {
                itemList.scrollTop(boxTop + (itemBottom - boxBottom));
            }
        } else {
            itemList.scrollTop(0);
        }
    }
    
    getSelectedItemIndex() {
        return this.selectedItemIndex;
    }
    
    renderResults() {
        let results = this.getResults();
        let resultEl = this.getResultsElement();
        let showResults = this.isFocused() && (this.isLoading() || this.getInputElement().val() !== '');
        
        if(showResults) {
            resultEl.addClass('-open');
        } else {
            resultEl.removeClass('-open');
            return;
        }
        
        if(this.isLoading()) {
            resultEl.html('<p>Loading...</p>');
            return;
        }
        
        if(this.getResults().length > 0) {
            let list = $('<ul />');
            for(let index in results) {
                let item = $('<li />');
                let link = $('<a />');
                link.text(results[index].label);
                link.attr('href', results[index].url);
                if(parseInt(index) === this.getSelectedItemIndex()) {
                    link.addClass('-selected');
                }
                item.append(link);
                list.append(item);
            }
            
            resultEl.html(list);
        } else {
            resultEl.html('<p>Nothing found!</p>');
        }
    }
    
    onFormSubmit(e) {
        e.preventDefault();
        let selectedResult = this.getResults()[this.getSelectedItemIndex()];
        if(selectedResult) {
            document.location = selectedResult.url;
        }
    }
    
    onDocumentLoad(e) {
        if(this.getInputElement().val()) {
            this.search(this.getInputElement().val());
        }
    }
    
    onRequestSuccess(response) {
        this.updateSelectedItemIndex(0);
        this.setResults(response.results);
    }
    
    onRequestError(e) {
        throw e;
    }
    
    onRequestComplete() {
        this.setLoading(false);
        this.request = null;
    }
    
    onInputKeyUp(e) {
        let self = this;
        let searchTerm = this.getInputElement().val();
        let ignoreKeys = [
            13, // Enter key
            37, // Left arrow
            38, // Up arrow
            39, // Right arrow
            40, // Down arrow
            16,  // Shift
            17, // Ctrl
            18 // Alt
        ];
        
        // Check for ignored keys
        if(ignoreKeys.indexOf(e.which) !== -1) {
            return;
        }
        
        // Clear any state
        this.setResults([]);
        clearTimeout(this.inputTimeout);
        this.cancelSearch();
        
        // Search is not blank
        if(searchTerm !== '') {
            this.setLoading(true);
            this.inputTimeout = setTimeout(function() {
                self.search(searchTerm);
            }, 300);
        } else {
            this.setLoading(false);
        }
    }
    
    onInputKeyDown(e) {
        if(e.which !== 38 && e.which !== 40) {
            return;
        }
        e.preventDefault();
        
        let newIndex = this.getSelectedItemIndex() + ((e.which === 38) ? -1 : 1);
        let maxIndex = this.getResults().length - 1;
        
        if(newIndex < -1) {
            newIndex = this.getResults().length - 1;
        } else if(newIndex > maxIndex) {
            newIndex = -1;
        }
        this.updateSelectedItemIndex(newIndex);
    }
    
    onInputFocus() {
        this.setFocused(true);
    }
    
    onBodyClick(e) {
        if(e.target == this.getElement()[0] || this.getElement().find(e.target).length > 0) {
            return;
        } else {
            this.setFocused(false);
        }
    }
    
    setFocused(focused) {
        this.focused = focused;
        this.renderResults();
    }
    
    isFocused() {
        return this.focused;
    }
    
    isResultsVisible() {
        return this.getResultsElement().hasClass('-open');
    }
    
    setLoading(loading) {
        this.loading = loading;
        this.renderResults();
    }
    
    setResults(results) {
        this.results = results;
        this.renderResults();
    }
    
    getResults() {
        return this.results;
    }
    
    isLoading() {
        return this.loading;
    }
    
    getSearchURL() {
        return this.searchURL;
    }
    
    getResultsElement() {
        return this.getElement().find('.base-header-search-results');
    }
    
    getInputElement() {
        return this.getElement().find('input[type=search]');
    }
    
    getElement() {
        return this.element;
    }
}


/**
 * Main dashboard interface controller
 */
class Dashboard {
    constructor(element) {
        this.element = $(element);
        this.sidebar = null;
        this.search = null;
        this.bindListeners();
        this.init();
    }
    
    init() {
        this.search = new DashboardSearch(
            SEARCH_URL,
            this.getElement().find('.base-header-search')
        );
    }
    
    bindListeners() {
        $('body').on('click', '.js-toggle-sidebar', this.toggleSidebar.bind(this));
        $('body').on('click', '.js-menu-go-back', this.onMenuBackbutton.bind(this));
        this.getElement()
            .find('.base-sidebar-menu > ul > li > a, .base-sidebar-menu > ul > li > span')
            .on('click', this.onTopLevelMenuClick.bind(this));
        $('.base-header-avatar-image').on('click', this.onThumbnailClick.bind(this));
        $('body').on('click', this.onBodyClick.bind(this));
    }
    
    onBodyClick(e) {
        // Close thumbnail menu on body click
        let thumbnailMenu = $('.base-header-avatar-menu');
        let thumbnail = $('.base-header-avatar-image');
        if(e.target == thumbnailMenu[0] || thumbnailMenu.find(e.target).length > 0
        || e.target == thumbnail[0] || thumbnail.find(e.target).length > 0) {
            return;
        } else {
            thumbnailMenu.removeClass('-open');
        }
    }
    
    onThumbnailClick() {
        $('.base-header-avatar-menu').toggleClass('-open');
    }
    
    toggleSidebar() {
        let el = this.getElement();
        let open = !el.hasClass('-show-sidebar');
        el.toggleClass('-show-sidebar', open);
        Cookies.set('show_sidebar', open);
    }
    
    selectMenu(menuElement) {
        let menu = this.getSidebarMenuElement();
        menu.find('.' + MENU_OPEN_CLASS).removeClass(MENU_OPEN_CLASS);
        if(menuElement) {
            menuElement.addClass(MENU_OPEN_CLASS);
            menu.addClass(MENU_SUB_LEVEL_CLASS);
        } else {
            menu.removeClass(MENU_SUB_LEVEL_CLASS);
        }
    }
    
    onTopLevelMenuClick(e) {
        let menuElement = $(e.target).parent();
        if(menuElement.find('> ul').length === 0) {
            return; // Do nowt, probably a top level link
        }
        this.selectMenu(menuElement);
    }
    
    onMenuBackbutton() {
        this.selectMenu(null);
    }
    
    getSidebarMenuElement() {
        return this.getElement().find('.base-sidebar-menu');
    }
    
    getElement() {
        return this.element;
    }
};

export default Dashboard;
