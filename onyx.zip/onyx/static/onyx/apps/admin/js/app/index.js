import Dashboard from 'admin/controllers/Dashboard';
import SearchList from 'admin/controllers/SearchList';
import Tabs from 'admin/controllers/Tabs';
import FormFieldController from 'admin/controllers/FormFieldController';


$(function() {
    $('.js-dashboard').each(function() {
        new Dashboard(this);
    });
    
    $('.js-search-list').each(function() {
        new SearchList(this);
    });
    
    $('.js-tabs').each(function() {
        new Tabs(this);
    });
    
    let multiform = document.getElementById('multi-form-view');
    if(multiform) {
        let formDirty = false;
        multiform.addEventListener('submit', function() {
            let elements = multiform.querySelectorAll('input[type="submit"], button');
            formDirty = false;
            for(let i = 0; i < elements.length; i += 1) {
                elements[i].disabled = true;
            }
        });
        let inputElements = multiform.querySelectorAll('input, textarea, select')
        for(let i = 0; i < inputElements.length; i += 1) {
            inputElements[i].addEventListener('change', function() {
                formDirty = true;
            });
            inputElements[i].addEventListener('keydown', function() {
                formDirty = true;
            });
        }
        window.onbeforeunload = function() {
            if(formDirty) {
                return "Are you sure you wish to leave this page? Changes you have made will be lost."
            }
        };
    }
    
    new FormFieldController();
});
