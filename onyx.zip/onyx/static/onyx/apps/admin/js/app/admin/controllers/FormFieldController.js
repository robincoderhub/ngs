/**
 * Class for apply focus/blur effects to all form elements
 */
class FormFieldController {
    constructor() {
        this.bindListeners();
        this.onStateChange();
        setTimeout(function() {
            document.body.classList.add('-form-fields-ready');
        }, 100);
    }
    
    bindListeners() {
        $('body').on(
            'focus',
            '.form-field input, .form-field textarea, .form-field select',
            this.onStateChange.bind(this)
        );
        $('body').on(
            'blur',
            '.form-field input, .form-field textarea',
            this.onStateChange.bind(this)
        )
        $('body').on(
            'change',
            '.form-field input, .form-field textarea',
            this.onStateChange.bind(this)
        )
        
        // Catches edges cases such as setting value with js
        setInterval(this.onStateChange.bind(this), 200);
    }
    
    updateInputLabels() {
        document.querySelectorAll('.form-field').forEach(function(formField) {
            let label = formField.querySelector('.form-field-label-wrapper');
            if(label) {
                let anyFocused = false;
                formField.querySelectorAll('input, textarea, select').forEach(function(inputEl) {
                    let focused = (inputEl.value !== '' || inputEl.tagName === 'SELECT' || document.activeElement === inputEl);
                    anyFocused = (focused) ? true : anyFocused;
                });
                if(anyFocused !== label.classList.contains('-focused')) {
                    label.classList.toggle('-focused', anyFocused);
                }
            }
        });
    }
    
    onStateChange() {
        this.updateInputLabels();
    }
};

export default FormFieldController;
