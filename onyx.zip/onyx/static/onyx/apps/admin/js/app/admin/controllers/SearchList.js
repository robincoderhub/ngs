/**
 * SearchList generic view controller
 */
class SearchList {
    constructor(element) {
        this.element = $(element);
        this.bindListeners();
    }
    
    bindListeners() {
        this.getElement().find('.button-filter').on(
            'click',
            this.onToggleFiltersClick.bind(this)
        );
    }
    
    onToggleFiltersClick() {
        this.toggleFilters();
    }
    
    toggleFilters(show) {
        show = typeof show === 'undefined' ? !this.isFiltersVisible() : show;
        this.setFiltersVisible(show);
    }
    
    setFiltersVisible(visible) {
        this.getFiltersElement().toggleClass('-active', visible);
    }
    
    isFiltersVisible() {
        return this.getFiltersElement().hasClass('-active');
    }
    
    getFiltersElement() {
        return this.getElement().find('.filters');
    }
    
    getElement() {
        return this.element;
    }
};

export default SearchList;
