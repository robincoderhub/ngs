/**
 * Tabs interface controller
 */
class Tabs {
    constructor(element) {
        this.element = $(element);
        this.bindListeners();
        this.initTabs();
    }
    
    bindListeners() {
        this.getElement().find('.tab-wrapper .button-tab').on('click', this.onTabClick.bind(this));
    }
    
    initTabs() {
        let activeTab = this.getTabElements().find('.-active');
        let tabs = this.getTabElements();
        for(let i = 0; i < tabs.length; i += 1) {
            let tab = $(tabs[i]);
            let tabBody = $('#' + tab.attr('for'));
            if(tabBody.find('.form-field.-has-errors').length > 0) {
                activeTab = tab;
                break;
            }
        }
        if(activeTab.length > 0) {
            this.selectTab(activeTab[0]);
        } else {
            this.selectTab(tabs[0]);
        }
    }
    
    selectTab(tabElement) {
        let tab = $(tabElement);
        let indicator = this.getIndicatorElement();
        
        // Update tab
        this.getTabElements().removeClass('-active');
        tab.addClass('-active');
        
        // Update indicator
        indicator.css('width', tab[0].offsetWidth.toString() + 'px');
        indicator.css('transform', `translateX(${tab[0].offsetLeft}px)`);
        
        // Update tab body
        this.getTabBodies().removeClass('-open');
        $('#' + tab.attr('for')).addClass('-open');
    }
    
    onTabClick(e) {
        this.selectTab(e.target);
    }
    
    getIndicatorElement() {
        return this.getElement().find('.tab-wrapper .tab-indicator');
    }
    
    getTabElements() {
        return this.getElement().find('.tab-wrapper .button-tab');
    }
    
    getTabBodies() {
        return this.getElement().find('.tab-body');
    }
    
    getElement() {
        return this.element;
    }
}

export default Tabs;
