/**
 * Sentry JS error handling set up
 */
if(window.Sentry && window.SENTRY_DSN) {
    Sentry.init({
        dsn: SENTRY_DSN,
        integrations: [
            new Sentry.Integrations.TryCatch(),
            new Sentry.Integrations.ReportingObserver()
        ],
        environment : window.APP_ENV || 'unknown',
        release: window.APP_RELEASE || 'unknown',
        beforeSend : function(event) {
            if (event.exception) {
                Sentry.showReportDialog();
            }
            return event;
        }
    });
    
    window.onerror = function (msg, url, line, colNo, error) {
        if(error && error instanceof Error) {
            Sentry.captureException(error);
        } else {
            var msg = msg + " - " + url + ":" + line + ':' + colNo;
            console.log(msg);
        }
    }
}
