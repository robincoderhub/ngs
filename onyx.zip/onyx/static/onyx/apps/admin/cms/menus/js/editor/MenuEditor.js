function ajax(method, url, options={}, data={}, files=[]) {
    return new Promise(function(resolve) {
        // Create full URL
        let requestURL = url;
        if(options) {
            let queryString = '';
            for(let key in options) {
                queryString += ((queryString === '') ? '' : '&');
                queryString += encodeURIComponent(key.toString()) + '=';
                queryString += encodeURIComponent(options[key].toString());
            }
            requestURL += (queryString !== '') ? '?' + queryString : '';
        }
        
        // Populate form data
        let formData = (data instanceof FormData) ? data : new FormData();
        if(!(data instanceof FormData)) {
            for(let key in data) {
                formData.append(key, data[key]);
            }
        }
        if(method !== 'GET') {
            let csrfToken = document.querySelector('[name=csrfmiddlewaretoken]').value;
            if(!csrfToken) {
                throw new Error('A CSRF token could not be found and is required for non GET requests.');
            }
            formData.append('csrfmiddlewaretoken', csrfToken);
        }
        if(files) {
            for(let i = 0; i < files.length; i += 1) {
                formData.append(
                    files[i][0],
                    files[i][1],
                    files[i][2],
                )
            }
        }
        
        // Execute request
        let xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if(this.readyState === 4) {
                resolve(xhttp);
            }
        };
        xhttp.ontimeout = function() {
            throw new Error('Ajax request timed out');
        };
        xhttp.open(method, requestURL, true);
        xhttp.send(formData);
    });
};


class MenuItem {
    constructor(label, name, itemType, weight, formData, children) {
        this.update(label, name, itemType, weight, formData, children);
    }
    
    getLabel() {
        return this.label;
    }
    
    setLabel(label) {
        this.label = label;
    }
    
    getName() {
        return this.name;
    }
    
    setName(name) {
        this.name = name;
    }
    
    getItemType() {
        return this.itemType;
    }
    
    setItemType(itemType) {
        this.itemType = itemType;
    }
    
    getWeight() {
        return this.weight;
    }
    
    setWeight(weight) {
        this.weight = weight;
    }
    
    getFormData() {
        return this.formData;
    }
    
    setFormData(formData) {
        this.formData = formData;
        this.getEditor().update();
    }
    
    getChildren() {
        return this.children;
    }
    
    toObject() {
        let children = this.getChildren();
        let object = {
            'label' : this.getLabel(),
            'name' : this.getName(),
            'item_type' : this.getItemType(),
            'weight' : this.getWeight(),
            'form_data' : this.getFormData(),
            'children' : []
        };
        for(let i = 0; i < children.length; i += 1) {
            object['children'].push(children[i].toObject());
        }
        return object;
    }
    
    update(label, name, itemType, weight, formData, children=[]) {
        this.label = label;
        this.name = name;
        this.itemType = itemType;
        this.weight = weight;
        this.formData = formData;
        this.children = children;
    }
    
    static fromObject(obj) {
        let children = [];
        for(let i = 0; i < obj['children'].length; i += 1) {
            children.push(MenuItem.fromObject(obj['children'][i]));
        }
        return new MenuItem(
            obj['label'],
            obj['name'],
            obj['item_type'],
            obj['weight'],
            obj['form_data'],
            children
        );
    }
};


class MenuPopup {
    constructor(formURL, editor, element, item, parentItem=null) {
        this.formURL = formURL;
        this.editor = editor;
        this.element = element.cloneNode(true);
        this.item = item || null;
        this.parentItem = parentItem;
        // A Promise 'resolve' function for when this popup has
        // completed its task
        this.completeResolve = null; 
    }
    
    displayForm(rawHTML, populate, formValues) {
        let self = this;
        return new Promise(function(resolve) {
            let contentEl = self.getContentElement();
            contentEl.innerHTML = rawHTML;
            
            // Add various buttons
            let addButton = function(label, callback) {
                let button = document.createElement('button');
                button.type = 'button';
                button.className = 'button';
                button.textContent = label;
                button.addEventListener('click', callback);
                contentEl.appendChild(button);
            };
            addButton('Save', self.submitForm.bind(self));
            if(self.item) {
                addButton('Delete', self.onDelete.bind(self));
            }
            addButton('Cancel', self.onCancelled.bind(self));
            
            // Populate form
            if(populate) {
                let formObj = {};
                if(self.item) {
                    let itemObj = self.item.toObject();
                    delete itemObj['children'];
                    formObj = itemObj['form_data'];
                    formObj['label'] = itemObj['label'];
                    formObj['name'] = itemObj['name'];
                    formObj['item_type'] = itemObj['item_type'];
                    formObj['weight'] = itemObj['weight'];
                } else {
                    let items = (self.parentItem) ? self.parentItem.getChildren() : self.getEditor().getMenuItems();
                    let highestWeight = -1;
                    for(let i = 0; i < items.length; i += 1) {
                        let itemWeight = parseInt(items[i].getWeight());
                        if(highestWeight < itemWeight) {
                            highestWeight = itemWeight;
                        }
                    }
                    formObj['weight'] = (highestWeight + 1);
                }
                if(formValues) {
                    formObj = {...formObj, ...formValues};
                }
                self.setFormValues(formObj);
            }
            
            // Fetch new form if item type changes
            contentEl.querySelector('[name=item_type]').addEventListener('change', function() {
                self.loadForm(true);
            });
            
            // Automagically change 'name' field based on label
            let labelField = contentEl.querySelector('[name=label]');
            let nameField = contentEl.querySelector('[name=name]');
            let updateNameField = function() {
                let label = labelField.value;
                let regex = new RegExp('[^a-zA-Z\_\\- ]')
                while(regex.test(label)) {
                    label = label.replace(regex, '');
                }
                regex = new RegExp('[- ]');
                while(regex.test(label)) {
                    label = label.replace(regex, '_')
                }
                nameField.value = label.toLowerCase();
            };
            labelField.addEventListener('change', updateNameField);
            labelField.addEventListener('keyup', updateNameField);
            labelField.addEventListener('keydown', updateNameField);
            
            // Load JS for form elements
            let scripts = contentEl.querySelectorAll('script');
            
            // Compile contained evaluated blocks and script tags
            let jsEvals = [];
            let jsScripts = [];
            let jsScriptLoaded = {};
            for(let i = 0; i < scripts.length; i += 1) {
                let script = scripts[i];
                if(script.src) {
                    jsScripts.push(script.src);
                    jsScriptLoaded[script.src] = false;
                } else if(script.innerHTML) {
                    jsEvals.push(script.innerHTML);
                }
            }
            
            // If we have scripts to load, load em, then run evals
            if(jsScripts.length > 0) {
                for(let i = 0; i < jsScripts.length; i += 1) {
                    let scriptSrc = jsScripts[i];
                    let scriptEl = document.createElement('script');
                    scriptEl.onload = function() {
                        jsScriptLoaded[scriptSrc] = true;
                        let allLoaded = true;
                        for(let key in jsScriptLoaded) {
                            if(jsScriptLoaded[key] !== true) {
                                allLoaded = false;
                                break;
                            }
                        }
                        if(allLoaded) {
                            for(let i = 0; i < jsEvals.length; i += 1) {
                                eval(jsEvals[i]);
                            }
                            resolve();
                        }
                    };
                    scriptEl.src = scriptSrc;
                    document.head.appendChild(scriptEl);
                }
            } else {
                for(let i = 0; i < jsEvals.length; i += 1) {
                    eval(jsEvals[i]);
                }
                resolve();
            }
        });
    }
    
    setFormValues(formValues) {
        let formElements = this.getContentElement().querySelectorAll('textarea, input, select');
        for(let i = 0; i < formElements.length; i += 1) {
            let formElement = formElements[i];
            if(formValues[formElement.name] === undefined || formElement.name === 'item_type') {
                continue;
            }
            if(formElement.tagName === 'INPUT') {
                if(formElement.type === 'radio') {
                    if(formValues[formElement.name].toString() === formElement.value) {
                        formElement.checked = true;
                    }
                } else if(formElement.type === 'checkbox') {
                    if(formValues[formElement.name].toString() === '1') {
                        formElement.checked = true;
                    }
                } else {
                    formElement.value = formValues[formElement.name];
                }
            } else {
                formElement.value = formValues[formElement.name];
            }
        }
        return formValues;
    }
    
    getFormValues() {
        let formEl = this.getContentElement();
        let formValues = {};
        let formElements = formEl.querySelectorAll('textarea, input, select');
        for(let i = 0; i < formElements.length; i += 1) {
            let formElement = formElements[i];
            if(formElement.tagName === 'INPUT' && formElement.type === 'radio') {
                if(formElement.checked) {
                    formValues[formElement.name] = formElement.value;
                }
            } else {
                formValues[formElement.name] = formElement.value;
            }
        }
        return formValues;
    }
    
    launch() {
        let self = this;
        return new Promise(function(resolve) {
            self.completeResolve = resolve;
            self.open();
        });
    }
    
    open() {
        let self = this;
        return new Promise(function(resolve) {
            document.body.appendChild(self.getElement());
            self.getElement().classList.add('-open');
            self.loadForm().then(function() {
                resolve();
            });
        });
    }
    
    close() {
        this.getElement().parentElement.removeChild(this.getElement());
        this.getElement().classList.remove('-open');
    }
    
    submitForm() {
        let self = this;
        let formData = new FormData();
        let formValues = this.getFormValues();
        for(let key in formValues) {
            formData.append(key, formValues[key]);
        }
        this.setLoading(true);
        ajax('POST', this.formURL, { 'item_type' : formValues['item_type'] }, formData).then(function(xhttp) {
            if(xhttp.status !== 200 && xhttp.status !== 400) {
                self.setLoading(false);
                throw new Error('A server error occurred.');
            }
            self.displayForm(xhttp.response).then(function() {
                self.setLoading(false);
                if(xhttp.status === 200) {
                    self.onFormValid(formValues);
                }
            });
        });
    }
    
    loadForm() {
        let self = this;
        return new Promise(function(resolve) {
            self.setLoading(true);
            let formValues = self.getFormValues();
            let options = {};
            if(formValues['item_type']) {
                options['item_type'] = formValues['item_type'];
            } else if(self.item) {
                options['item_type'] = self.item.getItemType();
            }
            ajax('GET', self.formURL, options).then(function(xhttp) {
                if(xhttp.status === 200) {
                    self.displayForm(xhttp.response, true, formValues).then(function() {
                        self.setLoading(false);
                        resolve();
                    });
                } else {
                    self.setLoading(false);
                    throw new Error('An error occurred loading popup');
                }
            });
        });
    }
    
    onFormValid(formValues) {
        let seperateVars = ['label', 'name', 'item_type', 'weight'];
        let item = this.item;
        
        let itemObject = {};
        for(let i = 0; i < seperateVars.length; i += 1) {
            let key = seperateVars[i];
            itemObject[key] = formValues[key];
            delete formValues[key];
        }
        itemObject['form_data'] = formValues;
        if(item) {
            item.update(
                itemObject['label'],
                itemObject['name'],
                itemObject['item_type'],
                parseInt(itemObject['weight']),
                itemObject['form_data'],
                item.children
            );
        } else {
            itemObject['children'] = [];
            item = MenuItem.fromObject(itemObject);
        }
        this.close();
        this.completeResolve(item);
    }
    
    onCancelled() {
        this.close();
        this.completeResolve(this.item);
    }
    
    onDelete() {
        if(!confirm('Are you sure you want to delete this menu item and any sub menus?')) {
            return;
        }
        this.close();
        this.completeResolve(null);
    }
    
    getElement() {
        return this.element;
    }
    
    getContentElement() {
        return this.getElement().querySelector('.omenu-popup-content');
    }
    
    getEditor() {
        return this.editor;
    }
    
    setLoading(loading) {
        this.getElement().classList.toggle('-loading', loading);
    }
    
    isLoading() {
        return this.getElement().classList.contains('-loading');
    }
    
    isOpen() {
        return this.getElement().classList.contains('-open');
    }
};


class MenuEditor {
    constructor(fieldName, element, apiURL) {
        this.element = element;
        this.menuItems = [];
        this.fieldName = fieldName;
        this.apiURL = apiURL;
        this.loadJSON();
        this.render();
    }
    
    render() {
        let storage = this.getMenuStorageElement();
        let menuItems = this.getMenuItems();
        menuItems.sort(function(a, b) {
            if(a.getWeight() > b.getWeight()) {
                return 1;
            } else if(a.getWeight() < b.getWeight()) {
                return -1;
            } else {
                return 0;
            }
        });
        storage.innerHTML = '';
        let menuRoot = document.createElement('ul');
        for(let i = 0; i < menuItems.length; i += 1) {
            menuRoot.appendChild(
                this.renderItem(menuItems[i])
            );
        }
        menuRoot.appendChild(this.renderFooterItem());
        storage.appendChild(menuRoot);
    }
    
    renderFooterItem(parent) {
        let self = this;
        let footerItem = document.createElement('li');
        let footerButton = document.createElement('button');
        footerButton.classList.add('omenu-footer-button');
        footerButton.textContent = 'Add Menu Item';
        footerButton.type = 'button';
        footerButton.addEventListener('click', function() {
            (parent) ? self.addItem(parent) : self.addItem();
        });
        footerItem.appendChild(footerButton);
        return footerItem;
    }
    
    renderItem(item) {
        let self = this;
        let listItem = document.createElement('li');
        
        let itemEl = document.createElement('div');
        let children = item.getChildren();
        itemEl.classList.add('omenu-editor-item');
        
        let itemTitle = document.createElement('b');
        itemTitle.classList.add('omenu-editor-item-title');
        itemTitle.textContent = item.getWeight().toString() + ": " + item.getLabel();
        itemEl.appendChild(itemTitle)
        
        let itemEditButton = document.createElement('button');
        itemEditButton.type = 'button';
        itemEditButton.classList.add('omenu-editor-item-button-edit');
        itemEditButton.textContent = 'Edit';
        itemEditButton.addEventListener('click', function() {
            self.editItem(item);
        });
        itemEl.appendChild(itemEditButton)
        
        if(item.children.length === 0) {
            let itemSubMenuButton = document.createElement('button');
            itemSubMenuButton.type = 'button';
            itemSubMenuButton.classList.add('omenu-editor-item-button-sub-item');
            itemSubMenuButton.textContent = 'Sub Menu';
            itemSubMenuButton.addEventListener('click', function() {
                self.addItem(item);
            });
            itemEl.appendChild(itemSubMenuButton);
        }
        
        listItem.appendChild(itemEl);
        
        if(children.length > 0) {
            let subList = document.createElement('ul');
            for(let i = 0; i < children.length; i += 1) {
                subList.appendChild(this.renderItem(children[i]));
            }
            subList.appendChild(this.renderFooterItem(item));
            listItem.appendChild(subList);
        }
        return listItem;
    }
    
    addItem(parentItem) {
        let self = this;
        new MenuPopup(
            this.apiURL,
            this,
            this.getPopupTemplateElement(),
            null,
            parentItem
        ).launch().then(function(item) {
            if(item === null) {
                return;
            }
            if(parentItem) {
                parentItem.children.push(item);
            } else {
                self.menuItems.push(item);
            }
            self.render();
            self.updateJSONValue();
        });
    }
    
    editItem(item) {
        let self = this;
        new MenuPopup(
            this.apiURL,
            this,
            this.getPopupTemplateElement(),
            item
        ).launch().then(function(itemResult) {
            if(itemResult === null) { // Delete item
                self.removeItem(item);
            }
            self.render();
            self.updateJSONValue();
        });
    }
    
    removeItem(item) {
        let recursiveRemove = function(itemArr) {
            for(let i = 0; i < itemArr.length; i += 1) {
                if(itemArr[i] === item) {
                    itemArr.splice(i, 1);
                    break;
                }
                if(itemArr[i].children.length > 0) {
                    recursiveRemove(itemArr[i].children);
                }
            }
        };
        recursiveRemove(this.menuItems);
        this.render();
        this.updateJSONValue();
    }
    
    getMenuItems() {
        return this.menuItems;
    }
    
    getElement() {
        return this.element;
    }
    
    getMenuStorageElement() {
        return this.getElement().querySelector('.omenu-editor');
    }
    
    getInputElement() {
        return this.getElement().parentElement.querySelector('[data-omenu-input]');
    }
    
    getPopupTemplateElement() {
        return this.getElement().querySelector('.omenu-popup-wrapper');
    }
    
    getMenu() {
        return this.menu;
    }
    
    loadJSON() {
        let inputValue = this.getInputElement().value;
        if(!inputValue) {
            return;
        }
        let rawItemArr = JSON.parse(inputValue);
        this.menuItems.splice(0, this.menuItems.length);
        for(let i = 0; i < rawItemArr.length; i += 1) {
            this.menuItems.push(MenuItem.fromObject(rawItemArr[i]));
        }
    }
    
    updateJSONValue() {
        let jsonArr = [];
        for(let i = 0; i < this.menuItems.length; i += 1) {
            jsonArr.push(this.menuItems[i].toObject());
        }
        this.getInputElement().value = JSON.stringify(jsonArr);
    }
};


function setUpMenuEditor(field_name, element, apiURL) {
    new MenuEditor(field_name, element, apiURL);
}


export {
    MenuEditor,
    setUpMenuEditor
};
