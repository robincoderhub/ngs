import { setUpMenuEditor } from 'editor/MenuEditor';

window.setUpMenuEditor = setUpMenuEditor;
