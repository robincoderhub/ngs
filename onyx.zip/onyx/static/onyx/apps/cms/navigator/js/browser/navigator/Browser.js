const CLIPBOARD_MODE = {
    'COPY' : 0,
    'CUT' : 1
};


function browserAlert(message) {
    // TODO would be nice to have a custom alert box
    alert(message);
}

// TODO would be nice to have custom prompt
// TODO would be nice to have custom confirm


function parentClassSearch(element, classNames) {
    if(typeof classNames === 'string') {
        classNames = [classNames];
    }
    while(element.parentElement) {
        let hasClasses = true;
        classNames.forEach(function(className){
            if(!element.parentElement.classList.contains(className)) {
                hasClasses = false;
            }
        });
        if(hasClasses) {
            return element.parentElement;
        }
        element = element.parentElement;
    }
    return null;
}


class BrowserAPIResponse {
    constructor(xhttp, code, message, data) {
        this.xhttp = xhttp;
        this.code = code;
        this.message = message;
        this.data = data;
    }
    
    getCode() {
        return this.code;
    }
    
    getData() {
        return this.data;
    }
    
    getMessage() {
        return this.message;
    }
    
    getXHTTPRequest() {
        return this.xhttp;
    }
    
    isSuccess() {
        let code = this.getCode();
        return (code >= 200 && code < 300);
    }
}


class BrowserAPI {
    constructor(apiURL, csrfToken, config) {
        config = config || {};
        this.apiURL = apiURL;
        this.csrfToken = csrfToken;
        this.defaultConfig = {
            'urlPaths' : true,
            'systemPaths' : true,
            'sources' : null
        };
        this.config = {...this.defaultConfig, ...config };
    }
    
    apiRequest(method, action, options, data, files) {
        let self = this;
        return new Promise(function(resolve, reject) {
            let xhttp = new XMLHttpRequest();
            let requestURL = self.getAPIURL() + action;
            let formData = new FormData()
            
            if(method !== 'GET') {
                formData.append('csrfmiddlewaretoken', self.csrfToken);
            }
            
            if(options) {
                let queryString = '';
                for(let key in options) {
                    queryString += ((queryString === '') ? '' : '&');
                    queryString += encodeURIComponent(key.toString()) + '=';
                    queryString += encodeURIComponent(options[key].toString());
                }
                requestURL += '?' + queryString;
            }
            
            if(data) {
                for(let key in data) {
                    formData.append(key, data[key]);
                }
            }
            
            if(files) {
                for(let i = 0; i < files.length; i += 1) {
                    formData.append(
                        files[i][0],
                        files[i][1],
                        files[i][2],
                    )
                }
            }
            
            xhttp.onreadystatechange = function() {
                if(this.readyState === 4) {
                    if(this.status >= 200 && this.status < 300) {
                        let parsedResponse = JSON.parse(this.response);
                        resolve(
                            new BrowserAPIResponse(
                                xhttp,
                                parsedResponse['code'],
                                parsedResponse['message'],
                                parsedResponse['data']
                            )
                        );
                    } else {
                        if(this.status === 413) {
                            reject(
                                new Error('File(s) specified were too large to upload. Contact site administrators to increase size limit.'),
                                xhttp
                            );
                        } else {
                            reject(
                                new Error('Failed to contact API.'),
                                xhttp
                            );
                        }
                    }
                }
            };
            
            xhttp.ontimeout = function() {
                reject(
                    new Error('API request timed out'),
                    xhttp
                );
            };
            
            xhttp.open(method, requestURL, true);
            xhttp.send(formData);
        });
    }
    
    createDirectory(path, name) {
        return this.apiRequest('POST', 'create_directory/', null, {
            'path' : path,
            'name' : name
        });
    }
    
    loadListing(path) {
        return this.apiRequest('GET', 'list/', {
            'path' : path,
            'urlPaths' : (this.getConfig('urlPaths') ? '1' : '0'),
            'systemPaths' : (this.getConfig('urlPaths') ? '1' : '0'),
            'sources' : (this.getConfig('sources') === null ? '' : this.getConfig('sources').join('|'))
        });
    }
    
    copy(pathArr, destPath) {
        return this.apiRequest('POST', 'copy/', null, {
            'paths' : pathArr.join('|'),
            'dest' : destPath
        });
    }
    
    cut(pathArr, destPath) {
        return this.apiRequest('POST', 'cut/', null, {
            'paths' : pathArr.join('|'),
            'dest' : destPath
        });
    }
    
    rename(path, name) {
        return this.apiRequest('POST', 'rename/', null, {
            'path' : path,
            'name' : name
        });
    }
    
    delete(pathArr) {
        return this.apiRequest('POST', 'delete/', null, {
            'paths' : pathArr.join('|')
        });
    }
    
    upload(path, fileArr) {
        return this.apiRequest(
            'POST',
            'upload/',
            null,
            {
                'path' : path
            },
            fileArr
        );
    }
    
    getAPIURL() {
        return this.apiURL;
    }
    
    getConfig(varName) {
        if(typeof varName === 'undefined') {
            return this.config;
        } else {
            return this.config[varName];
        }
    }
}


class BrowserPath {
    constructor(data) {
        this.name = data['name'];
        this.directory = data['is_directory'];
        this.file = data['is_file'];
        this.category = data['category'];
        this.hidden = data['is_hidden'];
        this.readOnly = data['is_read_only'];
        this.path = data['path'];
        this.url = data['url'];
        this.size = data['size'];
        this.sizeHuman = data['size_human'];
        this.lastModified = data['last_modified'];
        this.lastModifiedHuman = data['last_modified_human'];
        this.writable = data['writable'];
        this.source = data['source'];
        this.readable = data['readable'];
        this.protected = data['protected'];
    }
    
    getCategory() {
        return this.category;
    }
    
    isProtected() {
        return this.protected;
    }
    
    isDirectory() {
        return this.directory;
    }
    
    isFile() {
        return this.file;
    }
    
    isHidden() {
        return this.hidden;
    }
    
    isReadOnly() {
        return this.readOnly;
    }
    
    isWritable() {
        return this.writable;
    }
    
    isReadable() {
        return this.readable;
    }
    
    getName() {
        return this.name;
    }
    
    getSource() {
        return this.source;
    }
    
    getPath() {
        return this.path;
    }
    
    getSize() {
        return this.size;
    }
    
    getHumanSize() {
        return this.sizeHuman;
    }
    
    getLastModified() {
        return this.lastModified;
    }
    
    getHumanLastModified() {
        return this.lastModifiedHuman;
    }
    
    hasURL() {
        return this.url !== null;
    }
    
    getURL() {
        return this.url;
    }
    
    getFullURL() {
        if(!this.hasURL()) {
            return null;
        }
        return document.location.protocol + '//' + document.location.host + this.getURL();
    }
}


class BrowserContextMenu {
    constructor(browser, x, y) {
        this.browser = browser;
        this.element = document.createElement('div');
        this.x = x;
        this.y = y;
        this.onPageClickCallback = null;
        this.repositionInterval = null;
        this.render();
    }
    
    bindListeners() {
        this.unbindListeners();
        let callback = this.onPageClick.bind(this);
        this.onPageClickCallback = callback;
        document.body.addEventListener('click', this.onPageClickCallback);
        this.getElement().addEventListener('contextmenu', this.onContextMenu.bind(this));
    }
    
    unbindListeners() {
        if(this.onPageClickCallback) {
            document.body.removeEventListener('click', this.onPageClickCallback);
            this.onPageClickCallback = null;
        }
    }
    
    render() {
        let recentlyClicked = this.getBrowser().getRecentlySelectedPath();
        let selectedPaths = this.getBrowser().getSelectedPaths();
        let locationPath = this.getBrowser().getLocationPath();
        let clipboardPaths = this.getBrowser().getClipboardPaths();
        
        // Define menu item registry
        let menuItemRegistry = {
            'more_info' : ['More Info', this.onMoreInfoClick.bind(this)],
            'open_tab' : ['Open in new tab', this.onOpenInTabClick.bind(this)],
            'copy_url' : ['Copy URL', this.onCopyURLClick.bind(this)],
            'open_dir' : ['Open Directory', this.onOpenDirectoryClick.bind(this)],
            'create_dir' : ['Create Directory', this.onCreateDirectoryClick.bind(this)],
            'copy' : ['Copy', this.onCopyClick.bind(this)],
            'cut' : ['Cut', this.onCutClick.bind(this)],
            'rename' : ['Rename', this.onRenameClick.bind(this)],
            'paste' : ['Paste', this.onPasteClick.bind(this)],
            'delete' : ['Delete', this.onDeleteClick.bind(this)],
            'refresh' : ['Refresh', this.onRefreshClick.bind(this)],
            'no_actions' : ['No action', this.close.bind(this)]
        };
        let menuItems = [];
        let disabledItems = [];
        
        let viewWidth = Math.max(document.documentElement.clientWidth, window.innerWidth || 0);
        if(viewWidth <= 800 && selectedPaths.length > 0) {
            menuItems.push('more_info');
        }
        
        // Add relevant items
        if(recentlyClicked === null || !recentlyClicked.isDirectory()) {
            menuItems.push('create_dir');
        }
        menuItems.push('refresh');
        
        if(selectedPaths.length > 0) {
            if(recentlyClicked.isDirectory()) {
                menuItems.push('open_dir');
            } else {
                if(recentlyClicked.getURL()) {
                    menuItems.push('open_tab');
                    menuItems.push('copy_url');
                }
            }
            menuItems.push('copy');
            menuItems.push('cut');
            menuItems.push('delete');
            if(selectedPaths.length === 1) {
                menuItems.push('rename');
            }
        }
        if(clipboardPaths.length > 0) {
            menuItems.push('paste');
        }
        if(menuItems.length === 0) {
            menuItems.push('no_actions')
        }
        
        if(locationPath === null || !locationPath.isWritable()) {
            disabledItems.push('create_dir');
            disabledItems.push('paste');
            disabledItems.push('cut');
            disabledItems.push('delete');
            disabledItems.push('rename');
        }
        
        if(recentlyClicked !== null) {
            if(!recentlyClicked.isReadable()) {
                disabledItems.push('open_dir');
            }
            if(!recentlyClicked.isWritable()) {
                disabledItems.push('rename');
            }
        }
        
        /* Render menu */
        
        let menuEl = this.getElement();
        menuEl.classList.add('onavi-context');
        let listEl = document.createElement('ul');
        
        let createListItem = function(text, callback, disabled) {
            let listItem = document.createElement('li');
            listItem.textContent = text;
            if(disabled) {
                listItem.classList.add('disabled');
            } else {
                listItem.addEventListener('click', callback);
            }
            return listItem;
        }
        
        for(let key in menuItemRegistry) {
            if(menuItems.indexOf(key) !== -1) {
                listEl.appendChild(
                    createListItem(
                        menuItemRegistry[key][0],
                        menuItemRegistry[key][1],
                        (disabledItems.indexOf(key) !== -1)
                    )
                )
            }
        }
        
        menuEl.appendChild(listEl);
    }
    
    onMoreInfoClick() {
        this.close();
        this.getBrowser().showMobilePreview(true);
    }
    
    onPageClick(e) {
        if(parentClassSearch(e.target, 'onavi-context') !== null) {
            return;
        } else {
            this.close();
        }
    }
    
    onContextMenu(e) { // Right clicking the context menu
        e.preventDefault();
    }
    
    onOpenInTabClick() {
        this.close();
        let recentSelected = this.getBrowser().getRecentlySelectedPath();
        window.open(recentSelected.getFullURL());
    }
    
    onCopyURLClick() {
        this.close();
        let recentSelected = this.getBrowser().getRecentlySelectedPath();
        let url = recentSelected.getFullURL();
        let textarea = document.createElement('textarea');
        document.body.appendChild(textarea);
        textarea.value = url;
        textarea.select();
        textarea.setSelectionRange(0, 99999);
        document.execCommand('copy');
        document.body.removeChild(textarea);
    }
    
    onOpenDirectoryClick() {
        this.close();
        this.getBrowser().changeDirectory(
            this.getBrowser().getRecentlySelectedPath().getPath()
        )
    }
    
    onCreateDirectoryClick() {
        this.close();
        this.getBrowser().createDirectory();
    }
    
    onCopyClick() {
        this.close();
        this.getBrowser().copy();
    }
    
    onCutClick() {
        this.close();
        this.getBrowser().cut();
    }
    
    onRenameClick() {
        this.close();
        this.getBrowser().rename();
    }
    
    onPasteClick() {
        this.close();
        let recentClicked = this.getBrowser().getRecentlySelectedPath();
        if(recentClicked !== null && recentClicked.isDirectory()) {
            this.getBrowser().paste(recentClicked.getPath());
        } else {
            this.getBrowser().paste();
        }
    }
    
    onRefreshClick() {
        this.close();
        this.getBrowser().refresh();
    }
    
    onDeleteClick() {
        this.close();
        this.getBrowser().delete();
    }
    
    reposition() {
        let el = this.getElement();
        let x = this.x;
        let y = this.y;
        let width, height;
        if(el.getBoundingClientRect) {
            let boundingBox = el.getBoundingClientRect();
            width = boundingBox.width;
            height = boundingBox.height;
        } else {
            width = el.offsetWidth;
            height = el.offsetHeight;
        }
        let scrollX = window.scrollX;
        let scrollY = window.scrollY;
        let viewWidth = Math.max(document.documentElement.clientWidth, window.innerWidth || 0);
        let viewHeight = Math.max(document.documentElement.clientHeight, window.innerHeight || 0);
        if(x < 0 + scrollX) {
            x = scrollX;
        }
        if(x + width > viewWidth + scrollX) {
            x = x - ((x + width) - (viewWidth + scrollX))
        }
        
        if(y < 0 + scrollY) {
            y = scrollY;
        }
        
        if(y + height > viewHeight + scrollY) {
            y = y - ((y + height) - (viewHeight + scrollY));
        }
        
        el.style.left = x.toString() + 'px';
        el.style.top = y.toString() + 'px';
        
    }
    
    open() {
        let el = this.getElement();
        document.body.insertBefore(el, document.body.firstChild);
        el.style.left = this.x.toString() + 'px';
        el.style.top = this.y.toString() + 'px';
        this.bindListeners();
        this.reposition();
        this.repositionInterval = setInterval(this.reposition.bind(this), 10);
    }
    
    isOpen() {
        return document.body.contains(this.getElement());
    }
    
    close() {
        if(this.isOpen()) {
            this.unbindListeners();
            document.body.removeChild(this.getElement());
        }
        
        if(this.repositionInterval) {
            clearInterval(this.repositionInterval);
            this.repositionInterval = null;
        }
    }
    
    getElement() {
        return this.element;
    }
    
    getBrowser() {
        return this.browser;
    }
};


class BrowserUploadModal {
    constructor(browser, element) {
        this.browser = browser;
        this.element = element.cloneNode(true);
        this.bindListeners();
    }
    
    bindListeners() {
        let el = this.getElement();
        el.querySelector('.onavi-upload-upload').addEventListener('click', this.onUploadClick.bind(this));
        el.querySelector('.onavi-upload-cancel').addEventListener('click', this.onCancelClick.bind(this));
    }
    
    open() {
        let element = this.getElement();
        document.body.appendChild(element);
        this.reset();
        element.classList.add('-open');
    }
    
    isOpen() {
        return this.getElement().classList.contains('-open');
    }
    
    close() {
        let element = this.getElement();
        element.classList.remove('-open');
        document.body.removeChild(this.getElement());
    }
    
    reset() {
        this.getFileInput().value = '';
    }
    
    onUploadClick() {
        let self = this;
        let browser = this.getBrowser();
        let fileArr = [];
        let files = this.getFileInput().files;
        for(let i = 0; i < files.length; i += 1) {
            if(typeof files[i].size !== 'undefined') {
                if(files[i].size > 10000000) {
                    browserAlert('Files cannot be larger than 10mb, please contact support to upload larger files.');
                    return;
                }
            }
            fileArr.push(
                [
                    'file_' + i.toString(),
                    files[i],
                    files[i].name
                ]
            )
        }
        
        if(fileArr.length === 0) {
            browserAlert('Please select a file to upload');
            return;
        }
        this.setLoading(true);
        browser.getAPI().upload(
            browser.getLocation(),
            fileArr
        ).then(function(response) {
            self.setLoading(false);
            if(!response.isSuccess()) {
                browserAlert(response.getMessage());
                return;
            }
            browser.refresh();
            self.close();
        })
        .catch(function(e) {
            self.setLoading(false);
            browserAlert((e.message) ? e.message : e);
            return;
        });
    }
    
    setLoading(loading) {
        this.getElement().classList.toggle('-loading', loading);
    }
    
    isLoading() {
        return this.getElement().classList.contains('-loading');
    }
    
    onCancelClick() {
        this.close();
    }
    
    getFileInput() {
        return this.getElement().querySelector('input[type=file]');
    }
    
    getElement() {
        return this.element;
    }
    
    getBrowser() {
        return this.browser;
    }
};


class BrowserPreviewArea {
    constructor(browser, element) {
        this.browser = browser;
        this.element = element;
        this.render();
    }
    
    render() {
        let browser = this.getBrowser();
        let selectedPaths = browser.getSelectedPaths();
        let element = this.getElement();
        
        element.innerHTML = '';
        
        let detailsEl = document.createElement('div');
        detailsEl.classList.add('onavi-preview-details');
        
        let mobilePreviewButton = document.createElement('button');
        mobilePreviewButton.classList.add('onavi-preview-cancel');
        mobilePreviewButton.type = 'button';
        mobilePreviewButton.textContent = 'Back to files';
        mobilePreviewButton.addEventListener('click', this.onMobilePreviewCancelClick.bind(this));
        detailsEl.appendChild(mobilePreviewButton);
        
        if(selectedPaths.length === 0) {
            element.appendChild(detailsEl);
            return;
        }
        
        let previewSrc;
        let previewURL;
        let title = '';
        let stats = {};
        let selectText;
        let imgURLRoot = browser.getStaticURL() + 'onyx/apps/cms/navigator/img/preview';
        
        if(selectedPaths.length > 1) {
            previewSrc = imgURLRoot + '/multiple.svg';
            title = selectedPaths.length.toString() + ' items selected';
            selectText = 'Select items';
        } else {
            let selectedPath = selectedPaths[0];
            
            title = selectedPath.getName();
            if(selectedPath.getCategory() === 'image' && selectedPath.getFullURL()) {
                previewSrc = selectedPath.getFullURL();
            } else {
                previewSrc = imgURLRoot + '/' + selectedPath.getCategory() + '.svg';
            }
            
            if(selectedPath.getFullURL() && !selectedPath.isDirectory()) {
                previewURL = selectedPath.getFullURL();
            }
            
            stats['Type'] = selectedPath.getCategory();
            if(selectedPath.getSize()) {
                stats['Size'] = selectedPath.getHumanSize();
            }
            
            if(selectedPath.getLastModified()) {
                stats['Last Modified'] = selectedPath.getHumanLastModified();
            }
            
            if(selectedPath.isReadOnly()) {
                stats['Read Only'] = 'Yes';
            }
            
            if(selectedPath.isProtected()) {
                stats['Protected'] = 'Protected';
            }
            
            if(selectedPath.isDirectory()) {
                selectText = 'Select directory';
            } else {
                selectText = 'Select file';
            }
        }
        
        let previewEl;
        if(previewURL) {
            previewEl = document.createElement('a');
            previewEl.title = 'Click to open';
            previewEl.target = '_blank';
            previewEl.href = previewURL;
        } else {
            previewEl = document.createElement('div');
        }
        previewEl.classList.add('onavi-preview-pane');
        let previewImg = document.createElement('img');
        previewImg.src = previewSrc;
        previewEl.appendChild(previewImg);
        detailsEl.appendChild(previewEl);
        
        let titleEl = document.createElement('h2');
        titleEl.textContent = title;
        detailsEl.appendChild(titleEl);
        
        let statTable = document.createElement('table');
        let stateTBody = document.createElement('tbody');
        statTable.appendChild(stateTBody);
        for(let key in stats) {
            let row = document.createElement('tr');
            
            let cellTitle = document.createElement('td');
            cellTitle.textContent = key;
            row.appendChild(cellTitle);
            
            let cellValue = document.createElement('tr');
            cellValue.textContent = stats[key];
            row.appendChild(cellValue);
            
            stateTBody.appendChild(row);
        }
        detailsEl.appendChild(statTable);
        
        if(this.getBrowser().getConfig('selectMode')) {
            let selectButton = document.createElement('button');
            selectButton.textContent = selectText;
            selectButton.addEventListener(
                'click',
                function() {
                    browser.choosePaths();
                }
            );
            detailsEl.appendChild(selectButton);
        }
        
        element.appendChild(detailsEl);
    }
    
    onMobilePreviewCancelClick() {
        this.getBrowser().showMobilePreview(false);
    }
    
    getBrowser() {
        return this.browser;
    }
    
    getElement() {
        return this.element;
    }
};


/**
 * Main file browser class
 */
class Browser {
    constructor(element, api, config, staticURL) {
        this.defaultConfig = {
            'selectMode' : false, // For selecting a path
            'selectCallback' : null, // The callback for handling the path once selected
            'selectMax' : null, // Maximum number of paths allowed to select
            'pageMode' : false // Page mode is for the resource browser mode, for a non-closable 'in page' browser
        };
        this.config = {...this.defaultConfig, ...config};
        this.api = api;
        this.staticURL = staticURL;
        this.disabled = false;
        
        this.element = (this.config['pageMode']) ? element : element.cloneNode(true);
        this.element.classList.add('-bound');
        
        this.contextMenu = null;
        
        this.shiftPressed = false;
        this.shiftAnchorPath = null;
        
        this.location = '/';
        this.locationPath = null;
        
        this.selectedPaths = [];
        this.selectedPathStamp = 0;
        
        this.clipboardMode = null;
        this.clipboardPaths = [];
        
        this.safetyWarningPlayed = false;
        
        this.pathList = [];
        this.pathListOrder = 'name';
        
        this.bindings = [
            ['.onavi-header-button.-close', 'click', this.onCloseClick.bind(this)],
            ['.onavi-header-button.-back', 'click', this.onBackClick.bind(this)],
            ['.onavi-header-button.-refresh', 'click', this.onRefreshClick.bind(this)],
            ['.onavi-header-button.-home', 'click', this.onHomeClick.bind(this)],
            ['.onavi-header-button.-upload', 'click', this.onUploadClick.bind(this)],
            ['.onavi-footer-select', 'click', this.onSelectClick.bind(this)],
            ['.onavi-footer-cancel', 'click', this.onCancelClick.bind(this)],
            ['.onavi-pane', 'click', this.onPaneClick.bind(this)],
            ['.onavi-pane', 'contextmenu', this.onContextMenu.bind(this)],
            [[document.body], 'keydown', this.onBodyKeyDown.bind(this)],
            [[document.body], 'keyup', this.onBodyKeyUp.bind(this)]
        ];
        
        this.previewArea = new BrowserPreviewArea(this, this.element.querySelector('.onavi-preview'));
        this.uploadModal = new BrowserUploadModal(this, this.element.querySelector('.onavi-upload'));
    }
    
    open() {
        let pageMode = this.getConfig('pageMode');
        let selectMode = this.getConfig('selectMode');
        
        if(selectMode) {
            this.getElement().classList.add('-select-mode');
        }
        
        if(pageMode) {
            this.getElement().classList.add('-page-mode');
        }
        
        this.bindListeners();
        this.getElement().classList.add('-open');
        this.refresh();
        if(!pageMode) {
            document.body.insertBefore(this.getElement(), document.body.firstChild);
        }
    }
    
    isOpen() {
        return this.getElement().classList.contains('-open');
    }
    
    close() {
        if(!this.getConfig('pageMode')) {
            document.body.removeChild(this.getElement());
        }
        this.unbindListeners();
        this.getElement().classList.remove('-open');
        this.getElement().classList.remove('-page-mode');
        this.getElement().classList.remove('-select-mode');
        
        if(this.getUploadModal().isOpen()) {
            this.getUploadModal().close();
        }
    }
    
    bindListeners(bind) {
        bind = (bind === false) ? false : true;
        for(let i = 0; i < this.bindings.length; i += 1) {
            let elements = this.bindings[i][0];
            let event = this.bindings[i][1];
            let callback = this.bindings[i][2];
            if(typeof elements === 'string') {
                elements = this.getElement().querySelectorAll(elements);
            }
            for(let i2 = 0; i2 < elements.length; i2 += 1) {
                if(bind) {
                    elements[i2].addEventListener(event, callback);
                } else{
                    elements[i2].removeEventListener(event, callback);
                }
            }
        }
    }
    
    unbindListeners() {
        this.bindListeners(false);
    }
    
    safetyWarning() {
        let self = this;
        return new Promise(function(resolve) {
            if(self.safetyWarningPlayed) {
                resolve(true);
            } else {
                if(!confirm('Cutting, moving or renaming files can break links, are you sure?')) {
                    resolve(false);
                    return;
                }
                self.safetyWarningPlayed = true;
                resolve(true);
            }
        });
    }
    
    changeDirectory(pathString) {
        let self = this;
        return new Promise(function(resolve, reject) {
            self.clearSelectedPaths();
            self.getAPI().loadListing(pathString)
                .then(function(response) {
                    if(!response.isSuccess()) {
                        browserAlert(response.getMessage());
                        reject(new Error(response.getMessage()));
                        return;
                    }
                    let paths = [];
                    let data = response.getData();
                    self.locationPath = (data['dir']) ? new BrowserPath(data['dir']) : null;
                    self.location = (self.locationPath) ? self.locationPath.getPath() : pathString;
                    self.getElement().querySelector('.onavi-header-path').textContent = self.location;
                    for(let i = 0; i < data['paths'].length; i += 1) {
                        paths.push(
                            new BrowserPath(data['paths'][i])
                        );
                    }
                    self.pathList = paths;
                    self.render();
                    resolve(response);
                })
                .catch(function(e) {
                    browserAlert(e.message);
                    reject(e);
                });
        });
    }
    
    moveSelectedToClipboard(mode) {
        let selectedPaths = this.getSelectedPaths();
        for(let i = 0; i < selectedPaths.length; i += 1) {
            let selectedPath = selectedPaths[i];
            let pathType = (selectedPath.isDirectory()) ? 'directory' : 'file';
            if(mode === CLIPBOARD_MODE.CUT && selectedPath.isReadOnly()) {
                browserAlert(selectedPath.getName() + ' is a read-only ' + pathType + ' and cannot be cut.');
                return;
            }
            if(!selectedPath.isReadable()) {
                browserAlert("You do not have permission to view " + selectedPath.getName() + ' and cannot cut or copy it.');
                return;
            }
        }
        this.clipboardMode = mode;
        this.clipboardPaths = this.selectedPaths.slice();
    }
    
    choosePaths(pathList) {
        pathList = pathList || this.getSelectedPaths();
        let selectMode = this.getConfig('selectMode');
        let selectMax = this.getConfig('selectMax');
        let selectCallback = this.getConfig('selectCallback');
        if(!selectMode) {
            throw new Error('Browser is not in selectMode but choosePaths was called.');
        }
        if(pathList.length === 0) {
            browserAlert('You must select a file.');
            return;
        }
        if(selectMax !== null && pathList.length > selectMax) {
            browserAlert('You cannot select more than ' + ((selectMax === 1) ? 'one' : selectMax.toString()) + ' file.');
            return;
        }
        if(selectCallback) {
            selectCallback(pathList);
        } else {
            throw new Error('No select callback was specified.');
        }
        this.close();
    }
    
    createDirectory() {
        let self = this;
        return new Promise(function(resolve, reject) {
            let currentPath = self.getLocationPath();
            if(currentPath === null || !currentPath.isWritable()) {
                let msg = 'Directory is read-only, cannot create directory.';
                browserAlert(msg);
                resolve(false, msg);
                return;
            }
            let directoryName = prompt('New directory name', 'empty_folder');
            
            if(directoryName === null) { // Cancelled
                resolve(false, 'No directory name provided.');
                return;
            }
            
            self.getAPI().createDirectory(
                currentPath.getPath(),
                directoryName
            )
            .then(function(response) {
                if(response.isSuccess()) {
                    self.refresh();
                    resolve(true, 'Directory created');
                } else {
                    browserAlert(response.getMessage());
                    resolve(false, response.getMessage());
                }
            })
            .catch(function(e) {
                browserAlert((e.message) ? e.message : e);
                reject(e);
            });
        });
    }
    
    copy() { // A Promise for consistency
        let self = this;
        return new Promise(function(resolve) {
            self.moveSelectedToClipboard(CLIPBOARD_MODE.COPY);
            resolve(true, 'Copied to clipboard');
        });
    }
    
    cut() {
        let self = this;
        return new Promise(function(resolve) {
            self.safetyWarning().then(function(agreed) {
                if(agreed) {
                    self.moveSelectedToClipboard(CLIPBOARD_MODE.CUT)
                    resolve(false, "Cancelled cut operation");
                }
                resolve(true, "Cut to clipboard");
            });
        });
    }
    
    rename() {
        let self = this;
        return new Promise(function(resolve, reject) {
            self.safetyWarning().then(function(agreed) {
                if(!agreed) {
                    resolve(false, 'Cancelled operation');
                    return;
                }
                
                let recentlySelected = self.getRecentlySelectedPath();
                let newName = prompt(
                    'Rename this ' + ((recentlySelected.isDirectory()) ? 'directory' : 'file') +': ',
                    recentlySelected.getName()
                );
                
                if(newName === null) {
                    resolve(false, 'Cancelled operation.')
                    return;
                }
                
                self.getAPI().rename(
                    recentlySelected.getPath(),
                    newName
                )
                .then(function(response) {
                    if(response.isSuccess()) {
                        self.refresh();
                        resolve(true, 'Renamed successfully.');
                    } else {
                        browserAlert(response.getMessage());
                        resolve(false, response.getMessage());
                    }
                })
                .catch(function(e) {
                    browserAlert((e.message) ? e.message : e);
                    reject(e);
                });
            });
        });
    }
    
    delete() {
        let self = this;
        return new Promise(function(resolve, reject) {
            self.safetyWarning().then(function(agreed) {
                if(!agreed) {
                    resolve(false, 'Cancelled operation');
                    return;
                }
                
                let selectedPaths = self.getSelectedPaths();
                let pathArr = [];
                for(let i = 0; i < selectedPaths.length; i += 1) {
                    if(!selectedPaths[i].isWritable()) {
                        let msg = selectedPaths[i].getName() + ' is not writable and cannot be deleted.';
                        browserAlert(msg);
                        resolve(false, msg);
                        return;
                    }
                    pathArr.push(selectedPaths[i].getPath());
                }
                
                let confirmMsg = 'Are you sure you want to delete ';
                if(selectedPaths.length > 1) {
                    confirmMsg += 'these ' + selectedPaths.length.toString() + ' items?';
                } else {
                    confirmMsg += '"' + selectedPaths[0].getName() +'"';
                    if(selectedPaths[0].isDirectory()) {
                        confirmMsg += ' and all its contents?';
                    } else {
                        confirmMsg += '?';
                    }
                }
                confirmMsg += ' This operation is permanent and irreversible.';
                
                if(!confirm(confirmMsg)) {
                    resolve(false, 'Cancelled operation');
                    return;
                }
                
                self.getAPI().delete(
                    pathArr
                )
                .then(function(response) {
                    if(response.isSuccess()) {
                        self.refresh();
                        resolve(true, 'Item(s) deleted.');
                    } else {
                        browserAlert(response.getMessage());
                        resolve(false, response.getMessage());
                    }
                })
                .catch(function(e) {
                    browserAlert((e.message) ? e.message : e);
                    reject(e);
                });
            });
        });
    }
    
    paste(path) {
        let self = this;
        return new Promise(function(resolve, reject) {
            let onError = function(message) {
                browserAlert(message);
                resolve(false, message);
            }
            
            path = path || self.getLocationPath();
            if(!path.isWritable()) {
                onError('This directory is not writable, you cannot paste to it.');
                return;
            }
            
            let clipboard = self.getClipboardPaths();
            if(clipboard.length === 0) {
                onError('Nothing in your clipboard to paste.');
                return;
            }
            
            let pathArr = [];
            for(let i = 0; i < clipboard.length; i += 1) {
                pathArr.push(clipboard[i].getPath());
            }
            
            self.getAPI()[self.getClipboardMode() === CLIPBOARD_MODE.CUT ? 'cut' : 'copy'](
                pathArr,
                path.getPath()
            )
            .then(function(response) {
                if(response.isSuccess()) {
                    self.refresh();
                    self.clipboardPaths.splice(0, self.clipboardPaths.length);
                    resolve(true, 'Pasted successfully.');
                } else {
                    browserAlert(response.getMessage());
                    resolve(false, response.getMessage());
                }
            })
            .catch(function(e) {
                browserAlert((e.message) ? e.message : e);
                reject(e);
            });
        });
    }
    
    refresh() {
        return this.changeDirectory(
            this.getLocation()
        );
    }
    
    render() {
        let pane = this.getElement().querySelector('.onavi-pane');
        pane.innerHTML = '';
        
        // Create table
        let table = document.createElement('table');
        table.classList.add('onavi-file-table');
        
        // Create thead
        let thead = document.createElement('thead');
        let theadRow = document.createElement('tr');
        let headings = ['Filename', 'Size', 'Last Modified'];
        headings.forEach(function(heading) {
            let th = document.createElement('th');
            th.textContent = heading;
            theadRow.appendChild(th);
        });
        let dirOptionsCell = document.createElement('th');
        dirOptionsCell.classList.add('onavi-file-item-options');
        let dirOptionsButton = document.createElement('button');
        dirOptionsButton.type = 'button';
        dirOptionsButton.textContent = 'Options';
        dirOptionsButton.classList.add('onavi-file-item-options-button');
        dirOptionsCell.appendChild(dirOptionsButton);
        theadRow.appendChild(dirOptionsCell);
        thead.appendChild(theadRow);
        
        // Create tbody
        let tbody = document.createElement('tbody');
        let paths = this.orderPaths(this.getPathList().slice());
        let selectedPaths = this.getSelectedPaths();
        let locationPath = this.getLocationPath();
        
        // Cycle through paths and display
        for(let i = 0; i < paths.length; i += 1) {
            
            // Create row
            let path = paths[i];
            let pathRow = document.createElement('tr');
            pathRow.setAttribute('data-location', path.getPath());
            pathRow.classList.add('onavi-file-item');
            pathRow.classList.add('onavi-file-item-' + path.getCategory());
            selectedPaths.forEach(function(selectedPath) {
                if(selectedPath.getPath() === path.getPath()) {
                    pathRow.classList.add('-selected');
                }
            });
            
            // Add name cell
            let pathNameCell = document.createElement('td');
            let pathNameIcon = document.createElement('i');
            if(path.isDirectory()) {
                pathNameIcon.classList.add('fas', 'fa-folder');
                pathNameCell.appendChild(pathNameIcon);
            } else {
                pathNameIcon.classList.add('fas', 'fa-file');
                pathNameCell.appendChild(pathNameIcon);
            }
            let pathNameText = document.createElement('span');
            pathNameText.textContent = (locationPath !== null && path.getPath() === locationPath.getPath()) ? '..' : path.getName();
            pathNameCell.appendChild(pathNameText)
            pathRow.appendChild(pathNameCell);
            
            // Add size cell
            let pathSizeCell = document.createElement('td');
            if(path.getHumanSize() === null) {
                pathSizeCell.textContent = '';
            } else {
                pathSizeCell.textContent = path.getHumanSize();
            }
            pathRow.appendChild(pathSizeCell);
            
            // Add modified cell
            let pathModifiedCell = document.createElement('td');
            pathModifiedCell.textContent = path.getHumanLastModified();
            pathRow.appendChild(pathModifiedCell);
            
            // Add options cell
            let pathOptionsCell = document.createElement('td');
            pathOptionsCell.classList.add('onavi-file-item-options');
            let pathOptionsButton = document.createElement('button');
            pathOptionsButton.type = 'button';
            pathOptionsButton.textContent = 'Options';
            pathOptionsButton.classList.add('onavi-file-item-options-button');
            pathOptionsCell.appendChild(pathOptionsButton);
            pathRow.appendChild(pathOptionsCell);
            
            // Add row to body
            tbody.appendChild(pathRow);
        }
        
        // Add head/body
        table.appendChild(thead);
        table.appendChild(tbody);
        
        // Add to pane
        pane.appendChild(table);
    }
    
    onCloseClick() {
        this.close();
    }
    
    onSelectClick() {
        this.choosePaths(
            this.getSelectedPaths()
        );
    }
    
    onCancelClick() {
        this.close();
    }
    
    onContextMenu(e) {
        let fileItem = parentClassSearch(e.target, 'onavi-file-item');
        if(fileItem) {
            let fileItemPath = this.getPath(
                fileItem.getAttribute('data-location')
            );
            if(this.isSelectedPath(fileItemPath)) {
                this.removeSelectedPath(fileItemPath);
                this.addSelectedPath(fileItemPath);
            } else {
                this.clearSelectedPaths();
                this.addSelectedPath(fileItemPath);
            }
        } else {
            this.clearSelectedPaths();
        }
        if(this.contextMenu !== null) {
            this.contextMenu.close();
        }
        this.contextMenu = new BrowserContextMenu(this, e.pageX, e.pageY);
        this.contextMenu.open();
        this.render();
        e.preventDefault();
    }
    
    onPaneClick(e) {
        let fileItem = parentClassSearch(e.target, 'onavi-file-item');
        let optionButtonClicked = (e.target.classList.contains('onavi-file-item-options') || parentClassSearch(e.target, 'onavi-file-item-options'));
        let selectedPaths = this.getSelectedPaths();
        let recentSelected = this.getRecentlySelectedPath();
        let ctrlKeyPressed = e.ctrlKey;
        let shiftPressed = this.isShiftPressed();
        
        if(optionButtonClicked) {
            this.onContextMenu(e);
            e.stopPropagation();
        } else if(fileItem) {
            let fileItemPath = this.getPath(fileItem.getAttribute('data-location'));
            let fileItemSelected = this.isSelectedPath(fileItemPath);
            
            if(!shiftPressed) {
                this.setShiftAnchorPath(null);
            }
            
            if(shiftPressed) {
                let shiftAnchorPath = this.getShiftAnchorPath();
                if(shiftAnchorPath === null) {
                    if(selectedPaths.length > 0) {
                        this.setShiftAnchorPath(selectedPaths[0]);
                        shiftAnchorPath = selectedPaths[0];
                    } else {
                        this.setShiftAnchorPath(fileItemPath);
                        shiftAnchorPath = fileItemPath;
                    }
                }
                if(shiftAnchorPath.getPath() === fileItemPath.getPath()) {
                    this.clearSelectedPaths();
                    this.addSelectedPath(fileItemPath);
                } else {
                    this.clearSelectedPaths();
                    let pathElements = this.getPaneElement().querySelectorAll('.onavi-file-item');
                    let started = false;
                    let reverseSelectionOrder = false;
                    let shiftPaths = [];
                    for(let i = 0; i < pathElements.length; i+= 1) {
                        let pathElementLocation = pathElements[i].getAttribute('data-location');
                        let matchesAnchor = pathElementLocation === shiftAnchorPath.getPath();
                        let matchesFileItem = pathElementLocation === fileItemPath.getPath();
                        let matchesEitherPath = (matchesAnchor || matchesFileItem);
                        if(started) {
                            shiftPaths.push(this.getPath(pathElementLocation));
                        }
                        if(matchesEitherPath && !started) {
                            started = true;
                            shiftPaths.push(this.getPath(pathElementLocation));
                            if(matchesFileItem) { // Last clicked item is above anchor
                                reverseSelectionOrder = true;
                            }
                        } else if(matchesEitherPath && started) {
                            break;
                        }
                    }
                    if(reverseSelectionOrder) {
                        shiftPaths.reverse();
                    }
                    for(let i = 0; i < shiftPaths.length; i += 1) {
                        this.addSelectedPath(shiftPaths[i]);
                    }
                }
            } else if(ctrlKeyPressed) {
                if(fileItemSelected) {
                    this.removeSelectedPath(fileItemPath);
                } else {
                    this.addSelectedPath(fileItemPath);
                }
            } else {
                if(selectedPaths.length === 1 && recentSelected.getPath() === fileItemPath.getPath()) {
                    let timeSinceLastClick = new Date().getTime() - this.selectedPathStamp;
                    if(timeSinceLastClick < 1000) {
                        if(fileItemPath.isDirectory()) {
                            this.changeDirectory(fileItemPath.getPath());
                        } else {
                            if(this.getConfig('selectMode')) {
                                this.choosePaths([fileItemPath]);
                            } else if(recentSelected.getURL()) {
                                window.open(recentSelected.getFullURL());
                            }
                        }
                    } else {
                        this.selectedPathStamp = new Date().getTime();
                    }
                } else {
                    this.clearSelectedPaths();
                    this.addSelectedPath(fileItemPath);
                }
            }
        } else {
            if(!ctrlKeyPressed && !shiftPressed) {
                this.clearSelectedPaths();
            }
        }
        this.render();
    }
    
    onBackClick() {
        let removeEndRegex = new RegExp('(.+/)(.+$)');
        let location = this.getLocation();
        if(location[location.length -1] == '/') {
            location = location.slice(0, location.length - 1);
        }
        if(removeEndRegex.test(location)) {
            location = location.replace(removeEndRegex, '$1');
        } else {
            location = '/';
        }
        this.changeDirectory(location);
    }
    
    onHomeClick() {
        this.changeDirectory('/');
    }
    
    onRefreshClick() {
        this.refresh();
    }
    
    onBodyKeyDown(e) {
        if(e.keyCode === 16) {
            this.setShiftPressed(true);
        }
    }
    
    onBodyKeyUp(e) {
        if(e.keyCode === 16) {
            this.setShiftPressed(false);
        }
    }
    
    onUploadClick() {
        if(this.getLocationPath() === null || !this.getLocationPath().isWritable()) {
            browserAlert('You do not have permission to upload to this directory.');
            return;
        }
        this.getUploadModal().open();
    }
    
    orderPaths(pathList) {
        let orderMode = this.getPathListOrder().split('-');
        let reverse = orderMode.length > 1;
        let orderField = (orderMode.length > 1) ? orderMode[1] : orderMode[0];
        pathList.sort(function(a, b) {
            let aString = a[orderField].toString().toLowerCase();
            let bString = b[orderField].toString().toLowerCase();
            let yesValue = (reverse) ?  1 : -1;
            let noValue = (reverse) ? -1 : 1;
            if(a.isDirectory() !== b.isDirectory()) {
                return (a.isDirectory() && !b.isDirectory()) ? yesValue : noValue;
            } else if(aString !== bString) {
                if(aString < bString) {
                    return yesValue;
                } else {
                    return noValue;
                }
            } else {
                return 0;
            }
        });
        return pathList;
    }
    
    showMobilePreview(show) {
        this.getElement().classList.toggle('-mobile-preview', show);
    }
    
    setShiftPressed(shiftPressed) {
        this.shiftPressed = shiftPressed;
    }
    
    isShiftPressed() {
        return this.shiftPressed;
    }
    
    setPathListOrder(order) {
        this.pathListOrder = order;
        this.render();
    }
    
    getPathListOrder() {
        return this.pathListOrder;
    }
    
    getRecentlySelectedPath() {
        let selectedPaths = this.getSelectedPaths();
        return (selectedPaths.length === 0) ? null : selectedPaths[selectedPaths.length - 1];
    }
    
    getPath(location) {
        let pathList = this.getPathList();
        for(let i = 0; i < pathList.length; i += 1) {
            if(pathList[i].getPath() === location) {
                return pathList[i];
            }
        }
    }
    
    getSelectedPaths() {
        return this.selectedPaths;
    }
    
    addSelectedPath(path) {
        this.removeSelectedPath(path);
        this.selectedPaths.push(path);
        this.selectedPathStamp = new Date().getTime();
        this.getPreviewArea().render();
    }
    
    isSelectedPath(path) {
        for(let i = 0; i < this.selectedPaths.length; i += 1) {
            if(this.selectedPaths[i].getPath() === path.getPath()) {
                return true;
            }
        }
        return false;
    }
    
    removeSelectedPath(path) {
        for(let i = 0; i < this.selectedPaths.length; i += 1) {
            if(this.selectedPaths[i].getPath() === path.getPath()) {
                return this.selectedPaths.splice(i, 1);
            }
        }
        this.getPreviewArea().render();
    }
    
    clearSelectedPaths() {
        this.selectedPaths.splice(0, this.selectedPaths.length);
        this.getPreviewArea().render();
    }
    
    getClipboardPaths() {
        return this.clipboardPaths;
    }
    
    getClipboardMode() {
        return this.clipboardMode;
    }
    
    getAPI() {
        return this.api;
    }
    
    getLocationPath() {
        return this.locationPath;
    }
    
    getPathList() {
        return this.pathList;
    }
    
    getLocation() {
        return this.location;
    }
    
    getElement() {
        return this.element;
    }
    
    getPaneElement() {
        return this.getElement().querySelector('.onavi-pane');
    }
    
    isDisabled() {
        return this.disabled;
    }
    
    setDisabled(disabled) {
        this.disabled = disabled;
    }
    
    setShiftAnchorPath(path) {
        this.shiftAnchorPath = path;
    }
    
    getShiftAnchorPath() {
        return this.shiftAnchorPath;
    }
    
    getConfig(varName) {
        if(typeof varName === 'undefined') {
            return this.config;
        } else {
            return this.config[varName];
        }
    }
    
    getPreviewArea() {
        return this.previewArea;
    }
    
    getUploadModal() {
        return this.uploadModal;
    }
    
    getStaticURL() {
        return this.staticURL;
    }
};

// Initialiser
Browser.init = function(browserElement, browserConfig, apiURL, apiConfig) {
    let csrfToken = browserElement.querySelector('[name^=csrf]');
    if(!csrfToken) {
        csrfToken = document.querySelector('[name^=csrf]');
    }
    if(!csrfToken) {
        throw new Error('Navigator cannot find a CSRF token in the page, it will not work correctly.');
    }
    let staticURL = browserElement.getAttribute('data-static-root');
    let api = new BrowserAPI(apiURL, csrfToken.value, apiConfig);
    let browser = new Browser(browserElement, api, browserConfig, staticURL);
    return browser;
};

export {
    Browser,
    BrowserAPI,
    BrowserAPIResponse,
    BrowserContextMenu,
    BrowserPath
};
