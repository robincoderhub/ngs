import { Browser } from 'navigator/Browser';

function setUpNavigatorElements() {
    let buttons = document.querySelectorAll('.js-navigator-button:not(.-bound)');
    let template = document.querySelector('*:not(#navigator-page) .onavi:not(.-bound)');
    for(let i = 0; i < buttons.length; i += 1) {
        let button = buttons[i];
        let inputElement = button.parentElement.querySelector('input');
        let apiURL = inputElement.getAttribute('data-api-url');
        let apiSystemPaths = (inputElement.getAttribute('data-system-paths') === '1');
        let apiURLPaths = (inputElement.getAttribute('data-url-paths') === '1');
        let apiSources = (inputElement.getAttribute('data-sources') === '*') ? null : inputElement.getAttribute('data-sources').split('|');
        let broSelectURL = (inputElement.getAttribute('data-select-url') === '1');
        let broSelectFullURL = (inputElement.getAttribute('data-select-full-url') === '1')
        button.classList.add('-bound');
        if(apiSystemPaths === false && apiURLPaths === false) {
            throw new Error('Navigator: both urls and paths cannot be false.');
        }
        let browserConfig = {
            selectMode : true,
            selectCallback : function(pathList) {
                if(broSelectURL) {
                    if(broSelectFullURL) {
                        inputElement.value = pathList[0].getFullURL()
                    } else {
                        inputElement.value = pathList[0].getURL()
                    }
                } else {
                    inputElement.value = pathList[0].getPath()
                }
            },
            selectMax : 1
        };
        let apiConfig = {
            systemPaths : apiSystemPaths,
            urlPaths : apiURLPaths,
            sources : apiSources
        };
        
        let browser = Browser.init(template, browserConfig, apiURL, apiConfig);
        button.addEventListener('click', function() {
            browser.open();
        });
    }
};

window.setUpNavigatorElements = setUpNavigatorElements;
window.NavigatorBrowser = Browser;
