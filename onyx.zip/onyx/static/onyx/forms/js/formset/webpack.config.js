const WEBPACK_FILE_DIR = __dirname;
const WEBPACK_ENTRYPOINT = WEBPACK_FILE_DIR + '/index.js';

module.exports = {
    mode : 'production',
    entry: WEBPACK_ENTRYPOINT,
    output: {
        path: WEBPACK_FILE_DIR,
        filename: 'bundle.js'
    },
    module: {
        rules: [
            {
                test: /\.js$/,
                exclude: /(node_modules)/,
                use: {
                    loader: "babel-loader",
                    options: {
                        presets: ["@babel/preset-env"]
                    }
                }
            }
        ]
    },
    resolve : {
        modules : [
            WEBPACK_FILE_DIR,
            '/app/node_modules'
        ]
    }
};
