class FormsetController {
    constructor(element) {
        this.element = element;
        this.bindListeners();
    }

    bindListeners() {
        this.getElement().querySelector('.form-formset-controls-add').addEventListener(
            'click',
            this.onAddClick.bind(this)
        );
    }

    addForm() {
        let newFormId = this.getFormList().querySelectorAll('.form-formset-item').length;
        let newForm = this.generateEmptyForm(newFormId);
        this.getManagementForm().querySelector('[name$=TOTAL_FORMS]').value = newFormId + 1;
        this.getFormList().appendChild(newForm);
    }

    generateEmptyForm(formIndex) {
        let emptyForm = this.getElement().querySelector(
            '.form-formset-empty .form-formset-item'
        ).cloneNode(true);
        let prefixedElements = emptyForm.querySelectorAll('label, input, textarea, select');
        for(let i = 0; i < prefixedElements.length; i += 1) {
            let element = prefixedElements[i];
            if(element.htmlFor) {
                element.htmlFor = element.htmlFor.replace('__prefix__', formIndex);
            }
            if(element.name) {
                element.name = element.name.replace('__prefix__', formIndex);
            }
            if(element.id) {
                element.id = element.id.replace('__prefix__', formIndex);
            }
        }
        return emptyForm;
    }

    onAddClick() {
        this.addForm();
    }

    getElement() {
        return this.element;
    }

    getManagementForm() {
        return this.getElement().querySelector('.form-formset-management');
    }

    getFormList() {
        return this.getElement().querySelector('.form-formset-items');
    }

    getFormsetControls() {
        return this.getElement().querySelector('.form-formset-controls');
    }
}

window.addEventListener('DOMContentLoaded', function() {
    let formsets = document.querySelectorAll('.form-formset');
    for(let i = 0; i < formsets.length; i += 1) {
        if(!formsets[i].classList.contains('-bound')) {
            new FormsetController(formsets[i]);
            formsets[i].classList.add('-bound');
        }
    }
});
