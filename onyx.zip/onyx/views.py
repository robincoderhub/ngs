"""
# Onyx common views

These are generic views that are designed to make a number of common tasks easier and quicker.
"""

import json
from collections import OrderedDict

from django.contrib import messages
from django.shortcuts import redirect
from django.http import HttpResponseForbidden
from django.db import transaction
from django.db.models import Q
from django.views.generic.base import ContextMixin, View
from django.views.generic import TemplateView, ListView
from django.forms.utils import pretty_name
from django_tables2 import SingleTableMixin
from django_tables2 import LinkColumn
from django_tables2.utils import A

from onyx.apps.cms.menus.items import MenuItemTree
from onyx.utils.conditionals import validate_conditions


class SmartContextMixin(object):
    """A mixin that contains a number of commonly used
    context variables including page title, breadcrumbs,
    and meta data. It also has a permissions checking
    feature to deny access unless user has given permissions

    Args:
        args*: Class positional arguments
        view_title: The title of the view, typically page title.
        view_meta: A list of dicts containing meta tag attributes
            to display on the page.
        view_js: A list of javascript static paths to display on
            this page.
        view_css: A list of CSS static paths to display on this
            page.
        view_breadcrumbs: A list or tuple of (name, url) pairs to
            be used as navigation breadcrumbs on the page.
        view_menu: A menu instance for this page, see the
            onyx.apps.cms.menus module.
        view_menu_selector: The menu item to select as 'current' on
            the page, see onyx.apps.cms.menus module.
        view_permissions: A conditional object for view permissions
            see onyx.utils.conditionals.
        **kwargs: Class keyword arguments"""

    view_title = None
    """The title of the view, typically page title."""

    view_meta = None
    """A list of dicts containing meta tag attributes
    to display on the page."""

    view_js = None
    """A list of javascript static paths to display on
    this page."""

    view_css = None
    """A list of CSS static paths to display on this
    page."""

    view_breadcrumbs = None
    """A list or tuple of (name, url) pairs to
    be used as navigation breadcrumbs on the page."""

    view_menu = None
    """A menu instance for this page, see the
    onyx.apps.cms.menus module."""

    view_menu_selector = None
    """The menu item to select as 'current' on
    the page, see onyx.apps.cms.menus module."""

    view_permissions = None
    """A conditional object for view permissions
    see onyx.utils.conditionals."""

    def __init__(
        self, *args, view_title=None, view_meta=None,
        view_js=None, view_css=None, view_breadcrumbs=None,
        view_menu=None, view_menu_selector=None,
        view_permissions=None, **kwargs
    ):
        if hasattr(super(), '__init__'):
            super().__init__(*args, **kwargs)
        self.view_title = view_title or self.view_title
        self.view_meta = view_menu or self.view_menu or []
        self.view_js = view_js or self.view_js or []
        self.view_css = view_css or self.view_css or []
        self.view_breadcrumbs = view_breadcrumbs or self.view_breadcrumbs or []
        self.view_menu = view_menu or self.view_menu or MenuItemTree([])
        self.view_menu_selector = view_menu_selector or self.view_menu_selector
        self.view_permissions = view_permissions or self.view_permissions or []

    def prepare_view_menu(self):
        """Organises view menu before displaying, organises
        the menu by node weight, hides menu nodes that user
        doesn't have permission to see and selects 'current'
        menu node

        Returns:
            The sorted menu
        """
        view_menu = self.get_view_menu()
        view_menu_selector = self.get_view_menu_selector()
        if view_menu_selector:
            if (
                isinstance(view_menu_selector, list)
                or isinstance(view_menu_selector, tuple)
            ):
                for view_menu_selector_item in view_menu_selector:
                    view_menu.set_node_selected(view_menu_selector_item)
            else:
                view_menu.set_node_selected(view_menu_selector)
        if self.request:
            view_menu.prune_by_permissions(self.request.user)
        view_menu.sort_by_node_weight()
        return view_menu

    def validate_view_permissions(self, user):
        """Validates the user against the view to see if
        they have permission to view this view.

        Args:
            user: The user to validate against

        Returns:
            True if user is valid, False if not"""
        view_permissions = self.get_view_permissions()
        if view_permissions:
            return validate_conditions(
                lambda x, y: x.has_perm(y),
                user,
                view_permissions
            )
        return True

    def pre_dispatch(self, request, *args, **kwargs):
        """An extra step before dispatch to set some
        utilty variables on the class and validate
        view permissions. Saves having to do it manually
        each view

        Args:
            request: The incoming Django request object
            *args: Request arguments
            **kwargs: Request keyword arguments

        Returns:
            Can return a View object to override the view
            such as the forbidden view, or None to indicate
            the view should continue on as normal."""
        self.request = request
        self.request_args = args
        self.request_kwargs = kwargs
        if not self.validate_view_permissions(request.user):
            return HttpResponseForbidden()
        return None

    def dispatch(self, request, *args, **kwargs):
        """An override of the default dispatch method
        to include the 'pre_dispatch' method in the request
        process.

        Args:
            request: The incoming Django request object
            *args: The request arguments
            **kwargs: The request keyword arguments.

        Returns:
            A View object for Django to use."""
        response = self.pre_dispatch(request, *args, **kwargs)
        if response:
            return response
        return super().dispatch(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        """Override of default to add the various
        context variables this class provides.

        Args:
            **kwargs: The current context variable
                dict.

        Returns:
            A dict containing the updated context variables."""
        if hasattr(super(), 'get_context_data'):
            context = super().get_context_data(**kwargs)
        else:
            context = {}

        view_menu = self.prepare_view_menu()

        context.update({
            'view_title': self.get_view_title(),
            'view_meta': self.get_view_meta(),
            'view_js': self.get_view_js(),
            'view_css': self.get_view_css(),
            'view_breadcrumbs': self.get_view_breadcrumbs(),
            'view_menu': view_menu
        })
        return context

    def get_view_menu(self):
        """Getter for this views's menu instance

        Returns:
            A menu list instance
        """
        return self.view_menu

    def get_view_menu_selector(self):
        """Get the menu selector this view should
        use in the prepare step. If no selector
        is directly set it will attempt to determine
        the nearest match from the url.

        Returns:
            A string menu selector or None if it could
            not be determined.
        """
        selector = self.view_menu_selector
        if selector is None:
            menu = self.get_view_menu()
            if menu:
                node = menu.get_node_by_url(self.request.path)
                if node:
                    selector = menu.get_node_selector(node)
        return selector

    def get_view_title(self):
        """Get this view's title, if none has been
        set it will attempt to get this views 'verbose_name'
        attribute instead.

        Returns:
            The title string if found or None"""
        if self.view_title:
            return self.view_title
        elif hasattr(self, 'verbose_name'):
            return self.verbose_name
        return None

    def get_view_meta(self):
        """Get this view's meta data tags.

        Returns:
            A list of dicts containing the attributes
            for the meta tags to display."""
        return self.view_meta

    def get_view_js(self):
        """Get the additional JS files this view should
        display in the template.

        Returns:
            A list of static paths to JS files."""
        return self.view_js

    def get_view_css(self):
        """Get the additional CSS files this view should
        display in the template.

        Returns:
            A list of static paths to CSS files"""
        return self.view_css

    def get_view_breadcrumbs(self):
        """Get the navigation breadcrumbs for this view.

        Returns:
            A list of tuples containing (name, link)"""
        breadcrumbs = self.view_breadcrumbs
        if not breadcrumbs:
            menu = self.get_view_menu()
            if menu:
                node = menu.get_node_by_url(self.request.path)
                if node:
                    breadcrumbs = menu.get_breadcrumbs(node)
        if len(breadcrumbs) == 1:  # Just contains itself
            return []
        return breadcrumbs

    def get_view_permissions(self):
        """Gets permission conditional objects for this
        instance, see onyx.apps.conditionals for more information.

        Returns:
            Permission conditional object."""
        return self.view_permissions


class SmartView(SmartContextMixin, View):
    """A simple view that uses the SmartContextMixin
    mixin."""

    def post(self, *args, **kwargs):
        """Override of the post method to ensure
        POST requests don't receive Method Not Allowed
        errors. This will return the 'get' method's
        output.

        Args:
            *args: Method arguments
            **kwargs: Method keyword args

        Returns:
            A View object"""
        return self.get(*args, **kwargs)


class SearchListMixin(ContextMixin):
    """A standard 'search list' mixin for displaying results on a page,
    utilising Django Filters.

    Note:
        See https://django-filter.readthedocs.io/en/master/ for
            more information."""

    paginate_by = 50
    """The number of result to paginate by, defaults to 50."""

    default_order = '-pk'
    """The default attribute to order the result set by,
    this can contain the minus symbol for reverse listing."""

    search_fields = None
    """Specifies what fields of the model should be searched
    by the 'main' text search."""

    search_param_name = 'search'
    """The name of the GET variable that should be used
    for the 'main' text search."""

    search_any_word = True
    """If True, allows matching of any word in the 'main'
    search, if False must be an exact match."""

    filter_set_class = None
    """Can provide a Django filters FilterSet class to use to
    filter the queryset."""

    filter_set = None
    """This is the initialised version of the filter_set_class
    when the view is run."""

    def get_filter_set_class(self):
        """Get the currently set FilterSet class.

        Returns:
            A django filters FilterSet object or None
            if one is not set"""
        return self.filter_set_class

    def get_filter_set_kwargs(self):
        """Get filter set kwargs, this method is here
        to allow logic to be placed here if required.

        Returns:
            A dict of keyword arguments to pass the FilterSet
            object."""
        return {
            'data': self.request.GET
        }

    def get_filter_set(self, queryset=None):
        """Initialises and returns the filterset class set on
        this class.

        Args:
            queryset: Optional, this needs ran with a queryset
                once to initialize. Afterwards a call to
                get_filter_set will return the cached object.

        Returns:
            A FilterSet object or None if no class is specified."""
        if self.filter_set:
            return self.filter_set
        filter_set_class = self.get_filter_set_class()
        if not filter_set_class:
            return None
        filter_set_kwargs = self.get_filter_set_kwargs()
        if queryset:
            filter_set_kwargs['queryset'] = queryset
        self.filter_set = filter_set_class(**filter_set_kwargs)
        return self.filter_set

    def get_queryset(self, *args, **kwargs):
        """Override, get the queryset to display, this method
        applies the main search and filterset if applicable
        and returns the resultant queryset.

        Args:
            args*: Method arguments
            **kwargs: Method keyword arguments

        Returns:
            A Django queryset object"""
        queryset = super().get_queryset(*args, **kwargs)
        filter_set = self.get_filter_set(queryset)
        if filter_set:
            queryset = filter_set.qs

        search_queries = self.get_search_queries()
        if search_queries:
            queryset = queryset.filter(search_queries)

        return queryset.order_by(self.get_default_order())

    def get_default_order(self):
        """Get the default order for the queryset, can contain
        the minus symbol '-' for reverse ordering.

        Returns:
            A string such as '-id'"""
        return self.default_order

    def get_search_fields(self):
        """Get the fields on the models that are used by the 'main'
        search.

        Returns:
            A list of search fields"""
        return self.search_fields if self.search_fields else []

    def get_search_param_name(self):
        """Get the GET parameter name used for the 'main' search.

        Returns:
            A string containing the name."""
        return self.search_param_name

    def get_search_param_value(self):
        """Get the 'main' search parameter value from the request's
        GET variables, the search term.

        Returns:
            A string containing the input"""
        return self.request.GET.get(self.get_search_param_name(), '')

    def get_search_queries(self):
        """Builds a bitwise separated object of search queries
        to use to filter the queryset.

        Returns:
            Bitwise OR seperated list of queries."""
        search_queries = None
        search_term = self.get_search_param_value().strip()
        search_fields = self.get_search_fields()
        if len(search_fields) > 0 and search_term:
            if self.search_any_word:
                search_term_bits = search_term.split()
            else:
                search_term_bits = [search_term]
            for field_name in search_fields:
                for search_term_bit in search_term_bits:
                    query = Q(**{field_name: search_term_bit})
                    if search_queries:
                        search_queries = search_queries | query
                    else:
                        search_queries = query
        return search_queries

    def get_context_data(self, **kwargs):
        """Override of context data method to add various
        search and filter objects to context.

        Args:
            **kwargs: The current context data dict

        Returns:
            A dict of context vars."""
        context = super().get_context_data(**kwargs)
        context.update({
            'filter_set': self.get_filter_set(),
            'search_enabled': True if self.get_search_fields() else False,
            'search_param_name': self.get_search_param_name(),
            'search_param_value': self.get_search_param_value()
        })
        return context


class SearchListView(SearchListMixin, ListView):
    """A ListView class using the SearchListMixin mixin"""
    pass


class SearchTableMixin(SingleTableMixin, SearchListMixin):
    """An extension of the SearchListMixin and django-tables, this
    view mixin adds convenience functions for displaying the resultant
    data in a django-tables table."""

    table_template_name = None
    """The template to use for displaying the
    table in the view."""

    table_columns = None
    """A list of strings defining the fields for django-tables
    to use to build columns."""

    table_kwargs = None
    """Additional keyword arguments to pass to the django-tables
    table."""

    edit_url = None
    """If specified, adds an extra column to edit the row, this
    should be a django url identifier such as core.edit_row. By
    default this will only work if it the url accepts a 'id'
    parameter in the path."""

    delete_url = None
    """If specified, add an extra column to delete the row, this
    works the same as the edit_url."""

    extra_columns = None
    """Allows you to specify a list of Column class instances
    to use in the table if the standard django-tables columns are
    not suitable."""

    def get_table_template_name(self):
        """Getter for django-tables table template name

        Returns:
            The template name or None if not specified."""
        return self.table_template_name

    def get_table_columns(self):
        """Get table column names to display

        Returns:
            A list of strings containing model attributes to use
            for columns."""
        return self.table_columns

    def get_extra_columns(self):
        """Getter for additional column classes to use for this table.

        Returns:
            A list of table column instances"""
        return self.extra_columns

    def get_table_kwargs(self, *args, **kwargs):
        """Override, get keyword arguments for the table. This method
        adds the various options configured with the class
        attributes.

        Args:
            *args: Method arguments
            **kwargs: Method keyword arguments

        Returns:
            A dict of keyword arguments for the table."""
        table_kwargs = super().get_table_kwargs(*args, **kwargs)
        if self.table_kwargs:
            table_kwargs.update(self.table_kwargs)
        if self.edit_url or self.delete_url:
            if 'extra_columns' not in table_kwargs:
                table_kwargs['extra_columns'] = []
            if self.edit_url:
                table_kwargs['extra_columns'].append(
                    (
                        ' ',
                        LinkColumn(
                            self.edit_url,
                            text='Edit',
                            args=[A('pk')]
                        )
                    )
                )
            if self.delete_url:
                table_kwargs['extra_columns'].append(
                    (
                        ' ',
                        LinkColumn(
                            self.edit_url,
                            text='Delete',
                            args=[A('pk')]
                        )
                    )
                )
        table_kwargs.update({
            'template_name': self.get_table_template_name()
        })
        table_cols = self.get_table_columns()
        if table_cols or isinstance(table_cols, (list, tuple)):
            excluded_cols = []
            model = self.get_queryset().model
            for field in model._meta.get_fields():
                if field.name not in table_cols:
                    excluded_cols.append(field.name)
            table_kwargs.update({
                'sequence': table_cols,
                'exclude': excluded_cols
            })
        extra_columns = self.get_extra_columns()
        if extra_columns:
            table_kwargs['extra_columns'] = extra_columns
        return table_kwargs

    def get_search_fields(self):
        """Get the model fields to use for the 'main' search
        will add any table columns that have been specified.

        Returns:
            A list of field names."""
        fields = super().get_search_fields()
        # None check, might be deliberately empty '[]'
        if not fields and fields is not None and self.get_table_columns():
            search_fields = []
            for field_name in self.get_table_columns():
                search_fields.append(f"{field_name}__icontains")
            return search_fields
        return fields


class SearchTableView(SearchTableMixin, ListView):
    """A ListView class utilising the SearchTableMixin class"""
    pass


class MultiFormMixin(object):
    """A utility class for displaying and validating multiple forms
    as a single operation."""

    form_classes = OrderedDict()
    """An OrderedDict object containing the alias of the
    form class -> the form class to initialise."""

    success_redirect = None
    """A url to redirect to when the forms have been
    completed successfully."""

    success_message = "Saved successfully!"
    """A message to display using django.contrib.messages
    module. Set to None to display no message."""

    error_message = "Please address the highlighted errors."
    """A general error message to display using
    django.contrib.messages module if one or all forms did not
    validate. Example: There are errors with your forms."""

    def get_form_classes(self):
        """Getter for form class dict.

        Returns:
            A dict (preferably ordered) of the form alias -> form class"""
        return self.form_classes

    def get_form_kwargs(self, form_name):
        """Get form keyword arguments for a specific form in the set.
        by default it will pass the prefix kwarg as the form alias.

        Args:
            form_name: The form alias of the form, this can be used
                to differentiate what forms should receive what kwargs.

        Returns:
            A dict of kwargs to pass to the form."""
        return {
            'prefix': form_name
        }

    def create_forms(self, *args, **kwargs):
        """Create forms and place them in a dict, arguments
        and keyword arguments get passed into every form alongside
        the configure form kwargs from get_form_kwargs.

        Args:
            *args: These arguments are passed to all form classes
            **kwargs: These keyword arguments are passed to all form
                classes.

        Returns:
            A dict of initialised forms."""
        form_dict = OrderedDict()
        for form_name, form_class in self.get_form_classes().items():
            form_kwargs = kwargs.copy()
            form_kwargs.update(self.get_form_kwargs(form_name))
            form_dict[form_name] = form_class(
                *args,
                **form_kwargs
            )
        return form_dict

    def get_form_save_kwargs(self, form_name, form_dict):
        """Keyword arguments for the form's 'save' method.

        Args:
            form_name: The form alias, can be used to differentiate
                what is passed to what form.
            form_dict: The dict of initialised forms, this can be used
                to pass information from one form to another. Please note
                using an OrderedDict allows you to save forms in order.

        Returns:
            A dict of keyword arguments"""
        return {}

    def save_forms(self, form_dict):
        """Method for saving all forms, can be overidden to do
        any special saving logic.

        Args:
            form_dict: A dict of the initialised, validated form
                instances keyed by alias.

        Returns:
            A dict of saved form results"""
        form_results = OrderedDict()
        with transaction.atomic():
            for form_name, form in form_dict.items():
                form_results[form_name] = self.save_form(
                    form_name,
                    form,
                    form_dict
                )
        return form_results

    def save_form(self, form_name, form, form_dict):
        """Method for saving an individual form, can be overridden
        to apply any special logic for a form. By default this method
        will only save forms that have a dedicated 'save' method on
        them.

        Args:
            form_name: The form alias of the form being saved
            form: The initialised, validated form to be saved.
            form_dict: The dict of all initialized, validated forms
                keyed by alias.

        Returns:
            The result of the form's 'save' method or None if the
            form has no method."""
        if hasattr(form, 'save'):
            return form.save(
                **self.get_form_save_kwargs(form_name, form_dict)
            )
        return None

    def validate_form(self, form_name, form):
        """Method for validating a form, can be overridden to
        apply any special logic to form validation.

        Args:
            form_name: The form alias of the form being validated,
                can be used to apply special logic for specific forms.
            form: The form object to validated.
        Returns:
            bool: True if form is valid or False if not."""
        return form.is_valid()

    def forms_valid(self, request, forms, *args, **kwargs):
        """Method called if all forms are valid, by default
        saves all forms, applies success message and redirects
        to the success redirect if set.

        Args:
            request: The django request object
            forms: A dict of form object's keyed by alias.
            *args: Request arguments
            **kwargs: Request keyword arguments

        Returns:
            A Django Response object."""
        form_results = self.save_forms(forms)
        success_message = self.get_success_message(
            request,
            forms,
            form_results
        )
        success_redirect = self.get_success_redirect(
            request,
            forms,
            form_results
        )
        if success_message:
            messages.success(request, success_message)
        if success_redirect:
            return redirect(success_redirect)
        return self.render_to_response(self.get_context_data())

    def forms_invalid(self, request, forms, *args, **kwargs):
        """Method called if any forms are invalid, by default
        displays error message and display the view as normal.

        Args:
            request: The django request object
            forms: A dict of form object's keyed by alias.
            *args: Request arguments
            **kwargs: Request keyword arguments

        Returns:
            A Django Response object."""
        error_message = self.get_error_message(request, forms)
        if error_message:
            messages.error(request, error_message)
        return self.render_to_response(
            self.get_context_data()
        )

    def get_success_redirect(self, request, form_dict, form_results):
        """Get the success redirect url to be used on success. Can be
        overidden to redirect to different places depending on form
        input.

        Args:
            request: A Django request object
            form_dict: A dict of form objects keyed by alias
            form_results: A dict of the results of form's 'save' methods

        Returns:
            The redirect url or None if none set."""
        return self.success_redirect

    def get_success_message(self, request, form_dict, form_results):
        """Get the success message to be used on success. Can be
        overidden to display different messages based on form input.

        Args:
            request: A Django request object
            form_dict: A dict of form objects keyed by alias
            form_results: A dict of the results of form's 'save' methods

        Returns:
            The success message to display or None if set."""
        return self.success_message

    def get_error_message(self, request, form_dict):
        """Get the error message to be used on error. Can be
        overidden to display different messages based on form input.

        Args:
            request: A Django request object
            form_dict: A dict of form objects keyed by alias

        Returns:
            The error message to display or None if set."""
        return self.error_message


class MultiFormView(MultiFormMixin, TemplateView):
    """A View class utilising the MultiFormMixin class. This
    view sets up the dispatch methods to handle standard form
    submissions."""

    forms = None
    """The 'cached' form instances when first created."""

    def dispatch(self, request, *args, **kwargs):
        """Override of dispatch method to create the view's
        form instances and assign to the 'forms' class attribute.

        If 'POST' occurs, passes post data to forms whilst creating,
        these will then be validated, saved etc.

        Args:
            request: A Django request object
            *args: Request arguments
            **kwargs: Request keyword arguments

        Returns:
            A Django response object."""
        if request.method == 'POST':
            self.forms = self.create_forms(
                data=request.POST,
                files=request.FILES
            )
        else:
            self.forms = self.create_forms()
        return super().dispatch(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        """Post method dispatch handler, validates and triggers
        forms_valid method if valid.

        Args:
            request: Django request object
            *args: Request arguments
            **kwargs: Request keyword arguments

        Returns:
            A Django response object"""
        forms = self.get_forms()
        forms_valid = all(
            self.validate_form(form_name, form)
            for form_name, form in forms.items()
        )
        if forms_valid:
            return self.forms_valid(request, forms, *args, **kwargs)
        return self.forms_invalid(request, forms, *args, **kwargs)

    def get_context_data(self, **kwargs):
        """Override, adds form's to template context both
        under the name 'forms' for the aliased dict and each
        form individually by it's alias name.

        Args:
            **kwargs: Current context data to extend

        Returns:
            The updated context data"""
        context = super().get_context_data(**kwargs)
        forms = self.get_forms()
        context['forms'] = forms
        for form_name, form in forms.items():
            context[form_name] = form
        return context

    def get_forms(self):
        """Get the dict of initialised form instances
        set on this class.

        Returns:
            A dict of initialised forms keyed by alias."""
        return self.forms


class TabbedMultiFormMixin(MultiFormMixin):
    """A 'tabbed' version of the standard MultiFormMixin class. This
    class groups forms together in the context data to display however
    you want."""

    tab_definitions = None
    """A list of tuples in the format (name, list[alias]) to
        easily define groups of forms or None for no tabs."""

    def get_tabs(self, forms):
        """Get tabbed form's data for the context.

        Args:
            forms: The dict of initialised forms

        Returns:
            A list of tab dicts containing a 'name' member (the public facing
            name of the tab) and a 'forms' member containing a list of the form
            instances for display."""
        tab_definitions = self.get_tab_definitions()
        if not tab_definitions:
            tab_definitions = [
                (pretty_name(form_name), [form_name])
                for form_name, form in forms.items()
            ]
        tabs = []
        for tab_definition in tab_definitions:
            tab_name, tab_form_names = tab_definition
            tab_forms = [
                forms[tab_form_name]
                for tab_form_name in tab_form_names
            ]
            tabs.append({
                'name': tab_name,
                'forms': tab_forms
            })
        return tabs

    def get_tab_definitions(self):
        """Getter for tab definitions.

        Returns:
            A list of tuples in the format (name, list[alias]) to easily
            define groups of forms or None for no tabs."""
        return self.tab_definitions


class TabbedMultiFormView(TabbedMultiFormMixin, MultiFormView):
    """A MultiFormView that utilises the TabbedMultiFormMixin mixin
    and adds the resultant tabs to the context."""

    def get_context_data(self, **kwargs):
        """Override, adds the tabbed forms to the context.

        Args:
            **kwargs: The current coontext data

        Returns:
            A dict of updated context data."""
        context = super().get_context_data(**kwargs)
        context.update({
            'tabs': self.get_tabs(context['forms'])
        })
        return context


class JSConstantsView(TemplateView):
    """A reusable view for defining system-side 'constants' in a
    javascript file."""

    template_name = 'onyx/views/generic/js_constants.js'
    """The template name of the template to render"""

    content_type = 'text/javascript'
    """Sets content_type to 'text/javascript'"""

    def get_constants(self, request):
        """Gets constants to display in the file, this method
        should typically be overridden. Please note all variables
        must be able to be converted to JSON.

        Args:
            request: The incoming request

        Returns:
            A dict of variables to convert to JSON"""
        return {}

    def get_context_data(self, **kwargs):
        """Override, adds constants data to the template context

        Args:
            **kwargs: The current context data

        Returns:
            A dict of the updated context data"""
        context = super().get_context_data(**kwargs)
        constants = self.get_constants(self.request)
        context['constants'] = {
            key: json.dumps(value)
            for key, value in constants.items()
        }
        return context
