"""Template tags for Onyx and all sub apps should go here"""
