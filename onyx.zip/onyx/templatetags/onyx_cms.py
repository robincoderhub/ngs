"""Template tags for displaying various CSM content"""

from django.core.exceptions import ValidationError
from django.template import Library
from django.utils.html import mark_safe

from onyx.apps.cms.register import get_widget_type
from onyx.apps.cms.models import Chunk


register = Library()


@register.simple_tag(takes_context=True)
def display_widget(context, widget):
    """Render a widget

    Args:
        context: The template's context
        widget: The Widget model to display

    Returns:
        The rendered widget string (as a 'safe' string)"""

    widget_type = get_widget_type(widget.widget_type)
    if not widget_type:
        raise ValueError(
            f'Widget type {widget.widget_type} is not registered'
        )
    widget_data = widget.data
    if 'basic_details' in widget_data:
        for key, value in widget_data['basic_details'].items():
            widget_data[key] = value
    return mark_safe(
        widget_type.render(
            context,
            widget_data
        )
    )


@register.simple_tag(takes_context=True)
def display_chunk(context, chunk):
    """Display the widgets in a particular chunk
    in order.

    Args:
        context: The template context
        chunk: The Chunk model to display

    Returns:
        The rendered content as a 'safe' string."""
    widgets = chunk.widgets.all().order_by('order')
    widget_output = ''
    for widget in widgets:
        widget_output += display_widget(context, widget)
    return mark_safe(widget_output)


@register.simple_tag(takes_context=True)
def chunk(context, chunk_name):
    """Display the widgets in a particular chunk in order
    using the internal name of the chunk.

    Args:
        context: The template context
        chunk_name: The internal name of the chunk to use

    Returns:
        The rendered content as a 'safe' string."""
    try:
        chunk = Chunk.objects.get(
            global_chunk=True,
            chunk_name=chunk_name
        )
    except Chunk.DoesNotExist:
        return f'Global chunk "{chunk_name}" is not set up.'
    return display_chunk(context, chunk)


@register.simple_tag(takes_context=True)
def template_chunk(context, chunk_name):
    """A tag used to display the chunks of a template using
    the 'chunks' member of the global context

    Args:
        context: The templates' context
        chunk_name: The name of the chunk to display

    Returns:
        The rendered content as a 'safe' string."""
    chunk = context.get('chunks', {}).get(chunk_name)
    if chunk:
        return display_chunk(context, chunk)
    return ''
