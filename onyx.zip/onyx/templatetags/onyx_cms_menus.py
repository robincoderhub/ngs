"""Template tags for displaying CMS generated menus"""

from django import template
from django.template.loader import render_to_string

from onyx.apps.cms.menus.models import Menu


register = template.Library()


@register.simple_tag(takes_context=True)
def display_menu(context, node_tree, template_name='onyx/apps/cms/menus/menu.html'):
    """Display a CMS menu, can accept either an actual
    menu tree or a string reference to the menu to display.
    Fails softly if a CMS menu referenced cannot be found by
    displaying a message in its place.

    Args:
        context: The template's context
        node_tree: Either a menu node tree or a string reference
            to a cms menu i.e. 'main_menu'.
        template_name: Optional, can override the template used to display
            this menu.
    
    Returns:
        The rendered menu as a string."""
    if isinstance(node_tree, str):
        menu = Menu.objects.filter(name=node_tree)
        if len(menu) > 0:
            node_tree = menu[0].to_menu_tree()
        else:
            return f'Menu "{node_tree}" has not been defined in the admin.'
    node_tree.sort_by_node_weight()
    return render_to_string(
        template_name,
        {
            'node_tree': node_tree
        },
        request=context.get('request')
    )


@register.simple_tag(takes_context=True)
def display_menu_item(
    context, node,
    template_name='onyx/apps/cms/menus/menu_item.html'
):
    """Tag for displaying an individual menu node,
    used by display_menu

    Args:
        context: The template's context
        node: The menu node to display
        template_name: Optional, can override the template used
            to render this node.

    Returns:
        The rendered menu item string"""
    return render_to_string(
        template_name,
        {
            'node': node
        },
        request=context.get('request')
    )


@register.simple_tag(takes_context=True)
def display_menu_node(context, node):
    """Tag for displaying the menu node itself, calls
    '.render' on the node and returns the output.

    This is seprate from the 'menu_item', think of the
    menu item as being the '<li>' tag around the node
    and the node being the menu link itself.

    Args:
        context: The template context
        node: The Menu node to display

    Returns:
        The rendered node string."""
    return node.render(context)
