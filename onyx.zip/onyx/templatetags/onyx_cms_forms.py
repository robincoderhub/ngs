"""Template tags for displaying Onyx's CMS forms content"""

import os

from django import forms
from django.conf import settings
from django.urls import reverse
from django.template import Library
from django.template.loader import render_to_string

from onyx.utils import external_url, external_url_approximate
from onyx.apps.cms.cms_forms.models import CMSForm


register = Library()


@register.simple_tag(takes_context=True)
def display_cms_form(context, form_name, prefix=None, template_name='onyx/apps/cms/cms_forms/tags/cms_form.html'):
    """Display a CMS form, using its internal name to identify and
    load it.

    Example:
        {% display_cms_form 'contact_form' %}

    Args:
        context: The template context
        form_name: The internal name of the CMS form to display
        prefix: Optional, allows you to add a prefix to the form if
            multiple forms are present.
        template_name: Optional, allows you to override the template to
            use to render this form.

    Returns:
        The rendered form"""
    request = context['request']
    prefix = prefix if prefix else form_name
    try:
        form_model = CMSForm.objects.get(name=form_name)
    except CMSForm.DoesNotExist:
        form = None
    else:
        data = request.POST if request.method == 'POST' else None
        files = request.FILES if request.method == 'POST' else None
        form = form_model.to_form_class()(
            data=data,
            files=files,
            prefix=prefix
        )
        if form.is_valid():  # Make sure it gets validated
            # If form is valid, we can assume it was handled, so lets create
            # an empty one
            form = form_model.to_form_class()(data=None, prefix=prefix)
    return render_to_string(
        template_name,
        context={
            'form': form,
            'form_name': form_name
        },
        request=request
    )


@register.simple_tag(takes_context=True)
def render_form_response(
    context, form_model, form_data,
    response=None, html=True
):
    """Template tag for rendering a CMS form response, this
    tag is used on response pages and emails to render the output
    in a human friendly way.

    Args:
        context: The templates context
        form_model: The CMSForm model
        form_data: The data sent to the CMS form
        response: Optional, the response object it is attached to
        html: Defaults to True, displays response as HTML, if False plain text

    Notes:
        There are situations where 'response' is None, in the case that
        a CMS form sends to an email address but DOESN'T save it to
        the database. Hence why there are extra parameters instead of
        just the 'response' param.

    Returns:
        The rendered response string"""
    request = context.get('request')
    entries = []
    form = form_model.to_form_class()()
    field_models = {
        field.name: field
        for field in form_model.fields.all()
    }
    for field_name, field in form.fields.items():
        if (
            field_name not in field_models
            or not field_models[field_name].show_in_response
        ):
            continue
        entry_value = form_data.get(field_name)
        entry = {
            'label': field.label,
            'value': entry_value,
            'type': 'PLAIN'
        }
        if isinstance(entry_value, list):
            entry['type'] = 'LIST'
        elif isinstance(field, forms.URLField):
            entry['type'] = 'LINK'
        elif isinstance(field, forms.FileField):
            if not entry_value:
                entry['value'] = 'No file uploaded'
            elif response:
                file_dict = response.file_dict
                if field_name not in file_dict:
                    entry['value'] = 'No file found'
                else:
                    entry['type'] = 'LINK'
                    file_model = file_dict.get(field_name)
                    file_url = reverse(
                        'cms_forms:response_file',
                        args=[file_model.id]
                    )
                    if request:
                        entry['value'] = f"{external_url(request)}{file_url}"
                    else:
                        url_base = external_url_approximate(
                            settings.APP_HOSTNAME
                        )
                        entry['value'] = f"{url_base}{file_url}"
                    link_label_name = os.path.basename(
                        file_model.uploaded_file.name
                    )
                    entry['link_label'] = f"{link_label_name} (click to download)"
            else:
                entry['value'] = f'[FILE {entry_value}]'
        entries.append(entry)
    return render_to_string(
        (
            'onyx/apps/cms/cms_forms/tags/response.html'
            if html
            else 'onyx/apps/cms/cms_forms/tags/response.txt'
        ),
        context={
            'entries': entries
        },
        request=context.get('request')
    )
