"""Lorem ipsum style dummy conent tags for illustrative purposes"""

from django.template import Library

from onyx.utils import lorem


register = Library()


@register.simple_tag
def lorem_title_male():
    """Display a male title i.e. 'mr'

    Returns:
        A title string."""
    return lorem.title_male()


@register.simple_tag
def lorem_title_female():
    """Display a male title i.e. 'ms'/'mrs'

    Returns:
        A title string."""
    return lorem.title_female()


@register.simple_tag
def lorem_title_neuter():
    """Display a neuter title i.e. 'mx'

    Returns:
        A title string."""
    return lorem.title_neuter()


@register.simple_tag
def lorem_name(gender=None):
    """Display a full random name

    Args:
        gender: Optional, accepts 'male' or 'female'

    Returns:
        A random name i.e. Rupert Sharp."""
    return lorem.full_name(gender=gender)


@register.simple_tag
def lorem_name_with_title(gender=None):
    """Display a full random name with a title prefix

    Args:
        gender: Optional, accepts 'male' or 'female'

    Returns:
        A random name with a title i.e. Mr. Rupert Sharp"""
    return lorem.full_name_with_title(gender=gender)


@register.simple_tag
def lorem_first_name(gender=None):
    """Display a random first name

    Args:
        gender: Optional, accepts 'male' or 'female'

    Returns:
        A random first name i.e. Rupert"""
    return lorem.first_name(gender=gender)


@register.simple_tag
def lorem_last_name():
    """Display a random last name

    Returns:
        A random last name i.e. Sharp"""
    return lorem.last_name()


@register.simple_tag
def lorem_town():
    """Display a random town name

    Returns:
        A random name i.e. Edinburgh"""
    return lorem.town()


@register.simple_tag
def lorem_street():
    """Display a random street name

    Returns:
        A street name i.e. Bellvue Crescent"""
    return lorem.street()


@register.simple_tag
def lorem_street_with_number():
    """Display a random street name with a door number.

    Returns:
        A street name i.e. 23 Bellvue Crescent"""
    return lorem.street_with_number()


@register.simple_tag
def lorem_address():
    """Display a random address

    Returns:
        An address i.e. 23 Bellvue Crescent, Edinburgh,
        United Kingdom, EH99 9ZZ."""
    return lorem.address()


@register.simple_tag
def lorem_postcode():
    """Display a random postcode

    Returns:
        A random postcode string"""
    return lorem.postcode()


@register.simple_tag
def lorem_phone_number():
    """Display a random phone number

    Returns:
        A random phone number string"""
    return lorem.phone_number()


@register.simple_tag
def lorem_mobile_number():
    """Display a random mobile number

    Returns:
        A random mobile number string"""
    return lorem.mobile_number()


@register.simple_tag
def lorem_email():
    """Display a random email

    Returns:
        A random email string"""
    return lorem.email()


@register.simple_tag
def lorem_date():
    """Display a random date

    Returns:
        A random date string"""
    return lorem.date()


@register.simple_tag
def lorem_time():
    """Display a random time

    Returns:
        A random time string"""
    return lorem.time()


@register.simple_tag
def lorem_datetime():
    """Display a random datetime

    Returns:
        A random datetime string"""
    return lorem.datetime()
