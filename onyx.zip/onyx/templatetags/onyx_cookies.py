"""Cookie consent bar related tags"""

from django.template import Library
from django.template.loader import render_to_string

from onyx.apps.cookies.consent import CookieConsentReader
from onyx.apps.cookies.library import register as cookie_reg

register = Library()


@register.simple_tag(takes_context=True)
def cookie_consent_bar(context):
    """A tag to conditionally display the cookie bar
    depending on whether or not user has already accepted
    cookies.

    Args:
        context: The template context

    Returns:
        The rendered cookie bar."""
    request = context.get('request')
    reader = CookieConsentReader(request)

    if reader.is_cookie_set() and not reader.is_cookie_expired():
        return ''
    return render_to_string(
        'onyx/apps/cookies/consent-bar.html',
        context={
            'nodes': cookie_reg.get_tree()
        },
        request=context.get('request')
    )
