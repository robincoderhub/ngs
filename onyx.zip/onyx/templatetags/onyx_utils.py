"""General use utility template tags"""

import os
from urllib.parse import urlencode

from django.apps import apps as app_configs
from django.conf import settings
from django.template import Library
from django.template.loader import render_to_string
from django.utils.html import mark_safe

from onyx import utils as onyx_utils
from onyx.utils import files as file_utils


register = Library()


@register.simple_tag
def html_attrs(attr_dict):
    """Generate a valid set of HTML attributes from a
    dict.

    Args:
        attr_dict: A dict containing the html attributes i.e.
            {'hello':'world'} would become ' hello="world"'

    Returns:
        The HTML attributes string."""
    return render_to_string('onyx/templatetags/html_attrs.html', context={
        'attrs': attr_dict
    })


# Static util tags


@register.simple_tag
def include_static(static_file_path):
    """Directly include a static file's source code
    into a template.

    Args:
        static_file_path: The 'static' path to the resource

    Returns:
        The contents of the file."""
    return mark_safe(file_utils.read_static_file(static_file_path, 'r'))


@register.simple_tag
def base64_static_file(static_file_path):
    """Directly include a static file's source code
    into a template and also base64 encodes it. This can
    be useful for encoding images into a template for emails.

    Args:
        static_file_path: The 'static' path to the resource

    Returns:
        The base64 encoded contents of the file."""
    return file_utils.base64_encode_file(
        os.path.join(
            settings.STATIC_ROOT,
            static_file_path
        )
    )


@register.simple_tag
def base64_static_uri(static_file_path, content_type):
    """Typically used for images, this generates a base64
    encoded uri with the contents of an image in it

    Example output:
        data:image/png;base64,iVBORw0...

    Args:
        static_file_path: The 'static' path to the resource
        content_type: The content data type i.e. 'image/png'

    Returns:
        The contents of the file as a uri."""
    return file_utils.get_base64_data_uri(
        os.path.join(
            settings.STATIC_ROOT,
            static_file_path
        ),
        content_type
    )


# Media util tags


@register.simple_tag
def include_media(media_file_path):
    """Directly include a media file's source code
    into a template.

    Args:
        media_file_path: The 'static' path to the resource

    Returns:
        The contents of the file."""
    return mark_safe(file_utils.read_media_file(media_file_path, 'r'))


@register.simple_tag
def base64_media_file(media_file_path):
    """Directly include a media file's source code
    into a template and also base64 encodes it. This can
    be useful for encoding images into a template for emails.

    Args:
        media_file_path: The 'static' path to the resource

    Returns:
        The base64 encoded contents of the file."""
    return file_utils.base64_encode_file(
        os.path.join(
            settings.MEDIA_ROOT,
            media_file_path
        )
    )


@register.simple_tag
def base64_media_uri(media_file_path, content_type):
    """Typically used for images, this generates a base64
    encoded uri with the contents of an image in it from
    an uploaded media file.

    Example output:
        data:image/png;base64,iVBORw0...

    Args:
        media_file_path: The 'static' path to the resource
        content_type: The content data type i.e. 'image/png'

    Returns:
        The contents of the file as a uri."""
    return file_utils.get_base64_data_uri(
        os.path.join(
            settings.MEDIA_ROOT,
            media_file_path
        ),
        content_type
    )


@register.simple_tag
def call_method(obj, method, *args, **kwargs):
    """Call a method on an object and return the result
    to the template

    Args:
        obj: The object to call a method on
        method: The string name of the method to call
        *args: Arguments to pass to the method
        **kwargs: Keyword arguments to pass to the method

    Returns:
        The result of the method call"""
    return getattr(obj, method)(*args, **kwargs)


@register.filter('has_attr')
def has_attr(obj, attr):
    """Filter equivelant of hasattr

    Args:
        obj: The object to check
        attr: The string name of the attribute to check

    Returns:
        True if has attr or false if not"""
    return hasattr(obj, attr)


@register.filter('get_attr')
def get_attr(obj, attr):
    """Filter equivelant of getattr

    Args:
        obj: The object to get an attribute from
        attr: The string name of the attribute to get

    Returns:
        The attribute of the object or None"""
    return getattr(obj, attr)


@register.simple_tag(takes_context=True)
def external_url(context, relative_url):
    """Convert a relative url into a fully qualified url
    using the request context.

    Args:
        context: The template context
        relative_url: The relvative url to convert

    Returns:
        The fully qualified url."""
    url_base = onyx_utils.external_url(context.get('request'))
    return f"{url_base}{relative_url}"


@register.simple_tag(takes_context=False)
def external_url_approximate(relative_url, host=None, port=None, secure=True):
    """Aproximate a relative url into a fully qualified url,
    the most accurate way to do this is with external_url but
    if you do not have access to the request context, it will use
    settings variables to aproximate a url.

    Args:
        relative_url: The relative url to convert
        host: Optional, allows you to manually specify a value for hostname
        port: Optional, allows you to manually specify a value for port
        secure: Defaults to True, https vs. http

    Returns:
        The aproximate url"""
    url_base = onyx_utils.external_url_approximate(
        host=host,
        port=port,
        secure=secure
    )
    return f"{url_base}{relative_url}"


def update_url_params_from_arguments(params, *args, **kwargs):
    """Template tag friendly way of updating a dict using args and kwargs.

    Setting a value to None or 'None' will remove the parameter.

    Example:
        update_url_params_from_arguments(
            'mykey1',
            'myvalue1',
            mykey2='myvalue2'
        )

    Args:
        params: The dict to update
        *args: Arguments to set, each odd argument is a key and each
            even arg is the corresponding value.
        **kwargs: Key value pairs to set.

    Returns:
        The updated dict"""
    if len(args) != 0 and len(args) % 2 != 0:
        raise ValueError(
            "When passing arguments as 'args' an even amount of "
            + "parameter->value pair must be given"
        )

    param_name = None
    for arg in args:
        if not param_name:
            param_name = arg
        else:
            if arg is None or arg == 'None':
                del params[param_name]
            else:
                params[param_name] = arg
            param_name = None

    for param_name, value in kwargs.items():
        if value is None or value == 'None':
            del params[param_name]
        else:
            params[param_name] = value
    return params


@register.simple_tag(takes_context=True)
def request_params(context, *args, **kwargs):
    """Generateds a param string of all current request parameters. It also
    allows you to override, remove or set variables from the template tag.

    Examples:
        If our GET vars look like {'search':'tools', 'page': 1}
        {% request_params page=3 %} # produces search=tools&page=3
        {% request_params page=None %} # produces search=tools
        {% request_params cats='meow' %} # produces search=tools&page=3&cats=meow

    Args:
        *args: Arguments to set, each odd argument is a key and each
            even arg is the corresponding value.
        **kwargs: Key value pairs to set.

    Returns:
        An encoded parameter string"""
    request = context.get('request')
    params = update_url_params_from_arguments(
        request.GET.copy(),
        *args,
        **kwargs
    )
    return urlencode(params)


@register.filter
def split(text, split_char="\n"):
    """Filter equivelant of string.split()

    Args:
        text: The string to split
        split_char: Defaults to line break "\n", the character to split on.
    
    Returns:
        A list of string parts"""
    return text.split(split_char)


@register.filter
def strip(text, strip_chars=" \r\n\t"):
    """Strip characters from a string

    Args:
        text: The text to strip
        strip_chars: Defaults to " \r\n\t", the chars to remove.

    Returns:
        The modified string"""
    text = text or ''
    return text.strip(strip_chars)


@register.filter
def app_is_installed(name):
    """Filter to test if a particular app is installed

    Args:
        name: The name of the app to test for

    Returns:
        True if installed, otherwise False"""
    for app_config in app_configs.get_app_configs():
        if app_config.label == name:
            return True
    return False
