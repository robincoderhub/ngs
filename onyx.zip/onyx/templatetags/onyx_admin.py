"""Utility template tags for the admin section"""

from django import template
from django.template.loader import render_to_string


register = template.Library()


@register.filter('is_menu_open')
def is_menu_open(node_list):
    """Template filter to detect if menu should be 'open'
    i.e. if a sub menu item has been selected, this is typically
    specific to the default admin design.

    Args:
        node_list: The menu node list to search

    Returns:
        True if menu should be open, otherwise False"""
    if node_list is not None:
        for node in node_list:
            # A sub item has been selected
            if node.is_node_selected_parent():
                return True
            # allow opening of top level menu w/o selecting a sub item
            elif node.is_node_selected() and node.has_node_children():
                return True
        return False


@register.simple_tag(takes_context=True)
def admin_pagination(context, paginator, page):
    """A template tag to display the admin version of
    pagination.

    Args:
        context: The page context
        paginator: The Django Paginator object
        page: The current Django Page object

    Returns:
        Rendered template string."""
    return render_to_string(
        template_name='onyx/apps/admin/generic/pagination.html',
        context={
            'paginator': paginator,
            'page': page
        },
        request=context.request
    )
