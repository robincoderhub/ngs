"""Tags used to consitently display form fields in pages"""

from django import template, forms
from django.template.loader import render_to_string
from django.forms.forms import BoundField


register = template.Library()


DUMMY_CHOICES = [
    ('one', 'Option 1'),
    ('two', 'Option 2'),
    ('three', 'Option 3'),
]
"""Options used for multiple value select widget for
dummy fields"""


DUMMY_ID_COUNTER = 0
"""Counter to be used when displaying dummy fields to ensure
all field ids are unique"""


@register.simple_tag
def display_field(field, template_name='onyx/forms/form_field.html'):
    """Display a form field, passes additional CSS class variables
    to make the field easier to style and identify.

    Args:
        field: A django form field of any type
        template_name: Optional, allows you to override the default
            form field template.

    Returns:
        The rendered form field."""
    is_bound_field = isinstance(field, BoundField)
    real_field = field.field if is_bound_field else field

    field_type = type(real_field)
    widget_type = type(real_field.widget)
    field_class = f"-type-{field_type.__name__.replace('Field', '').lower()}"
    widget_name = widget_type.__name__.replace(
        'Input',
        ''
    ).lower()
    field_widget_class = f"-widget-{widget_name}"
    field_required_class = '-required' if real_field.required else ''

    field_error_class = ''
    if is_bound_field and field.errors:
        field_error_class = '-has-errors'

    return render_to_string(
        template_name,
        context={
            'field': field,
            'field_class': field_class,
            'field_widget_class': field_widget_class,
            'field_error_class': field_error_class,
            'field_required_class': field_required_class
        }
    )


@register.simple_tag
def display_dummy_field(
    field_type, label=None, help_text=None,
    placeholder=None, show_errors=False, required=False,
    name=None, choices=DUMMY_CHOICES,
    template_name='onyx/forms/form_field.html'
):
    """Display a 'dummy' form field, this tag is used to display
    fake fields for illustrative purposes in the same way that it'd
    display if it where a real field.

    Field types:
        text: A CharField field
        textarea: A CharField field with a Textarea widget
        email: A CharField field with an EmailInput widget
        password: A CharField with a PasswordInput widget
        number: An IntegerField
        boolean: A BooleanField (checkbox)
        boolean_null: A NullBooleanField, Yes/No/Neither
        date: A DateField
        datetime: DateTimeField
        datetime_split: SplitDateTimeField
        time: A TimeField
        url: A URLField
        file: A FileField
        choice: A ChoiceField
        radiochoice: A ChoiceField with a RadioSelect widget
        multichoice: A MultipleChoiceField
        checkboxes: A MultipleChoiceField with a CheckboxSelectMultiple widget

    Args:
        field_type: The string field type to display.
        label: Optional, the field label to display
        help_text: Optional, the help text to display
        placeholder: Optional, the placeholder text to display
        show_errors: Defaults to False, if True displays the field as
            if it had received an input error.
        required: Defaults to False, if True set the field as required
        name: Optional, the 'name' attribute of the field.
        choices: Optional, a string of comma separated values for
            choice fields. By default uses DUMMY_CHOICES variable.
        template_name: Optional, allows you to override the template
            used to display this form field.

    Returns:
        The rendered form field."""
    global DUMMY_ID_COUNTER
    if label is None:
        label = f"Field ({field_type})"

    if choices and isinstance(choices, str):
        choices = [
            (choice.strip(), choice.strip())
            for choice in choices.split(',')
        ]

    field_mapping = {
        'text': forms.CharField(),
        'textarea': forms.CharField(widget=forms.Textarea()),
        'email': forms.CharField(widget=forms.EmailInput()),
        'password': forms.CharField(widget=forms.PasswordInput()),
        'number': forms.IntegerField(),
        'boolean': forms.BooleanField(),
        'boolean_null': forms.NullBooleanField(),
        'date': forms.DateField(),
        'datetime': forms.DateTimeField(),
        'datetime_split': forms.SplitDateTimeField(),
        'time': forms.TimeField(),
        'url': forms.URLField(),
        'file': forms.FileField(),
        'choice': forms.ChoiceField(
            choices=choices
        ),
        'radiochoice': forms.ChoiceField(
            choices=choices,
            widget=forms.RadioSelect
        ),
        'multichoice': forms.MultipleChoiceField(
            choices=choices
        ),
        'checkboxes': forms.MultipleChoiceField(
            choices=choices,
            widget=forms.CheckboxSelectMultiple()
        )
    }

    if field_type not in field_mapping:
        raise ValueError(
            f'Unknown dummy field type "{field_type}".'
        )

    dummy_field = field_mapping[field_type]
    dummy_field.label = label
    dummy_field.help_text = help_text
    dummy_field.required = required
    if name:
        dummy_field.name = name
    else:
        DUMMY_ID_COUNTER += 1
        dummy_field.name = f'dummy_field_{field_type}_{DUMMY_ID_COUNTER}'

    if placeholder:
        dummy_field.widget.attrs['placeholder'] = placeholder

    form = forms.Form()
    form.dummy_field = dummy_field
    if show_errors:
        form.errors[dummy_field.name] = ["Your input is invalid."]

    return display_field(
        BoundField(
            form,
            dummy_field,
            dummy_field.name
        ),
        template_name=template_name
    )


@register.simple_tag
def display_form(form, template_name='onyx/forms/form.html'):
    """Display all a form's fields in order

    Args:
        form: The Django form to display
        template_name: Optional, allows you to override the template
            used to display this form.

    Returns:
        The rendered form fields."""
    return render_to_string(
        template_name,
        context={
            'form': form
        }
    )


@register.simple_tag
def display_formset(formset, template_name='onyx/forms/formset.html'):
    """Display a formset.

    Args:
        formset: The formset to display
        template_name: Optional, allows you to override the template
            used to display this formset.

    Returns:
        The rendered formset"""
    return render_to_string(
        template_name,
        context={
            'formset': formset
        }
    )


@register.simple_tag
def display_form_errors(form, template_name='onyx/forms/form_errors.html'):
    """Display the 'form' errors, i.e. the __all__ member
    of a form's errors attribute, errors that apply to the form
    as a whole.

    Notes:
        If a form has no errors, this will render an empty string.

    Args:
        form: The form to display the errors of
        template_name: Optional, allows you to override the template used
            to display this forms' errors.

    Returns:
        The rendered errors."""
    return render_to_string(
        template_name,
        context={
            'form': form
        }
    )


@register.filter('is_formset')
def is_formset(formset):
    """Filter for testing if a variable is a formset
    rather than a form.

    Args:
        formset: The object to test

    Returns:
        True if is a formset otherwise False."""
    return isinstance(formset, forms.BaseFormSet)
