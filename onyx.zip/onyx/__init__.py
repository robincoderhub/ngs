"""
# The Onyx library

See the README.md for library overview.

## Installation

The onyx app must be installed when using any of the the sub apps.

To do this add it your installed apps.
```
INSTALLED_APPS = [
    ...
    'onyx',
    ...
]
```

## Configuration

See the app_settings.py file for a full view of all the common settings in Onyx.

It's recommend that you at least define all the `APP_*` settings.

## Setting up the email restriction middleware

For the most part look to the code for explanation of its use, however including a short intro for the email middleware.

The PermittedRecipientsEmailBackend in `utils/email/backends.py` can be used to filter recipients for sent emails, this is super handy during staging or testing to ensure no emails get sent to 'real' addresses. To install the middleware set the following in your `settings.py`
```
EMAIL_BACKEND = (
    'onyx.utils.email.backends.PermittedRecipientsEmailBackend'
)
```

Then set your EMAIL_PERMITTED_RECIPIENTS variable, this should be a list of acceptable email formats. For example:
```
EMAIL_PERMITTED_RECIPIENTS = ['*mercurytide*']
```
Will allow any email with 'mercurytide' in it to be sent to.

By default onyx_foundation already has this set up and can be configured per deployment with the ./bin/configure tool.

"""
default_app_config = 'onyx.config.OnyxConfig'
