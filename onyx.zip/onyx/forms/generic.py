"""Onyx generic form mixins and classes"""

from django.forms import BaseForm


class ReadOnlyFormMixin(BaseForm):
    """A mixin that sets all fields contained in it to
    disabled=True
    
    Args:
        *args: Inherited field arguments
        **kwargs: Inherited field keyword arguments"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.disabled = True

    def save(self, *args, **kwargs):
        """Override, prevents form from saving"""
        return
