"""Onyx form utilities"""

import re


def to_internal_name(input_string):
    """Convert a string to an acceptable internal name

    Args:
        input_string: The string to convert

    Returns:
        A valid internal name version of the string"""

    input_string = re.sub(
        r'[^a-zA-Z\_\- ]',
        '',
        input_string
    )
    return re.sub(
        '[- ]',
        '_',
        input_string
    ).lower()


def get_unclean_data(form, prefixed=False):
    """Get the 'unclean' data from a submitted form

    Args:
        form: The Django Form class to get information from
        prefixed: Optional, if set to true, maintains 'prefixed'
            keyword names.

    Returns:
        A dict of unclean form data"""
    unclean_data = {}
    for field_name in form.fields.keys():
        field_prefix = (
            f"{form.prefix}-"
            if form.prefix is not None
            else ''
        )
        full_field_name = f"{field_prefix}{field_name}"
        if prefixed:
            unclean_data[full_field_name] = form.data.get(full_field_name)
        else:
            unclean_data[field_name] = form.data.get(full_field_name)
    return unclean_data
