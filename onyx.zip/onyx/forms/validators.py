"""General use form input validators"""

import json
from collections.abc import Mapping

from django.core.validators import (
    RegexValidator,
    ValidationError,
    URLValidator
)

from onyx.utils import dotted_path_exists


INTERNAL_NAME_REGEX = r'^[a-z\_]+[a-z0-9\_]*$'
"""A regex for validating 'internal name' type strings"""


DOTTED_PATH_REGEX = r'^[a-zA-Z][a-zA-Z0-9\_]*(\.[a-zA-Z][a-zA-Z0-9\_]*)*$'
"""A regex validating pythong dotted path strings"""


URL_PATH_REGEX = r'^\/[a-z0-9\-._~%!$&\'()*+,;=:@/]*(\?.*)*'
"""A regex for validating relative URL paths"""


class AndValidator(object):
    """Validates that the input matches all of the validators

    Args:
        validators: A list or tuple of validators to use
        message: Optional, can be specified to override error message"""

    def __init__(self, validators=None, message=None):
        self.validators = validators or ()
        # If message is specified, will override any thrown
        self.message = message

    def __call__(self, value):
        """Override, executes validators on input

        Args:
            value: The value to validate

        Raises:
            ValidationError: Raised if input does not validate"""
        for validator in self.validators:
            try:
                validator(value)
            except ValidationError as e:
                code = e.code
                if self.message:
                    raise ValidationError(self.message, code=code)
                raise

    def __eq__(self, other):
        """Override to match this class against others of
        the same type.

        Args:
            other: The 'other' object to compare against

        Returns:
            True if it's considered the same object, otherwise
            False."""
        return (
            isinstance(other, AndValidator)
            and all(
                validator in self.validators
                for validator in other.validators
            )
            and self.message == other.message
        )


class OrValidator(object):
    """Validates that the input matches at least one of the validators

    Args:
        validators: Validators to use
        message: Allows you to override error message if input
            is invalid."""

    def __init__(self, validators=None, message=None):
        self.validators = validators or ()
        # If message is specified, will override any thrown
        self.message = message

    def __call__(self, value):
        """Override, executes validators on input, only
        throws an error if ALL validators fail.

        Args:
            value: The value to validate

        Raises:
            ValidationError: Raised if input does not validate"""
        message = ''
        code = ''
        for validator in self.validators:
            try:
                validator(value)
            except ValidationError as e:
                message = e.messages[0]
                code = e.code
            else:
                return
        if self.message:
            message = self.message
        raise ValidationError(message, code=code)

    def __eq__(self, other):
        """Override to match this class against others of
        the same type.

        Args:
            other: The 'other' object to compare against

        Returns:
            True if it's considered the same object, otherwise
            False."""
        return (
            isinstance(other, OrValidator)
            and all(
                validator in self.validators
                for validator in other.validators
            )
            and self.message == other.message
        )


class InternalNameValidator(RegexValidator):
    """Validates a string as a valid internal name

    Args:
        *args: Inherited arguments
        message: The error emssage to display on failure
        **kwargs: Inherited keyword arguments"""

    def __init__(
        self, *args, regex=INTERNAL_NAME_REGEX,
        message=(
            'Name must start with a letter and only contains lowercase' +
            ' a-z, numbers and the underscore character.'
        ),
        **kwargs
    ):
        super().__init__(
            *args,
            regex=regex,
            message=message,
            **kwargs
        )


class DottedPathValidator(RegexValidator):
    """Validates a string as a valid python import path, does not check if it
    exists.

    Args:
        *args: Inherited arguments
        regex: The regex used to test input
        message: The error message to display on failure
        **kwargs: Inherited keyword arguments"""

    def __init__(
        self, *args, regex=DOTTED_PATH_REGEX,
        message='Must be a valid python class path',
        **kwargs
    ):
        super().__init__(
            *args,
            regex=regex,
            message=message,
            **kwargs
        )


class DottedPathExistsValidator(object):
    """Validates a dotted path as a valid python module or module attribute in
    the current python path.

    Args:
        *args: Inherited arguments
        message: Override of error message"""

    def __init__(
        self,
        message='Python dotted path specificed does not exist in the'
        + ' current PYTHONPATH.'
    ):
        self.message = message

    def __call__(self, value):
        """Override, executes validators on input

        Args:
            value: The value to validate

        Raises:
            ValidationError: Raised if input does not validate"""
        if not dotted_path_exists(value):
            raise ValidationError(self.message)

    def __eq__(self, other):
        """Override to match this class against others of
        the same type.

        Args:
            other: The 'other' object to compare against

        Returns:
            True if it's considered the same object, otherwise
            False."""
        return (
            isinstance(other, DottedPathExistsValidator) and
            self.message == other.message
        )


class ExistingDottedPathValidator(AndValidator):
    """Validates a string as a python dotted path that exists on the python path.

    Args:
        *args: Inherited arguments
        message: Error message on failure
        **kwargs: Inhehrited keyword arguments"""

    def __init__(
        self, *args,
        message='Must be a valid python dotted path that exists on' +
        ' the PYTHONPATH.',
        **kwargs
    ):
        super().__init__(
            *args,
            validators=(
                DottedPathValidator(),
                DottedPathExistsValidator()
            ),
            **kwargs
        )


class URLPathValidator(RegexValidator):
    """Validates a string as a valid relative url path, beginning with a slash.

    Args:
        *args: Inherited arguments
        regex: The regex to use for testing
        message: Error message on failure
        **kwargs: Inhehrited keyword arguments"""

    def __init__(
        self, *args, regex=URL_PATH_REGEX,
        message='Must be a valid url path beginning with a slash.',
        **kwargs
    ):
        super().__init__(
            *args,
            regex=regex,
            message=message,
            **kwargs
        )


class FlexibleURLValidator(OrValidator):
    """Allows either a fully qualified url or a url path '/my/path?something=1'

    Args:
        *args: Inherited arguments
        message: Error message on failure
        **kwargs: Inhehrited keyword arguments"""

    def __init__(
        self, *args,
        message="Must be a qualified url or url path starting with a slash.",
        **kwargs
    ):
        self.message = message
        super().__init__(
            *args,
            validators=(
                URLPathValidator(),
                URLValidator()
            ),
            message=message,
            **kwargs
        )


class JSONValidator(object):
    """Validates a string as JSON.

    Args:
        message: Error message on failure"""

    def __init__(self, message='Must be valid JSON.'):
        self.message = message

    def __call__(self, value):
        """Override, executes validators on input

        Args:
            value: The value to validate

        Raises:
            ValidationError: Raised if input does not validate"""
        try:
            json.loads(value)
        except json.JSONDecodeError:
            raise ValidationError(self.message)

    def __eq__(self, other):
        """Override to match this class against others of
        the same type.

        Args:
            other: The 'other' object to compare against

        Returns:
            True if it's considered the same object, otherwise
            False."""
        return (
            isinstance(other, JSONValidator) and
            self.message == other.message
        )


class JSONObjectValidator(object):
    """Validates a string as a valid JSON object.

    Args:
        message: Error message on failure"""

    def __init__(self, message='Must be a valid JSON object.'):
        self.message = message

    def __call__(self, value):
        """Override, executes validators on input

        Args:
            value: The value to validate

        Raises:
            ValidationError: Raised if input does not validate"""
        try:
            json_object = json.loads(value)
        except json.JSONDecodeError:
            raise ValidationError(self.message)
        else:
            if not isinstance(json_object, Mapping):
                raise ValidationError(self.message)

    def __eq__(self, other):
        """Override to match this class against others of
        the same type.

        Args:
            other: The 'other' object to compare against

        Returns:
            True if it's considered the same object, otherwise
            False."""
        return (
            isinstance(other, JSONObjectValidator) and
            self.message == other.message
        )
