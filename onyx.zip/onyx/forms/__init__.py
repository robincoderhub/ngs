"""Onyx form utilties

This module contains additional fields, widgets, validators etc.
to be used with Django forms."""
