"""Onyx form widgets"""

from django.forms.widgets import Textarea


class TinyMCE(Textarea):
    """A form widget for displaying a TinyMCE editor field

    Args:
        attrs: Optional, a dict of attributes to set on the
            input."""

    template_name = 'onyx/forms/widgets/tinymce.html'
    """The template name of the form widget"""

    def __init__(self, attrs=None):
        default_attrs = {
            'rows': 20
        }
        if attrs:
            default_attrs.update(attrs)
        super().__init__(attrs)
