"""Custom Onyx form field classes"""

from django import forms

from onyx.forms import validators, widgets


class InternalNameField(forms.CharField):
    """Form field that accepts a valid internal name

    Args:
        *args: Inherited field arguments
        max_length: Change of default max_length to 255
        **kwargs: Inherited field keyword arguments"""

    def __init__(self, *args, max_length=255, **kwargs):
        super().__init__(*args, max_length=max_length, **kwargs)
        self.validators.append(validators.InternalNameValidator())


class DottedPathField(forms.CharField):
    """Form field that accepts a valid python import path

    Args:
        *args: Inherited field arguments
        max_length: Change of default max_length to 255
        **kwargs: Inherited field keyword arguments"""

    def __init__(self, *args, max_length=255, **kwargs):
        super().__init__(*args, max_length=max_length, **kwargs)
        self.validators.append(validators.DottedPathValidator())


class ExistingDottedPathField(DottedPathField):
    """Form field that accepts a valid python import path that exists on the
    PYTHONPATH

    Args:
        *args: Inherited field arguments
        **kwargs: Inherited field keyword arguments"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.validators.append(validators.DottedPathExistsValidator())


class JSONField(forms.CharField):
    """Form field that accepts a valid JSON string

    Args:
        *args: Inherited field arguments
        **kwargs: Inherited field keyword arguments"""

    widget = forms.Textarea
    """Changes the default widget to a Textarea"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.validators.append(validators.JSONValidator())


class JSONObjectField(forms.CharField):
    """Form field that accepts a valid JSON string that defines an object

    Args:
        *args: Inherited field arguments
        **kwargs: Inherited field keyword arguments"""

    widget = forms.Textarea
    """Changes the default widget to a Textarea"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.validators.append(validators.JSONObjectValidator())


class URLPathField(forms.CharField):
    """Form field that accepts a valid url path

    Args:
        *args: Inherited field arguments
        **kwargs: Inherited field keyword arguments"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.validators.append(
            validators.URLPathValidator()
        )


class FlexibleURLField(forms.CharField):
    """Form field that accepts either a valid url or url path

    Args:
        *args: Inherited field arguments
        **kwargs: Inherited field keyword arguments"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.validators.append(
            validators.FlexibleURLValidator()
        )


class TinyMCEField(forms.CharField):
    """Charfield utilising a TinyMCE widget"""

    widget = widgets.TinyMCE()
    """Set the default widget to TinyMCE."""
